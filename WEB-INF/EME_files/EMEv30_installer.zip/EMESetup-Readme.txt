************************************************************************************
Installation and Configuration Instructions for the EPA Metadata Editor
************************************************************************************

Preliminary Requirements for Installing the EPA Metadata Editor

1. Make sure you have ArcGIS 9.2 and the most recent service pack installed on your machine.  
You must have ArcGIS 9.2 service pack 2 installed on your machine at a minimum.  
The editor will also install with any ArcGIS 9.2 service pack level above 2 and also with ArcGIS 9.3.

2. Make sure you have the Microsoft .NET Framework 2.0 installed on your machine.
The Microsoft .NET Framework 2.0 can be accessed from Microsoft's website. 
As of 4/8/2007, the website for the distributable package is:
http://www.microsoft.com/downloads/details.aspx?familyid=0856eacb-4362-4b0d-8edd-aab15c5e04f5&displaylang=en
You can determine which version of the .NET Framework is on your machine by going to:
Start->Control Panel->Add or Remove Programs.  
You should see Microsoft .NET Framework 2.0 listed.

3. Make sure you have installed the ESRI .NET Support Feature for ArcGIS.  
This feature is not installed by default when you choose the standard installation for ArcGIS.  
You can determine if this was installed on your machine by going to 'C:\Program Files\ArcGIS' 
(or your default installation directory for ArcGIS) and looking for the DotNet folder.  
If this folder does not exist, the ESRI .NET Support Feature for ArcGIS is not on your machine.  
If this folder does exist but it does not contain anything in it, then the ESRI .NET Support Feature for ArcGIS is not on your machine. 
This folder should have a number of .dll files located within it.
If this feature was not installed with your initial installation of ArcGIS, you can add this to your installation. 
Go to 'Add/Remove programs' in the Control Panel and modifying your installation to include this feature.  
The feature may be installed from the original ESRI ArcGIS source media.

4. If you have the EPA Metadata Editor already installed on your machine, you must uninstall it before installing the newest version. It is recommended that you make a copy of your current metadata.mdb file before uninstalling the EPA Metadata Editor so as to preserve any edits you have made to the database.  You will be required to update the new EPA Metadata Editor 3.0 database to reflect any edits you made to the 2.1 version. For more information on how the EME database has changed from version 2.1 to version 3.0, please review the "Setting up the EME Database" section of the EME help file.

************************************************************************************
Installing the EPA Metadata Editor
1. Double click EMESetup.msi
2. Follow set-up instructions
************************************************************************************


************************************************************************************
Configuring the EPA Metadata Editor in ArcCatalog
1. Open ArcCatalog
2. Go to Tools->Options in the menu bar
3. Click on the Metadata Tab
4. If you do not use the EPA Synchronizer, it is recommended to uncheck the 'Automatically Create Metadata' checkbox to disable ESRI-generated metadata elements.
5. If you do not use the EPA Synchronizer, it is recommended to uncheck the 'Automatically Update Metadata' checkbox to disable ESRI-generated metadata elements.
6. Select the 'EPA Metadata Editor' in the Metadata Editor drop-down at the bottom of the interface.
7. Go to View->Toolbars and make sure the EPA Metadata Editor toolbar is checked on to view the EME toolbar.

************************************************************************************

************************************************************************************
Installation Troubleshooting 
For troubleshooting installation problems and/or other aspects of the EPA Metadata Editor see http://www.epa.gov/geospatial/emefaq.html

For more information, please contact:
Michelle Torreano
Office of Information Collection
Office of Environmental Information
U.S. Environmental Protection Agency
Phone: 202-566-2141
Fax: 202-566-1624
torreano.michelle@epa.gov


