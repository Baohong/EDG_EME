<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EditorForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(EditorForm))
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.dataqual_complete_____default = New System.Windows.Forms.Button()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.dataqual_complete_____warning = New System.Windows.Forms.PictureBox()
        Me.dataqual_logic_____warning = New System.Windows.Forms.PictureBox()
        Me.dataqual_logic_____default = New System.Windows.Forms.Button()
        Me.dataqual_logic_____help = New System.Windows.Forms.LinkLabel()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.dataqual_complete = New System.Windows.Forms.ComboBox()
        Me.dataqual_logic = New System.Windows.Forms.TextBox()
        Me.dataqual_complete_____help = New System.Windows.Forms.LinkLabel()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.dataqual_posacc_horizpa_____warning = New System.Windows.Forms.PictureBox()
        Me.dataqual_posacc_horizpa_horizpar_____warning = New System.Windows.Forms.PictureBox()
        Me.dataqual_posacc_horizpa_horizpar = New System.Windows.Forms.ComboBox()
        Me.dataqual_posacc_horizpa_horizpar_____default = New System.Windows.Forms.Button()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.dataqual_posacc_horizpa_horizpar_____help = New System.Windows.Forms.LinkLabel()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.dataqual_lineage_____warning = New System.Windows.Forms.PictureBox()
        Me.dataqual_lineage_procstep_____warning = New System.Windows.Forms.PictureBox()
        Me.dataqual_lineage_procstep_____help = New System.Windows.Forms.LinkLabel()
        Me.Panel30 = New System.Windows.Forms.Panel()
        Me.btnDelProcstep = New System.Windows.Forms.Button()
        Me.btnAddProcstep = New System.Windows.Forms.Button()
        Me.lblProc = New System.Windows.Forms.Label()
        Me.dataqual_lineage_procstep = New System.Windows.Forms.DataGridView()
        Me.procDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.procdesc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.spref_horizsys_Zone = New System.Windows.Forms.ComboBox()
        Me.spref_horizsys_Zone_____help = New System.Windows.Forms.LinkLabel()
        Me.spref_horizsys_CoordinateSystem = New System.Windows.Forms.ComboBox()
        Me.spref_horizsys_CoordinateSystem_____help = New System.Windows.Forms.LinkLabel()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____warning = New System.Windows.Forms.PictureBox()
        Me.dataqual_posacc_vertacc_qvertpa_vertacce_____warning = New System.Windows.Forms.PictureBox()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.dataqual_posacc_vertacc_qvertpa_vertacce = New System.Windows.Forms.TextBox()
        Me.dataqual_posacc_vertacc_qvertpa_vertacce_____help = New System.Windows.Forms.LinkLabel()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv = New System.Windows.Forms.TextBox()
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____help = New System.Windows.Forms.LinkLabel()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.dataqual_____warning = New System.Windows.Forms.PictureBox()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.dataqual_posacc_horizpa_qhorizpa_horizpae_____warning = New System.Windows.Forms.PictureBox()
        Me.dataqual_posacc_horizpa_qhorizpa_horizpav_____warning = New System.Windows.Forms.PictureBox()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.dataqual_posacc_horizpa_qhorizpa_horizpae = New System.Windows.Forms.TextBox()
        Me.dataqual_posacc_horizpa_qhorizpa_horizpae_____help = New System.Windows.Forms.LinkLabel()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.dataqual_posacc_horizpa_qhorizpa_horizpav = New System.Windows.Forms.TextBox()
        Me.dataqual_posacc_horizpa_qhorizpa_horizpav_____help = New System.Windows.Forms.LinkLabel()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.dataqual_posacc_vertacc_____warning = New System.Windows.Forms.PictureBox()
        Me.dataqual_posacc_vertacc_vertaccr_____warning = New System.Windows.Forms.PictureBox()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.dataqual_posacc_vertacc_vertaccr = New System.Windows.Forms.TextBox()
        Me.dataqual_posacc_vertacc_vertaccr_____help = New System.Windows.Forms.LinkLabel()
        Me.eainfo_overview_eadetcit_____default = New System.Windows.Forms.Button()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.spref_horizsys_Datum = New System.Windows.Forms.ComboBox()
        Me.spref_horizsys_Datum_____help = New System.Windows.Forms.LinkLabel()
        Me.spref_horizsys_Units_____help = New System.Windows.Forms.LinkLabel()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.spref_horizsys_Datum_____warning = New System.Windows.Forms.PictureBox()
        Me.spref_horizsys_Units_____warning = New System.Windows.Forms.PictureBox()
        Me.spref_horizsys_Zone_____warning = New System.Windows.Forms.PictureBox()
        Me.spref_horizsys_____warning = New System.Windows.Forms.PictureBox()
        Me.spref_horizsys_CoordinateSystem_____warning = New System.Windows.Forms.PictureBox()
        Me.spref_horizsys_____default = New System.Windows.Forms.Button()
        Me.spref_horizsys_Units = New System.Windows.Forms.ComboBox()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Panel18 = New System.Windows.Forms.Panel()
        Me.distinfo_distliab_____warning = New System.Windows.Forms.PictureBox()
        Me.distinfo_distliab_____help = New System.Windows.Forms.LinkLabel()
        Me.distinfo_distliab_____default = New System.Windows.Forms.Button()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.distinfo_distliab = New System.Windows.Forms.TextBox()
        Me.GroupBox14 = New System.Windows.Forms.GroupBox()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.distinfo_resdesc_____warning = New System.Windows.Forms.PictureBox()
        Me.distinfo_resdesc_____default = New System.Windows.Forms.Button()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.distinfo_resdesc_____help = New System.Windows.Forms.LinkLabel()
        Me.distinfo_resdesc = New System.Windows.Forms.ComboBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.distinfo_distrib_____warning = New System.Windows.Forms.PictureBox()
        Me.distinfo_distrib_____help = New System.Windows.Forms.LinkLabel()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.distinfo_distrib = New System.Windows.Forms.ComboBox()
        Me.distinfo_distrib_____default = New System.Windows.Forms.Button()
        Me.distinfo_distrib_cntinfo_cntorgp = New System.Windows.Forms.RadioButton()
        Me.distinfo_distrib_cntinfo_cntperp = New System.Windows.Forms.RadioButton()
        Me.distinfo_____warning = New System.Windows.Forms.PictureBox()
        Me.metainfo_metfrd = New System.Windows.Forms.TextBox()
        Me.metainfo_metd = New System.Windows.Forms.TextBox()
        Me.btnMetaFRDate4yrs = New System.Windows.Forms.Button()
        Me.metainfo_metfrd_____help = New System.Windows.Forms.LinkLabel()
        Me.metainfo_metd_____help = New System.Windows.Forms.LinkLabel()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.ComboBox22 = New System.Windows.Forms.ComboBox()
        Me.LinkLabel37 = New System.Windows.Forms.LinkLabel()
        Me.Panel21 = New System.Windows.Forms.Panel()
        Me.metainfo_metstdv_____warning = New System.Windows.Forms.PictureBox()
        Me.metainfo_metstdn_____warning = New System.Windows.Forms.PictureBox()
        Me.Button99 = New System.Windows.Forms.Button()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.metainfo_metstdv = New System.Windows.Forms.TextBox()
        Me.metainfo_metstdn = New System.Windows.Forms.TextBox()
        Me.metainfo_metstdv_____help = New System.Windows.Forms.LinkLabel()
        Me.metainfo_metstdn_____help = New System.Windows.Forms.LinkLabel()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Panel20 = New System.Windows.Forms.Panel()
        Me.metainfo_metc_____warning = New System.Windows.Forms.PictureBox()
        Me.metainfo_metc_____help = New System.Windows.Forms.LinkLabel()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.metainfo_metc = New System.Windows.Forms.ComboBox()
        Me.metainfo_metc_____default = New System.Windows.Forms.Button()
        Me.metainfo_metc_cntinfo_cntorgp = New System.Windows.Forms.RadioButton()
        Me.metainfo_metc_cntinfo_cntperp = New System.Windows.Forms.RadioButton()
        Me.GroupBox17 = New System.Windows.Forms.GroupBox()
        Me.metainfo_____warning = New System.Windows.Forms.PictureBox()
        Me.Panel19 = New System.Windows.Forms.Panel()
        Me.metainfo_metfrd_____warning = New System.Windows.Forms.PictureBox()
        Me.metainfo_metd_____warning = New System.Windows.Forms.PictureBox()
        Me.metainfo_metd_____today = New System.Windows.Forms.Button()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.idinfo_citation_____warning = New System.Windows.Forms.PictureBox()
        Me.Panel23 = New System.Windows.Forms.Panel()
        Me.btnMoreLinkages = New System.Windows.Forms.Button()
        Me.idinfo_citation_citeinfo_onlink_10_ = New System.Windows.Forms.ComboBox()
        Me.idinfo_citation_citeinfo_onlink_9_ = New System.Windows.Forms.ComboBox()
        Me.idinfo_citation_citeinfo_onlink_10______default = New System.Windows.Forms.Button()
        Me.idinfo_citation_citeinfo_onlink_9______default = New System.Windows.Forms.Button()
        Me.idinfo_citation_citeinfo_onlink_10______check = New System.Windows.Forms.Button()
        Me.idinfo_citation_citeinfo_onlink_9______check = New System.Windows.Forms.Button()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.idinfo_citation_citeinfo_onlink_9______help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_citation_citeinfo_onlink_10______help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_citation_citeinfo_onlink_8_ = New System.Windows.Forms.ComboBox()
        Me.idinfo_citation_citeinfo_onlink_7_ = New System.Windows.Forms.ComboBox()
        Me.idinfo_citation_citeinfo_onlink_8______default = New System.Windows.Forms.Button()
        Me.idinfo_citation_citeinfo_onlink_7______default = New System.Windows.Forms.Button()
        Me.idinfo_citation_citeinfo_onlink_8______check = New System.Windows.Forms.Button()
        Me.idinfo_citation_citeinfo_onlink_7______check = New System.Windows.Forms.Button()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.idinfo_citation_citeinfo_onlink_7______help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_citation_citeinfo_onlink_8______help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_citation_citeinfo_onlink_6_ = New System.Windows.Forms.ComboBox()
        Me.idinfo_citation_citeinfo_onlink_5_ = New System.Windows.Forms.ComboBox()
        Me.idinfo_citation_citeinfo_onlink_6______default = New System.Windows.Forms.Button()
        Me.idinfo_citation_citeinfo_onlink_5______default = New System.Windows.Forms.Button()
        Me.idinfo_citation_citeinfo_onlink_6______check = New System.Windows.Forms.Button()
        Me.idinfo_citation_citeinfo_onlink_5______check = New System.Windows.Forms.Button()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.idinfo_citation_citeinfo_onlink_5______help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_citation_citeinfo_onlink_6______help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_citation_citeinfo_onlink_4_ = New System.Windows.Forms.ComboBox()
        Me.idinfo_citation_citeinfo_onlink_3_ = New System.Windows.Forms.ComboBox()
        Me.idinfo_citation_citeinfo_onlink_4______default = New System.Windows.Forms.Button()
        Me.idinfo_citation_citeinfo_onlink_3______default = New System.Windows.Forms.Button()
        Me.idinfo_citation_citeinfo_onlink_4______check = New System.Windows.Forms.Button()
        Me.idinfo_citation_citeinfo_onlink_3______check = New System.Windows.Forms.Button()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.idinfo_citation_citeinfo_onlink_3______help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_citation_citeinfo_onlink_4______help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_citation_citeinfo_onlink_2_ = New System.Windows.Forms.ComboBox()
        Me.idinfo_citation_citeinfo_onlink_1_ = New System.Windows.Forms.ComboBox()
        Me.idinfo_citation_citeinfo_onlink_2______default = New System.Windows.Forms.Button()
        Me.idinfo_citation_citeinfo_onlink_1______default = New System.Windows.Forms.Button()
        Me.idinfo_citation_citeinfo_onlink_____warning = New System.Windows.Forms.PictureBox()
        Me.idinfo_citation_citeinfo_onlink_2______check = New System.Windows.Forms.Button()
        Me.idinfo_citation_citeinfo_onlink_1______check = New System.Windows.Forms.Button()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.idinfo_citation_citeinfo_onlink_1______help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_citation_citeinfo_onlink_2______help = New System.Windows.Forms.LinkLabel()
        Me.Panel22 = New System.Windows.Forms.Panel()
        Me.idinfo_citation_citeinfo_pubdate_____warning = New System.Windows.Forms.PictureBox()
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____warning = New System.Windows.Forms.PictureBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.idinfo_citation_citeinfo_pubinfo_publish_____warning = New System.Windows.Forms.PictureBox()
        Me.idinfo_citation_citeinfo_pubinfo_____warning = New System.Windows.Forms.PictureBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.idinfo_citation_citeinfo_pubdate_____help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_citation_citeinfo_pubdate_____today = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.idinfo_citation_citeinfo_pubdate = New System.Windows.Forms.TextBox()
        Me.idinfo_citation_citeinfo_pubinfo_publish_____help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_citation_citeinfo_pubinfo_publish = New System.Windows.Forms.ComboBox()
        Me.idinfo_citation_citeinfo_pubinfo_pubplace = New System.Windows.Forms.ComboBox()
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____help = New System.Windows.Forms.LinkLabel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.idinfo_citation_citeinfo_title_____warning = New System.Windows.Forms.PictureBox()
        Me.idinfo_citation_citeinfo_origin_____warning = New System.Windows.Forms.PictureBox()
        Me.idinfo_citation_citeinfo_title_____default = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.idinfo_citation_citeinfo_title_____help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_citation_citeinfo_origin_____help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_citation_citeinfo_origin_____default = New System.Windows.Forms.Button()
        Me.idinfo_citation_citeinfo_title = New System.Windows.Forms.TextBox()
        Me.idinfo_citation_citeinfo_origin = New System.Windows.Forms.TextBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.idinfo_spdom_____warning = New System.Windows.Forms.PictureBox()
        Me.Panel24 = New System.Windows.Forms.Panel()
        Me.idinfo_spdom_bounding_southbc_____warning = New System.Windows.Forms.PictureBox()
        Me.idinfo_spdom_bounding_westbc_____warning = New System.Windows.Forms.PictureBox()
        Me.idinfo_spdom_bounding_eastbc_____warning = New System.Windows.Forms.PictureBox()
        Me.idinfo_spdom_bounding_northbc_____warning = New System.Windows.Forms.PictureBox()
        Me.idinfo_spdom_bounding_westbc = New System.Windows.Forms.TextBox()
        Me.idinfo_spdom_bounding_southbc_____help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_spdom_bounding_westbc_____help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_spdom_bounding_eastbc_____help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_spdom_bounding_northbc_____help = New System.Windows.Forms.LinkLabel()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.idinfo_spdom_bounding = New System.Windows.Forms.ComboBox()
        Me.idinfo_spdom_bounding_southbc = New System.Windows.Forms.TextBox()
        Me.idinfo_spdom_bounding_eastbc = New System.Windows.Forms.TextBox()
        Me.idinfo_spdom_bounding_____default = New System.Windows.Forms.Button()
        Me.idinfo_spdom_bounding_northbc = New System.Windows.Forms.TextBox()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.idinfo_ptcontac_____warning = New System.Windows.Forms.PictureBox()
        Me.idinfo_ptcontac_____help = New System.Windows.Forms.LinkLabel()
        Me.Panel26 = New System.Windows.Forms.Panel()
        Me.idinfo_ptcontac = New System.Windows.Forms.ComboBox()
        Me.idinfo_ptcontac_cntinfo_cntorgp = New System.Windows.Forms.RadioButton()
        Me.idinfo_ptcontac_____default = New System.Windows.Forms.Button()
        Me.idinfo_ptcontac_cntinfo_cntperp = New System.Windows.Forms.RadioButton()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.Panel25 = New System.Windows.Forms.Panel()
        Me.idinfo_secinfo_____warning = New System.Windows.Forms.PictureBox()
        Me.idinfo_useconst_____warning = New System.Windows.Forms.PictureBox()
        Me.idinfo_accconst_____warning = New System.Windows.Forms.PictureBox()
        Me.idinfo_secinfo_____default = New System.Windows.Forms.Button()
        Me.idinfo_useconst_____default = New System.Windows.Forms.Button()
        Me.idinfo_accconst_____default = New System.Windows.Forms.Button()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.idinfo_secinfo = New System.Windows.Forms.ComboBox()
        Me.idinfo_accconst = New System.Windows.Forms.ComboBox()
        Me.idinfo_accconst_____help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_secinfo_____help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_useconst_____help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_useconst = New System.Windows.Forms.ComboBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.idinfo_keywords_____warning = New System.Windows.Forms.PictureBox()
        Me.tcKeywords = New System.Windows.Forms.TabControl()
        Me.tpISO = New System.Windows.Forms.TabPage()
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____default = New System.Windows.Forms.Button()
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category_______warning = New System.Windows.Forms.PictureBox()
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey = New System.Windows.Forms.ListBox()
        Me.tpEPA = New System.Windows.Forms.TabPage()
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____default = New System.Windows.Forms.Button()
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus_______warning = New System.Windows.Forms.PictureBox()
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey = New System.Windows.Forms.ListBox()
        Me.tpUser = New System.Windows.Forms.TabPage()
        Me.idinfo_keywords_theme_themekt__User___themekey_____default = New System.Windows.Forms.Button()
        Me.idinfo_keywords_theme_themekt__User___themekey_____help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_keywords_theme_themekt__User_______warning = New System.Windows.Forms.PictureBox()
        Me.idinfo_keywords_theme_themekt__User___themekey = New System.Windows.Forms.ListBox()
        Me.tpPlace = New System.Windows.Forms.TabPage()
        Me.idinfo_keywords_place_placekt__None___placekey_____default = New System.Windows.Forms.Button()
        Me.idinfo_keywords_place_placekt__None___placekey_____help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_keywords_place_placekt__None_______warning = New System.Windows.Forms.PictureBox()
        Me.idinfo_keywords_place_placekt__None___placekey = New System.Windows.Forms.ListBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.idinfo_status_____warning = New System.Windows.Forms.PictureBox()
        Me.idinfo_timeperd_____warning = New System.Windows.Forms.PictureBox()
        Me.Panel27 = New System.Windows.Forms.Panel()
        Me.idinfo_status_update_____warning = New System.Windows.Forms.PictureBox()
        Me.idinfo_timeperd_current_____warning = New System.Windows.Forms.PictureBox()
        Me.idinfo_status_progress_____warning = New System.Windows.Forms.PictureBox()
        Me.GroupBox18 = New System.Windows.Forms.GroupBox()
        Me.idinfo_timeperd_timeinfo_____warning = New System.Windows.Forms.PictureBox()
        Me.timeinfo_____help2 = New System.Windows.Forms.LinkLabel()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.timeinfo_____today = New System.Windows.Forms.Button()
        Me.timeinfo = New System.Windows.Forms.TextBox()
        Me.idinfo_timeperd_timeinfo_mdattim_sngdate____caldate = New System.Windows.Forms.ListBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.idinfo_status_update = New System.Windows.Forms.ComboBox()
        Me.idinfo_status_progress_____help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_timeperd_current = New System.Windows.Forms.ComboBox()
        Me.idinfo_status_progress = New System.Windows.Forms.ComboBox()
        Me.idinfo_status_update_____help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_timeperd_current_____help = New System.Windows.Forms.LinkLabel()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.idinfo_descript_____warning = New System.Windows.Forms.PictureBox()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.idinfo_descript_purpose_____warning = New System.Windows.Forms.PictureBox()
        Me.idinfo_descript_abstract_____warning = New System.Windows.Forms.PictureBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.idinfo_descript_purpose_____help = New System.Windows.Forms.LinkLabel()
        Me.idinfo_descript_purpose = New System.Windows.Forms.TextBox()
        Me.idinfo_descript_abstract = New System.Windows.Forms.TextBox()
        Me.idinfo_descript_abstract_____help = New System.Windows.Forms.LinkLabel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.idinfo_descript_supplinf_____warning = New System.Windows.Forms.PictureBox()
        Me.idinfo_descript_supplinf = New System.Windows.Forms.TextBox()
        Me.idinfo_descript_supplinf_____help = New System.Windows.Forms.LinkLabel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnCloseDiscard = New System.Windows.Forms.Button()
        Me.btnCloseSave = New System.Windows.Forms.Button()
        Me.tcEME = New System.Windows.Forms.TabControl()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.GroupBox13 = New System.Windows.Forms.GroupBox()
        Me.eainfo_____warning = New System.Windows.Forms.PictureBox()
        Me.tcEntityAttr = New System.Windows.Forms.TabControl()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.eainfo_overview_eadetcit_____warning = New System.Windows.Forms.PictureBox()
        Me.eainfo_overview_eadetcit_____help = New System.Windows.Forms.LinkLabel()
        Me.eainfo_overview_eaover_____warning = New System.Windows.Forms.PictureBox()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.eainfo_overview_eaover_____help = New System.Windows.Forms.LinkLabel()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.eainfo_overview_eadetcit = New System.Windows.Forms.ComboBox()
        Me.eainfo_overview_eaover = New System.Windows.Forms.TextBox()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.btnDeleteEntity = New System.Windows.Forms.Button()
        Me.btnAddEntity = New System.Windows.Forms.Button()
        Me.enttypd = New System.Windows.Forms.TextBox()
        Me.enttyp_____help2 = New System.Windows.Forms.LinkLabel()
        Me.detailed_____help2 = New System.Windows.Forms.LinkLabel()
        Me.enttypds_____help2 = New System.Windows.Forms.Label()
        Me.enttypd_____help2 = New System.Windows.Forms.Label()
        Me.enttypds = New System.Windows.Forms.ComboBox()
        Me.enttypl = New System.Windows.Forms.ComboBox()
        Me.enttypl_____help2 = New System.Windows.Forms.Label()
        Me.grpDomain = New System.Windows.Forms.GroupBox()
        Me.attrdomv_____help2 = New System.Windows.Forms.LinkLabel()
        Me.tcDomain = New System.Windows.Forms.TabControl()
        Me.tp_rdom = New System.Windows.Forms.TabPage()
        Me.rdommax = New System.Windows.Forms.TextBox()
        Me.rdommax_____help2 = New System.Windows.Forms.Label()
        Me.rdommin_____help2 = New System.Windows.Forms.Label()
        Me.rdommin = New System.Windows.Forms.TextBox()
        Me.tp_codesetd = New System.Windows.Forms.TabPage()
        Me.codesetn = New System.Windows.Forms.TextBox()
        Me.codesets_____help2 = New System.Windows.Forms.Label()
        Me.codesetn_____help2 = New System.Windows.Forms.Label()
        Me.codesets = New System.Windows.Forms.ComboBox()
        Me.tp_edom = New System.Windows.Forms.TabPage()
        Me.dgv_edom = New System.Windows.Forms.DataGridView()
        Me.Value = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Definition = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DefinitionSource = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.tp_udom = New System.Windows.Forms.TabPage()
        Me.udom = New System.Windows.Forms.ComboBox()
        Me.grpAttr = New System.Windows.Forms.GroupBox()
        Me.btnDeleteAttribute = New System.Windows.Forms.Button()
        Me.btnAddAttribute = New System.Windows.Forms.Button()
        Me.attrdef = New System.Windows.Forms.TextBox()
        Me.attr_____help2 = New System.Windows.Forms.LinkLabel()
        Me.attrdefs_____help2 = New System.Windows.Forms.Label()
        Me.attrdef_____help2 = New System.Windows.Forms.Label()
        Me.attrlabl_____help2 = New System.Windows.Forms.Label()
        Me.attrdefs = New System.Windows.Forms.ComboBox()
        Me.attrlabl = New System.Windows.Forms.ComboBox()
        Me.GroupBox12 = New System.Windows.Forms.GroupBox()
        Me.spref_____warning = New System.Windows.Forms.PictureBox()
        Me.spref_horizsys = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Panel28 = New System.Windows.Forms.Panel()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Panel29 = New System.Windows.Forms.Panel()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.EMESpelling = New NetSpell.SpellChecker.Spelling(Me.components)
        Me.EMEWordDictionary = New NetSpell.SpellChecker.Dictionary.WordDictionary(Me.components)
        Me.HoverToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.btnSave = New System.Windows.Forms.Button()
        Me._____warning = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.toolStripSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveAsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.toolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.PrintToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrintPreviewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.toolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UndoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RedoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.toolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.CutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PasteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.toolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.SelectAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FindAndReplaceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SpellCheckToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetDefaultToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.LocalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViaWebserviceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.tbValidationTimeout = New System.Windows.Forms.ToolStripTextBox()
        Me.SetValidationResultsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewInUserInterfaceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewInBrowserWindowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ValidateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewMetadataXMLToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenDatabaseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RefreshFromDatabaseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoveESRITagsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IndexToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SearchToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.toolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Panel9.SuspendLayout()
        CType(Me.dataqual_complete_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dataqual_logic_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel10.SuspendLayout()
        CType(Me.dataqual_posacc_horizpa_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dataqual_posacc_horizpa_horizpar_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox11.SuspendLayout()
        CType(Me.dataqual_lineage_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dataqual_lineage_procstep_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel30.SuspendLayout()
        CType(Me.dataqual_lineage_procstep, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel12.SuspendLayout()
        CType(Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dataqual_posacc_vertacc_qvertpa_vertacce_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox10.SuspendLayout()
        CType(Me.dataqual_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel11.SuspendLayout()
        CType(Me.dataqual_posacc_horizpa_qhorizpa_horizpae_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dataqual_posacc_horizpa_qhorizpa_horizpav_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel13.SuspendLayout()
        CType(Me.dataqual_posacc_vertacc_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dataqual_posacc_vertacc_vertaccr_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel14.SuspendLayout()
        CType(Me.spref_horizsys_Datum_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spref_horizsys_Units_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spref_horizsys_Zone_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spref_horizsys_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spref_horizsys_CoordinateSystem_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel18.SuspendLayout()
        CType(Me.distinfo_distliab_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox14.SuspendLayout()
        Me.Panel17.SuspendLayout()
        CType(Me.distinfo_resdesc_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel16.SuspendLayout()
        CType(Me.distinfo_distrib_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.distinfo_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel21.SuspendLayout()
        CType(Me.metainfo_metstdv_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.metainfo_metstdn_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel20.SuspendLayout()
        CType(Me.metainfo_metc_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox17.SuspendLayout()
        CType(Me.metainfo_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel19.SuspendLayout()
        CType(Me.metainfo_metfrd_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.metainfo_metd_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.idinfo_citation_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel23.SuspendLayout()
        CType(Me.idinfo_citation_citeinfo_onlink_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel22.SuspendLayout()
        CType(Me.idinfo_citation_citeinfo_pubdate_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.idinfo_citation_citeinfo_pubinfo_pubplace_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.idinfo_citation_citeinfo_pubinfo_publish_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.idinfo_citation_citeinfo_pubinfo_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.idinfo_citation_citeinfo_title_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.idinfo_citation_citeinfo_origin_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        CType(Me.idinfo_spdom_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel24.SuspendLayout()
        CType(Me.idinfo_spdom_bounding_southbc_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.idinfo_spdom_bounding_westbc_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.idinfo_spdom_bounding_eastbc_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.idinfo_spdom_bounding_northbc_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox7.SuspendLayout()
        CType(Me.idinfo_ptcontac_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel26.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.Panel25.SuspendLayout()
        CType(Me.idinfo_secinfo_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.idinfo_useconst_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.idinfo_accconst_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        CType(Me.idinfo_keywords_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tcKeywords.SuspendLayout()
        Me.tpISO.SuspendLayout()
        CType(Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category_______warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpEPA.SuspendLayout()
        CType(Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus_______warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpUser.SuspendLayout()
        CType(Me.idinfo_keywords_theme_themekt__User_______warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpPlace.SuspendLayout()
        CType(Me.idinfo_keywords_place_placekt__None_______warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        CType(Me.idinfo_status_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.idinfo_timeperd_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel27.SuspendLayout()
        CType(Me.idinfo_status_update_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.idinfo_timeperd_current_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.idinfo_status_progress_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox18.SuspendLayout()
        CType(Me.idinfo_timeperd_timeinfo_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.idinfo_descript_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel6.SuspendLayout()
        CType(Me.idinfo_descript_purpose_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.idinfo_descript_abstract_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.idinfo_descript_supplinf_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tcEME.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox13.SuspendLayout()
        CType(Me.eainfo_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tcEntityAttr.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        CType(Me.eainfo_overview_eadetcit_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.eainfo_overview_eaover_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage9.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.grpDomain.SuspendLayout()
        Me.tcDomain.SuspendLayout()
        Me.tp_rdom.SuspendLayout()
        Me.tp_codesetd.SuspendLayout()
        Me.tp_edom.SuspendLayout()
        CType(Me.dgv_edom, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tp_udom.SuspendLayout()
        Me.grpAttr.SuspendLayout()
        Me.GroupBox12.SuspendLayout()
        CType(Me.spref_____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel5.SuspendLayout()
        Me.Panel28.SuspendLayout()
        Me.Panel29.SuspendLayout()
        CType(Me._____warning, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'dataqual_complete_____default
        '
        Me.dataqual_complete_____default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.dataqual_complete_____default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dataqual_complete_____default.Location = New System.Drawing.Point(396, 28)
        Me.dataqual_complete_____default.Name = "dataqual_complete_____default"
        Me.dataqual_complete_____default.Size = New System.Drawing.Size(33, 23)
        Me.dataqual_complete_____default.TabIndex = 4
        Me.dataqual_complete_____default.Text = "D"
        Me.dataqual_complete_____default.UseVisualStyleBackColor = False
        '
        'Panel9
        '
        Me.Panel9.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel9.Controls.Add(Me.dataqual_complete_____warning)
        Me.Panel9.Controls.Add(Me.dataqual_logic_____warning)
        Me.Panel9.Controls.Add(Me.dataqual_logic_____default)
        Me.Panel9.Controls.Add(Me.dataqual_logic_____help)
        Me.Panel9.Controls.Add(Me.Label51)
        Me.Panel9.Controls.Add(Me.Label50)
        Me.Panel9.Controls.Add(Me.dataqual_complete_____default)
        Me.Panel9.Controls.Add(Me.dataqual_complete)
        Me.Panel9.Controls.Add(Me.dataqual_logic)
        Me.Panel9.Controls.Add(Me.dataqual_complete_____help)
        Me.Panel9.Location = New System.Drawing.Point(6, 16)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(432, 57)
        Me.Panel9.TabIndex = 0
        '
        'dataqual_complete_____warning
        '
        Me.dataqual_complete_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_complete_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_complete_____warning.Location = New System.Drawing.Point(131, 35)
        Me.dataqual_complete_____warning.Name = "dataqual_complete_____warning"
        Me.dataqual_complete_____warning.Size = New System.Drawing.Size(13, 14)
        Me.dataqual_complete_____warning.TabIndex = 44
        Me.dataqual_complete_____warning.TabStop = False
        Me.dataqual_complete_____warning.Visible = False
        '
        'dataqual_logic_____warning
        '
        Me.dataqual_logic_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_logic_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_logic_____warning.Location = New System.Drawing.Point(98, 9)
        Me.dataqual_logic_____warning.Name = "dataqual_logic_____warning"
        Me.dataqual_logic_____warning.Size = New System.Drawing.Size(13, 14)
        Me.dataqual_logic_____warning.TabIndex = 43
        Me.dataqual_logic_____warning.TabStop = False
        Me.dataqual_logic_____warning.Visible = False
        '
        'dataqual_logic_____default
        '
        Me.dataqual_logic_____default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.dataqual_logic_____default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dataqual_logic_____default.Location = New System.Drawing.Point(396, 3)
        Me.dataqual_logic_____default.Name = "dataqual_logic_____default"
        Me.dataqual_logic_____default.Size = New System.Drawing.Size(33, 23)
        Me.dataqual_logic_____default.TabIndex = 18
        Me.dataqual_logic_____default.Text = "D"
        Me.dataqual_logic_____default.UseVisualStyleBackColor = False
        '
        'dataqual_logic_____help
        '
        Me.dataqual_logic_____help.AutoSize = True
        Me.dataqual_logic_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dataqual_logic_____help.Location = New System.Drawing.Point(20, 9)
        Me.dataqual_logic_____help.Name = "dataqual_logic_____help"
        Me.dataqual_logic_____help.Size = New System.Drawing.Size(82, 13)
        Me.dataqual_logic_____help.TabIndex = 0
        Me.dataqual_logic_____help.TabStop = True
        Me.dataqual_logic_____help.Text = "Integrity Tests:"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.ForeColor = System.Drawing.Color.Black
        Me.Label51.Location = New System.Drawing.Point(7, 38)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(13, 13)
        Me.Label51.TabIndex = 17
        Me.Label51.Text = "*"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.ForeColor = System.Drawing.Color.Black
        Me.Label50.Location = New System.Drawing.Point(7, 11)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(13, 13)
        Me.Label50.TabIndex = 16
        Me.Label50.Text = "*"
        '
        'dataqual_complete
        '
        Me.dataqual_complete.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dataqual_complete.FormattingEnabled = True
        Me.dataqual_complete.Location = New System.Drawing.Point(143, 30)
        Me.dataqual_complete.Name = "dataqual_complete"
        Me.dataqual_complete.Size = New System.Drawing.Size(247, 21)
        Me.dataqual_complete.TabIndex = 3
        '
        'dataqual_logic
        '
        Me.dataqual_logic.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dataqual_logic.Location = New System.Drawing.Point(112, 6)
        Me.dataqual_logic.Name = "dataqual_logic"
        Me.dataqual_logic.Size = New System.Drawing.Size(278, 21)
        Me.dataqual_logic.TabIndex = 2
        '
        'dataqual_complete_____help
        '
        Me.dataqual_complete_____help.AutoSize = True
        Me.dataqual_complete_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dataqual_complete_____help.Location = New System.Drawing.Point(20, 35)
        Me.dataqual_complete_____help.Name = "dataqual_complete_____help"
        Me.dataqual_complete_____help.Size = New System.Drawing.Size(117, 13)
        Me.dataqual_complete_____help.TabIndex = 1
        Me.dataqual_complete_____help.TabStop = True
        Me.dataqual_complete_____help.Text = "Completeness of Data:"
        '
        'Panel10
        '
        Me.Panel10.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel10.Controls.Add(Me.dataqual_posacc_horizpa_____warning)
        Me.Panel10.Controls.Add(Me.dataqual_posacc_horizpa_horizpar_____warning)
        Me.Panel10.Controls.Add(Me.dataqual_posacc_horizpa_horizpar)
        Me.Panel10.Controls.Add(Me.dataqual_posacc_horizpa_horizpar_____default)
        Me.Panel10.Controls.Add(Me.Label52)
        Me.Panel10.Controls.Add(Me.dataqual_posacc_horizpa_horizpar_____help)
        Me.Panel10.Controls.Add(Me.Label12)
        Me.Panel10.Location = New System.Drawing.Point(6, 78)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(432, 44)
        Me.Panel10.TabIndex = 2
        '
        'dataqual_posacc_horizpa_____warning
        '
        Me.dataqual_posacc_horizpa_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_posacc_horizpa_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_posacc_horizpa_____warning.Location = New System.Drawing.Point(186, 0)
        Me.dataqual_posacc_horizpa_____warning.Name = "dataqual_posacc_horizpa_____warning"
        Me.dataqual_posacc_horizpa_____warning.Size = New System.Drawing.Size(13, 14)
        Me.dataqual_posacc_horizpa_____warning.TabIndex = 46
        Me.dataqual_posacc_horizpa_____warning.TabStop = False
        Me.dataqual_posacc_horizpa_____warning.Visible = False
        '
        'dataqual_posacc_horizpa_horizpar_____warning
        '
        Me.dataqual_posacc_horizpa_horizpar_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_posacc_horizpa_horizpar_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_posacc_horizpa_horizpar_____warning.Location = New System.Drawing.Point(58, 18)
        Me.dataqual_posacc_horizpa_horizpar_____warning.Name = "dataqual_posacc_horizpa_horizpar_____warning"
        Me.dataqual_posacc_horizpa_horizpar_____warning.Size = New System.Drawing.Size(13, 14)
        Me.dataqual_posacc_horizpa_horizpar_____warning.TabIndex = 45
        Me.dataqual_posacc_horizpa_horizpar_____warning.TabStop = False
        Me.dataqual_posacc_horizpa_horizpar_____warning.Visible = False
        '
        'dataqual_posacc_horizpa_horizpar
        '
        Me.dataqual_posacc_horizpa_horizpar.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dataqual_posacc_horizpa_horizpar.FormattingEnabled = True
        Me.dataqual_posacc_horizpa_horizpar.Location = New System.Drawing.Point(70, 15)
        Me.dataqual_posacc_horizpa_horizpar.Name = "dataqual_posacc_horizpa_horizpar"
        Me.dataqual_posacc_horizpa_horizpar.Size = New System.Drawing.Size(320, 21)
        Me.dataqual_posacc_horizpa_horizpar.TabIndex = 19
        '
        'dataqual_posacc_horizpa_horizpar_____default
        '
        Me.dataqual_posacc_horizpa_horizpar_____default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.dataqual_posacc_horizpa_horizpar_____default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dataqual_posacc_horizpa_horizpar_____default.Location = New System.Drawing.Point(396, 15)
        Me.dataqual_posacc_horizpa_horizpar_____default.Name = "dataqual_posacc_horizpa_horizpar_____default"
        Me.dataqual_posacc_horizpa_horizpar_____default.Size = New System.Drawing.Size(33, 23)
        Me.dataqual_posacc_horizpa_horizpar_____default.TabIndex = 18
        Me.dataqual_posacc_horizpa_horizpar_____default.Text = "D"
        Me.dataqual_posacc_horizpa_horizpar_____default.UseVisualStyleBackColor = False
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.ForeColor = System.Drawing.Color.Black
        Me.Label52.Location = New System.Drawing.Point(7, 18)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(13, 13)
        Me.Label52.TabIndex = 17
        Me.Label52.Text = "*"
        '
        'dataqual_posacc_horizpa_horizpar_____help
        '
        Me.dataqual_posacc_horizpa_horizpar_____help.AutoSize = True
        Me.dataqual_posacc_horizpa_horizpar_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dataqual_posacc_horizpa_horizpar_____help.Location = New System.Drawing.Point(20, 17)
        Me.dataqual_posacc_horizpa_horizpar_____help.Name = "dataqual_posacc_horizpa_horizpar_____help"
        Me.dataqual_posacc_horizpa_horizpar_____help.Size = New System.Drawing.Size(44, 13)
        Me.dataqual_posacc_horizpa_horizpar_____help.TabIndex = 2
        Me.dataqual_posacc_horizpa_horizpar_____help.TabStop = True
        Me.dataqual_posacc_horizpa_horizpar_____help.Text = "Report:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(8, -2)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(178, 13)
        Me.Label12.TabIndex = 1
        Me.Label12.Text = "Horizontal Positional Accuracy"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.ForeColor = System.Drawing.Color.Black
        Me.Label15.Location = New System.Drawing.Point(7, -1)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(163, 13)
        Me.Label15.TabIndex = 1
        Me.Label15.Text = "Vertical Positional Accuracy"
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.dataqual_lineage_____warning)
        Me.GroupBox11.Controls.Add(Me.dataqual_lineage_procstep_____warning)
        Me.GroupBox11.Controls.Add(Me.dataqual_lineage_procstep_____help)
        Me.GroupBox11.Controls.Add(Me.Panel30)
        Me.GroupBox11.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox11.ForeColor = System.Drawing.Color.Black
        Me.GroupBox11.Location = New System.Drawing.Point(6, 276)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(443, 240)
        Me.GroupBox11.TabIndex = 1
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "                                "
        '
        'dataqual_lineage_____warning
        '
        Me.dataqual_lineage_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_lineage_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_lineage_____warning.Location = New System.Drawing.Point(118, 0)
        Me.dataqual_lineage_____warning.Name = "dataqual_lineage_____warning"
        Me.dataqual_lineage_____warning.Size = New System.Drawing.Size(13, 14)
        Me.dataqual_lineage_____warning.TabIndex = 50
        Me.dataqual_lineage_____warning.TabStop = False
        Me.dataqual_lineage_____warning.Visible = False
        '
        'dataqual_lineage_procstep_____warning
        '
        Me.dataqual_lineage_procstep_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_lineage_procstep_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_lineage_procstep_____warning.Location = New System.Drawing.Point(104, 0)
        Me.dataqual_lineage_procstep_____warning.Name = "dataqual_lineage_procstep_____warning"
        Me.dataqual_lineage_procstep_____warning.Size = New System.Drawing.Size(13, 14)
        Me.dataqual_lineage_procstep_____warning.TabIndex = 49
        Me.dataqual_lineage_procstep_____warning.TabStop = False
        Me.dataqual_lineage_procstep_____warning.Visible = False
        '
        'dataqual_lineage_procstep_____help
        '
        Me.dataqual_lineage_procstep_____help.AutoSize = True
        Me.dataqual_lineage_procstep_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dataqual_lineage_procstep_____help.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.dataqual_lineage_procstep_____help.Location = New System.Drawing.Point(6, 0)
        Me.dataqual_lineage_procstep_____help.Name = "dataqual_lineage_procstep_____help"
        Me.dataqual_lineage_procstep_____help.Size = New System.Drawing.Size(103, 13)
        Me.dataqual_lineage_procstep_____help.TabIndex = 51
        Me.dataqual_lineage_procstep_____help.TabStop = True
        Me.dataqual_lineage_procstep_____help.Text = "Processing Steps"
        '
        'Panel30
        '
        Me.Panel30.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel30.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Panel30.Controls.Add(Me.btnDelProcstep)
        Me.Panel30.Controls.Add(Me.btnAddProcstep)
        Me.Panel30.Controls.Add(Me.lblProc)
        Me.Panel30.Controls.Add(Me.dataqual_lineage_procstep)
        Me.Panel30.Location = New System.Drawing.Point(5, 18)
        Me.Panel30.Name = "Panel30"
        Me.Panel30.Size = New System.Drawing.Size(432, 216)
        Me.Panel30.TabIndex = 36
        '
        'btnDelProcstep
        '
        Me.btnDelProcstep.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.btnDelProcstep.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelProcstep.Image = Global.MetadataEditor.My.Resources.Resources.minus
        Me.btnDelProcstep.Location = New System.Drawing.Point(413, 3)
        Me.btnDelProcstep.Name = "btnDelProcstep"
        Me.btnDelProcstep.Size = New System.Drawing.Size(16, 16)
        Me.btnDelProcstep.TabIndex = 44
        Me.btnDelProcstep.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnDelProcstep.UseVisualStyleBackColor = False
        '
        'btnAddProcstep
        '
        Me.btnAddProcstep.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.btnAddProcstep.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddProcstep.Image = Global.MetadataEditor.My.Resources.Resources.plus
        Me.btnAddProcstep.Location = New System.Drawing.Point(391, 3)
        Me.btnAddProcstep.Name = "btnAddProcstep"
        Me.btnAddProcstep.Size = New System.Drawing.Size(16, 16)
        Me.btnAddProcstep.TabIndex = 43
        Me.btnAddProcstep.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnAddProcstep.UseVisualStyleBackColor = False
        '
        'lblProc
        '
        Me.lblProc.AutoSize = True
        Me.lblProc.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProc.Location = New System.Drawing.Point(3, 3)
        Me.lblProc.Name = "lblProc"
        Me.lblProc.Size = New System.Drawing.Size(174, 13)
        Me.lblProc.TabIndex = 1
        Me.lblProc.Text = "(* only 1 processing step required)"
        '
        'dataqual_lineage_procstep
        '
        Me.dataqual_lineage_procstep.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.dataqual_lineage_procstep.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dataqual_lineage_procstep.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.procDate, Me.procdesc})
        Me.dataqual_lineage_procstep.Location = New System.Drawing.Point(4, 22)
        Me.dataqual_lineage_procstep.Name = "dataqual_lineage_procstep"
        Me.dataqual_lineage_procstep.RowHeadersVisible = False
        Me.dataqual_lineage_procstep.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dataqual_lineage_procstep.Size = New System.Drawing.Size(425, 191)
        Me.dataqual_lineage_procstep.TabIndex = 0
        '
        'procDate
        '
        Me.procDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.procDate.FillWeight = 20.0!
        Me.procDate.HeaderText = "Date"
        Me.procDate.MinimumWidth = 20
        Me.procDate.Name = "procDate"
        Me.procDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'procdesc
        '
        Me.procdesc.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.procdesc.FillWeight = 80.0!
        Me.procdesc.HeaderText = "Description"
        Me.procdesc.Name = "procdesc"
        Me.procdesc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'spref_horizsys_Zone
        '
        Me.spref_horizsys_Zone.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.spref_horizsys_Zone.FormattingEnabled = True
        Me.spref_horizsys_Zone.Location = New System.Drawing.Point(122, 36)
        Me.spref_horizsys_Zone.Name = "spref_horizsys_Zone"
        Me.spref_horizsys_Zone.Size = New System.Drawing.Size(201, 21)
        Me.spref_horizsys_Zone.TabIndex = 5
        '
        'spref_horizsys_Zone_____help
        '
        Me.spref_horizsys_Zone_____help.AutoSize = True
        Me.spref_horizsys_Zone_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.spref_horizsys_Zone_____help.Location = New System.Drawing.Point(14, 39)
        Me.spref_horizsys_Zone_____help.Name = "spref_horizsys_Zone_____help"
        Me.spref_horizsys_Zone_____help.Size = New System.Drawing.Size(102, 13)
        Me.spref_horizsys_Zone_____help.TabIndex = 4
        Me.spref_horizsys_Zone_____help.TabStop = True
        Me.spref_horizsys_Zone_____help.Text = "Zone (if applicable):"
        '
        'spref_horizsys_CoordinateSystem
        '
        Me.spref_horizsys_CoordinateSystem.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.spref_horizsys_CoordinateSystem.FormattingEnabled = True
        Me.spref_horizsys_CoordinateSystem.Location = New System.Drawing.Point(78, 11)
        Me.spref_horizsys_CoordinateSystem.Name = "spref_horizsys_CoordinateSystem"
        Me.spref_horizsys_CoordinateSystem.Size = New System.Drawing.Size(206, 21)
        Me.spref_horizsys_CoordinateSystem.TabIndex = 3
        '
        'spref_horizsys_CoordinateSystem_____help
        '
        Me.spref_horizsys_CoordinateSystem_____help.AutoSize = True
        Me.spref_horizsys_CoordinateSystem_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.spref_horizsys_CoordinateSystem_____help.Location = New System.Drawing.Point(13, 14)
        Me.spref_horizsys_CoordinateSystem_____help.Name = "spref_horizsys_CoordinateSystem_____help"
        Me.spref_horizsys_CoordinateSystem_____help.Size = New System.Drawing.Size(59, 13)
        Me.spref_horizsys_CoordinateSystem_____help.TabIndex = 2
        Me.spref_horizsys_CoordinateSystem_____help.TabStop = True
        Me.spref_horizsys_CoordinateSystem_____help.Text = "Projection:"
        '
        'Panel12
        '
        Me.Panel12.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel12.Controls.Add(Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____warning)
        Me.Panel12.Controls.Add(Me.dataqual_posacc_vertacc_qvertpa_vertacce_____warning)
        Me.Panel12.Controls.Add(Me.Label60)
        Me.Panel12.Controls.Add(Me.Label59)
        Me.Panel12.Controls.Add(Me.dataqual_posacc_vertacc_qvertpa_vertacce)
        Me.Panel12.Controls.Add(Me.dataqual_posacc_vertacc_qvertpa_vertacce_____help)
        Me.Panel12.Controls.Add(Me.Label14)
        Me.Panel12.Controls.Add(Me.dataqual_posacc_vertacc_qvertpa_vertaccv)
        Me.Panel12.Controls.Add(Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____help)
        Me.Panel12.Location = New System.Drawing.Point(6, 228)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(432, 29)
        Me.Panel12.TabIndex = 6
        '
        'dataqual_posacc_vertacc_qvertpa_vertaccv_____warning
        '
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____warning.Location = New System.Drawing.Point(58, 9)
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____warning.Name = "dataqual_posacc_vertacc_qvertpa_vertaccv_____warning"
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____warning.Size = New System.Drawing.Size(13, 14)
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____warning.TabIndex = 48
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____warning.TabStop = False
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____warning.Visible = False
        '
        'dataqual_posacc_vertacc_qvertpa_vertacce_____warning
        '
        Me.dataqual_posacc_vertacc_qvertpa_vertacce_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_posacc_vertacc_qvertpa_vertacce_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_posacc_vertacc_qvertpa_vertacce_____warning.Location = New System.Drawing.Point(220, 7)
        Me.dataqual_posacc_vertacc_qvertpa_vertacce_____warning.Name = "dataqual_posacc_vertacc_qvertpa_vertacce_____warning"
        Me.dataqual_posacc_vertacc_qvertpa_vertacce_____warning.Size = New System.Drawing.Size(13, 14)
        Me.dataqual_posacc_vertacc_qvertpa_vertacce_____warning.TabIndex = 47
        Me.dataqual_posacc_vertacc_qvertpa_vertacce_____warning.TabStop = False
        Me.dataqual_posacc_vertacc_qvertpa_vertacce_____warning.Visible = False
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label60.ForeColor = System.Drawing.Color.Black
        Me.Label60.Location = New System.Drawing.Point(151, 8)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(19, 13)
        Me.Label60.TabIndex = 26
        Me.Label60.Text = "**"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label59.ForeColor = System.Drawing.Color.Black
        Me.Label59.Location = New System.Drawing.Point(8, 9)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(19, 13)
        Me.Label59.TabIndex = 27
        Me.Label59.Text = "**"
        '
        'dataqual_posacc_vertacc_qvertpa_vertacce
        '
        Me.dataqual_posacc_vertacc_qvertpa_vertacce.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dataqual_posacc_vertacc_qvertpa_vertacce.Location = New System.Drawing.Point(231, 3)
        Me.dataqual_posacc_vertacc_qvertpa_vertacce.Name = "dataqual_posacc_vertacc_qvertpa_vertacce"
        Me.dataqual_posacc_vertacc_qvertpa_vertacce.Size = New System.Drawing.Size(198, 21)
        Me.dataqual_posacc_vertacc_qvertpa_vertacce.TabIndex = 4
        '
        'dataqual_posacc_vertacc_qvertpa_vertacce_____help
        '
        Me.dataqual_posacc_vertacc_qvertpa_vertacce_____help.AutoSize = True
        Me.dataqual_posacc_vertacc_qvertpa_vertacce_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dataqual_posacc_vertacc_qvertpa_vertacce_____help.Location = New System.Drawing.Point(167, 7)
        Me.dataqual_posacc_vertacc_qvertpa_vertacce_____help.Name = "dataqual_posacc_vertacc_qvertpa_vertacce_____help"
        Me.dataqual_posacc_vertacc_qvertpa_vertacce_____help.Size = New System.Drawing.Size(58, 13)
        Me.dataqual_posacc_vertacc_qvertpa_vertacce_____help.TabIndex = 3
        Me.dataqual_posacc_vertacc_qvertpa_vertacce_____help.TabStop = True
        Me.dataqual_posacc_vertacc_qvertpa_vertacce_____help.Text = "Test used:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(112, 6)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(23, 13)
        Me.Label14.TabIndex = 2
        Me.Label14.Text = "(m)"
        '
        'dataqual_posacc_vertacc_qvertpa_vertaccv
        '
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv.Location = New System.Drawing.Point(69, 3)
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv.Name = "dataqual_posacc_vertacc_qvertpa_vertaccv"
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv.Size = New System.Drawing.Size(42, 21)
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv.TabIndex = 1
        '
        'dataqual_posacc_vertacc_qvertpa_vertaccv_____help
        '
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____help.AutoSize = True
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____help.Location = New System.Drawing.Point(25, 7)
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____help.Name = "dataqual_posacc_vertacc_qvertpa_vertaccv_____help"
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____help.Size = New System.Drawing.Size(37, 13)
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____help.TabIndex = 0
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____help.TabStop = True
        Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____help.Text = "Value:"
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.dataqual_____warning)
        Me.GroupBox10.Controls.Add(Me.Panel12)
        Me.GroupBox10.Controls.Add(Me.Panel11)
        Me.GroupBox10.Controls.Add(Me.Panel13)
        Me.GroupBox10.Controls.Add(Me.Panel9)
        Me.GroupBox10.Controls.Add(Me.Panel10)
        Me.GroupBox10.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox10.ForeColor = System.Drawing.Color.Black
        Me.GroupBox10.Location = New System.Drawing.Point(6, 6)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(443, 264)
        Me.GroupBox10.TabIndex = 0
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "Quality"
        '
        'dataqual_____warning
        '
        Me.dataqual_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_____warning.Location = New System.Drawing.Point(50, 0)
        Me.dataqual_____warning.Name = "dataqual_____warning"
        Me.dataqual_____warning.Size = New System.Drawing.Size(13, 14)
        Me.dataqual_____warning.TabIndex = 43
        Me.dataqual_____warning.TabStop = False
        Me.dataqual_____warning.Visible = False
        '
        'Panel11
        '
        Me.Panel11.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel11.Controls.Add(Me.dataqual_posacc_horizpa_qhorizpa_horizpae_____warning)
        Me.Panel11.Controls.Add(Me.dataqual_posacc_horizpa_qhorizpa_horizpav_____warning)
        Me.Panel11.Controls.Add(Me.Label55)
        Me.Panel11.Controls.Add(Me.Label54)
        Me.Panel11.Controls.Add(Me.dataqual_posacc_horizpa_qhorizpa_horizpae)
        Me.Panel11.Controls.Add(Me.dataqual_posacc_horizpa_qhorizpa_horizpae_____help)
        Me.Panel11.Controls.Add(Me.Label13)
        Me.Panel11.Controls.Add(Me.dataqual_posacc_horizpa_qhorizpa_horizpav)
        Me.Panel11.Controls.Add(Me.dataqual_posacc_horizpa_qhorizpa_horizpav_____help)
        Me.Panel11.Location = New System.Drawing.Point(6, 128)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(432, 30)
        Me.Panel11.TabIndex = 3
        '
        'dataqual_posacc_horizpa_qhorizpa_horizpae_____warning
        '
        Me.dataqual_posacc_horizpa_qhorizpa_horizpae_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_posacc_horizpa_qhorizpa_horizpae_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_posacc_horizpa_qhorizpa_horizpae_____warning.Location = New System.Drawing.Point(220, 11)
        Me.dataqual_posacc_horizpa_qhorizpa_horizpae_____warning.Name = "dataqual_posacc_horizpa_qhorizpa_horizpae_____warning"
        Me.dataqual_posacc_horizpa_qhorizpa_horizpae_____warning.Size = New System.Drawing.Size(13, 14)
        Me.dataqual_posacc_horizpa_qhorizpa_horizpae_____warning.TabIndex = 47
        Me.dataqual_posacc_horizpa_qhorizpa_horizpae_____warning.TabStop = False
        Me.dataqual_posacc_horizpa_qhorizpa_horizpae_____warning.Visible = False
        '
        'dataqual_posacc_horizpa_qhorizpa_horizpav_____warning
        '
        Me.dataqual_posacc_horizpa_qhorizpa_horizpav_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_posacc_horizpa_qhorizpa_horizpav_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_posacc_horizpa_qhorizpa_horizpav_____warning.Location = New System.Drawing.Point(55, 10)
        Me.dataqual_posacc_horizpa_qhorizpa_horizpav_____warning.Name = "dataqual_posacc_horizpa_qhorizpa_horizpav_____warning"
        Me.dataqual_posacc_horizpa_qhorizpa_horizpav_____warning.Size = New System.Drawing.Size(13, 14)
        Me.dataqual_posacc_horizpa_qhorizpa_horizpav_____warning.TabIndex = 46
        Me.dataqual_posacc_horizpa_qhorizpa_horizpav_____warning.TabStop = False
        Me.dataqual_posacc_horizpa_qhorizpa_horizpav_____warning.Visible = False
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label55.ForeColor = System.Drawing.Color.Black
        Me.Label55.Location = New System.Drawing.Point(151, 11)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(19, 13)
        Me.Label55.TabIndex = 25
        Me.Label55.Text = "**"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label54.ForeColor = System.Drawing.Color.Black
        Me.Label54.Location = New System.Drawing.Point(8, 10)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(19, 13)
        Me.Label54.TabIndex = 18
        Me.Label54.Text = "**"
        '
        'dataqual_posacc_horizpa_qhorizpa_horizpae
        '
        Me.dataqual_posacc_horizpa_qhorizpa_horizpae.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dataqual_posacc_horizpa_qhorizpa_horizpae.Location = New System.Drawing.Point(231, 4)
        Me.dataqual_posacc_horizpa_qhorizpa_horizpae.Name = "dataqual_posacc_horizpa_qhorizpa_horizpae"
        Me.dataqual_posacc_horizpa_qhorizpa_horizpae.Size = New System.Drawing.Size(198, 21)
        Me.dataqual_posacc_horizpa_qhorizpa_horizpae.TabIndex = 4
        '
        'dataqual_posacc_horizpa_qhorizpa_horizpae_____help
        '
        Me.dataqual_posacc_horizpa_qhorizpa_horizpae_____help.AutoSize = True
        Me.dataqual_posacc_horizpa_qhorizpa_horizpae_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dataqual_posacc_horizpa_qhorizpa_horizpae_____help.Location = New System.Drawing.Point(167, 10)
        Me.dataqual_posacc_horizpa_qhorizpa_horizpae_____help.Name = "dataqual_posacc_horizpa_qhorizpa_horizpae_____help"
        Me.dataqual_posacc_horizpa_qhorizpa_horizpae_____help.Size = New System.Drawing.Size(58, 13)
        Me.dataqual_posacc_horizpa_qhorizpa_horizpae_____help.TabIndex = 3
        Me.dataqual_posacc_horizpa_qhorizpa_horizpae_____help.TabStop = True
        Me.dataqual_posacc_horizpa_qhorizpa_horizpae_____help.Text = "Test used:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(113, 10)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(23, 13)
        Me.Label13.TabIndex = 2
        Me.Label13.Text = "(m)"
        '
        'dataqual_posacc_horizpa_qhorizpa_horizpav
        '
        Me.dataqual_posacc_horizpa_qhorizpa_horizpav.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dataqual_posacc_horizpa_qhorizpa_horizpav.Location = New System.Drawing.Point(66, 4)
        Me.dataqual_posacc_horizpa_qhorizpa_horizpav.Name = "dataqual_posacc_horizpa_qhorizpa_horizpav"
        Me.dataqual_posacc_horizpa_qhorizpa_horizpav.Size = New System.Drawing.Size(42, 21)
        Me.dataqual_posacc_horizpa_qhorizpa_horizpav.TabIndex = 1
        '
        'dataqual_posacc_horizpa_qhorizpa_horizpav_____help
        '
        Me.dataqual_posacc_horizpa_qhorizpa_horizpav_____help.AutoSize = True
        Me.dataqual_posacc_horizpa_qhorizpa_horizpav_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dataqual_posacc_horizpa_qhorizpa_horizpav_____help.Location = New System.Drawing.Point(24, 10)
        Me.dataqual_posacc_horizpa_qhorizpa_horizpav_____help.Name = "dataqual_posacc_horizpa_qhorizpa_horizpav_____help"
        Me.dataqual_posacc_horizpa_qhorizpa_horizpav_____help.Size = New System.Drawing.Size(37, 13)
        Me.dataqual_posacc_horizpa_qhorizpa_horizpav_____help.TabIndex = 0
        Me.dataqual_posacc_horizpa_qhorizpa_horizpav_____help.TabStop = True
        Me.dataqual_posacc_horizpa_qhorizpa_horizpav_____help.Text = "Value:"
        '
        'Panel13
        '
        Me.Panel13.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel13.Controls.Add(Me.dataqual_posacc_vertacc_____warning)
        Me.Panel13.Controls.Add(Me.dataqual_posacc_vertacc_vertaccr_____warning)
        Me.Panel13.Controls.Add(Me.Label57)
        Me.Panel13.Controls.Add(Me.dataqual_posacc_vertacc_vertaccr)
        Me.Panel13.Controls.Add(Me.dataqual_posacc_vertacc_vertaccr_____help)
        Me.Panel13.Controls.Add(Me.Label15)
        Me.Panel13.Location = New System.Drawing.Point(6, 164)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(432, 58)
        Me.Panel13.TabIndex = 5
        '
        'dataqual_posacc_vertacc_____warning
        '
        Me.dataqual_posacc_vertacc_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_posacc_vertacc_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_posacc_vertacc_____warning.Location = New System.Drawing.Point(167, 0)
        Me.dataqual_posacc_vertacc_____warning.Name = "dataqual_posacc_vertacc_____warning"
        Me.dataqual_posacc_vertacc_____warning.Size = New System.Drawing.Size(13, 14)
        Me.dataqual_posacc_vertacc_____warning.TabIndex = 48
        Me.dataqual_posacc_vertacc_____warning.TabStop = False
        Me.dataqual_posacc_vertacc_____warning.Visible = False
        '
        'dataqual_posacc_vertacc_vertaccr_____warning
        '
        Me.dataqual_posacc_vertacc_vertaccr_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_posacc_vertacc_vertaccr_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.dataqual_posacc_vertacc_vertaccr_____warning.Location = New System.Drawing.Point(58, 27)
        Me.dataqual_posacc_vertacc_vertaccr_____warning.Name = "dataqual_posacc_vertacc_vertaccr_____warning"
        Me.dataqual_posacc_vertacc_vertaccr_____warning.Size = New System.Drawing.Size(13, 14)
        Me.dataqual_posacc_vertacc_vertaccr_____warning.TabIndex = 47
        Me.dataqual_posacc_vertacc_vertaccr_____warning.TabStop = False
        Me.dataqual_posacc_vertacc_vertaccr_____warning.Visible = False
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label57.ForeColor = System.Drawing.Color.Black
        Me.Label57.Location = New System.Drawing.Point(8, 27)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(19, 13)
        Me.Label57.TabIndex = 26
        Me.Label57.Text = "**"
        '
        'dataqual_posacc_vertacc_vertaccr
        '
        Me.dataqual_posacc_vertacc_vertaccr.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dataqual_posacc_vertacc_vertaccr.Location = New System.Drawing.Point(70, 12)
        Me.dataqual_posacc_vertacc_vertaccr.Multiline = True
        Me.dataqual_posacc_vertacc_vertaccr.Name = "dataqual_posacc_vertacc_vertaccr"
        Me.dataqual_posacc_vertacc_vertaccr.Size = New System.Drawing.Size(359, 41)
        Me.dataqual_posacc_vertacc_vertaccr.TabIndex = 3
        '
        'dataqual_posacc_vertacc_vertaccr_____help
        '
        Me.dataqual_posacc_vertacc_vertaccr_____help.AutoSize = True
        Me.dataqual_posacc_vertacc_vertaccr_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dataqual_posacc_vertacc_vertaccr_____help.Location = New System.Drawing.Point(24, 26)
        Me.dataqual_posacc_vertacc_vertaccr_____help.Name = "dataqual_posacc_vertacc_vertaccr_____help"
        Me.dataqual_posacc_vertacc_vertaccr_____help.Size = New System.Drawing.Size(44, 13)
        Me.dataqual_posacc_vertacc_vertaccr_____help.TabIndex = 2
        Me.dataqual_posacc_vertacc_vertaccr_____help.TabStop = True
        Me.dataqual_posacc_vertacc_vertaccr_____help.Text = "Report:"
        '
        'eainfo_overview_eadetcit_____default
        '
        Me.eainfo_overview_eadetcit_____default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.eainfo_overview_eadetcit_____default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.eainfo_overview_eadetcit_____default.Location = New System.Drawing.Point(285, 0)
        Me.eainfo_overview_eadetcit_____default.Name = "eainfo_overview_eadetcit_____default"
        Me.eainfo_overview_eadetcit_____default.Size = New System.Drawing.Size(33, 23)
        Me.eainfo_overview_eadetcit_____default.TabIndex = 23
        Me.eainfo_overview_eadetcit_____default.Text = "D"
        Me.eainfo_overview_eadetcit_____default.UseVisualStyleBackColor = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.ForeColor = System.Drawing.Color.Black
        Me.Label16.Location = New System.Drawing.Point(13, -3)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(65, 13)
        Me.Label16.TabIndex = 1
        Me.Label16.Text = "Horizontal"
        '
        'spref_horizsys_Datum
        '
        Me.spref_horizsys_Datum.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.spref_horizsys_Datum.FormattingEnabled = True
        Me.spref_horizsys_Datum.Location = New System.Drawing.Point(223, 61)
        Me.spref_horizsys_Datum.Name = "spref_horizsys_Datum"
        Me.spref_horizsys_Datum.Size = New System.Drawing.Size(100, 21)
        Me.spref_horizsys_Datum.TabIndex = 9
        '
        'spref_horizsys_Datum_____help
        '
        Me.spref_horizsys_Datum_____help.AutoSize = True
        Me.spref_horizsys_Datum_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.spref_horizsys_Datum_____help.Location = New System.Drawing.Point(175, 64)
        Me.spref_horizsys_Datum_____help.Name = "spref_horizsys_Datum_____help"
        Me.spref_horizsys_Datum_____help.Size = New System.Drawing.Size(42, 13)
        Me.spref_horizsys_Datum_____help.TabIndex = 8
        Me.spref_horizsys_Datum_____help.TabStop = True
        Me.spref_horizsys_Datum_____help.Text = "Datum:"
        '
        'spref_horizsys_Units_____help
        '
        Me.spref_horizsys_Units_____help.AutoSize = True
        Me.spref_horizsys_Units_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.spref_horizsys_Units_____help.Location = New System.Drawing.Point(14, 64)
        Me.spref_horizsys_Units_____help.Name = "spref_horizsys_Units_____help"
        Me.spref_horizsys_Units_____help.Size = New System.Drawing.Size(35, 13)
        Me.spref_horizsys_Units_____help.TabIndex = 6
        Me.spref_horizsys_Units_____help.TabStop = True
        Me.spref_horizsys_Units_____help.Text = "Units:"
        '
        'Panel14
        '
        Me.Panel14.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel14.Controls.Add(Me.spref_horizsys_Datum_____warning)
        Me.Panel14.Controls.Add(Me.spref_horizsys_Units_____warning)
        Me.Panel14.Controls.Add(Me.spref_horizsys_Zone_____warning)
        Me.Panel14.Controls.Add(Me.spref_horizsys_____warning)
        Me.Panel14.Controls.Add(Me.spref_horizsys_CoordinateSystem_____warning)
        Me.Panel14.Controls.Add(Me.spref_horizsys_____default)
        Me.Panel14.Controls.Add(Me.spref_horizsys_Units)
        Me.Panel14.Controls.Add(Me.Label65)
        Me.Panel14.Controls.Add(Me.Label64)
        Me.Panel14.Controls.Add(Me.Label63)
        Me.Panel14.Controls.Add(Me.Label62)
        Me.Panel14.Controls.Add(Me.spref_horizsys_Datum)
        Me.Panel14.Controls.Add(Me.spref_horizsys_Datum_____help)
        Me.Panel14.Controls.Add(Me.spref_horizsys_Units_____help)
        Me.Panel14.Controls.Add(Me.spref_horizsys_Zone)
        Me.Panel14.Controls.Add(Me.spref_horizsys_Zone_____help)
        Me.Panel14.Controls.Add(Me.spref_horizsys_CoordinateSystem)
        Me.Panel14.Controls.Add(Me.spref_horizsys_CoordinateSystem_____help)
        Me.Panel14.Controls.Add(Me.Label16)
        Me.Panel14.Location = New System.Drawing.Point(6, 18)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(332, 90)
        Me.Panel14.TabIndex = 4
        '
        'spref_horizsys_Datum_____warning
        '
        Me.spref_horizsys_Datum_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.spref_horizsys_Datum_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.spref_horizsys_Datum_____warning.Location = New System.Drawing.Point(208, 64)
        Me.spref_horizsys_Datum_____warning.Name = "spref_horizsys_Datum_____warning"
        Me.spref_horizsys_Datum_____warning.Size = New System.Drawing.Size(13, 14)
        Me.spref_horizsys_Datum_____warning.TabIndex = 49
        Me.spref_horizsys_Datum_____warning.TabStop = False
        Me.spref_horizsys_Datum_____warning.Visible = False
        '
        'spref_horizsys_Units_____warning
        '
        Me.spref_horizsys_Units_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.spref_horizsys_Units_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.spref_horizsys_Units_____warning.Location = New System.Drawing.Point(41, 64)
        Me.spref_horizsys_Units_____warning.Name = "spref_horizsys_Units_____warning"
        Me.spref_horizsys_Units_____warning.Size = New System.Drawing.Size(13, 14)
        Me.spref_horizsys_Units_____warning.TabIndex = 48
        Me.spref_horizsys_Units_____warning.TabStop = False
        Me.spref_horizsys_Units_____warning.Visible = False
        '
        'spref_horizsys_Zone_____warning
        '
        Me.spref_horizsys_Zone_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.spref_horizsys_Zone_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.spref_horizsys_Zone_____warning.Location = New System.Drawing.Point(110, 39)
        Me.spref_horizsys_Zone_____warning.Name = "spref_horizsys_Zone_____warning"
        Me.spref_horizsys_Zone_____warning.Size = New System.Drawing.Size(13, 14)
        Me.spref_horizsys_Zone_____warning.TabIndex = 47
        Me.spref_horizsys_Zone_____warning.TabStop = False
        Me.spref_horizsys_Zone_____warning.Visible = False
        '
        'spref_horizsys_____warning
        '
        Me.spref_horizsys_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.spref_horizsys_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.spref_horizsys_____warning.Location = New System.Drawing.Point(78, 0)
        Me.spref_horizsys_____warning.Name = "spref_horizsys_____warning"
        Me.spref_horizsys_____warning.Size = New System.Drawing.Size(13, 14)
        Me.spref_horizsys_____warning.TabIndex = 46
        Me.spref_horizsys_____warning.TabStop = False
        Me.spref_horizsys_____warning.Visible = False
        '
        'spref_horizsys_CoordinateSystem_____warning
        '
        Me.spref_horizsys_CoordinateSystem_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.spref_horizsys_CoordinateSystem_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.spref_horizsys_CoordinateSystem_____warning.Location = New System.Drawing.Point(67, 14)
        Me.spref_horizsys_CoordinateSystem_____warning.Name = "spref_horizsys_CoordinateSystem_____warning"
        Me.spref_horizsys_CoordinateSystem_____warning.Size = New System.Drawing.Size(13, 14)
        Me.spref_horizsys_CoordinateSystem_____warning.TabIndex = 45
        Me.spref_horizsys_CoordinateSystem_____warning.TabStop = False
        Me.spref_horizsys_CoordinateSystem_____warning.Visible = False
        '
        'spref_horizsys_____default
        '
        Me.spref_horizsys_____default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.spref_horizsys_____default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.spref_horizsys_____default.Location = New System.Drawing.Point(290, 11)
        Me.spref_horizsys_____default.Name = "spref_horizsys_____default"
        Me.spref_horizsys_____default.Size = New System.Drawing.Size(33, 23)
        Me.spref_horizsys_____default.TabIndex = 22
        Me.spref_horizsys_____default.Text = "D"
        Me.spref_horizsys_____default.UseVisualStyleBackColor = False
        '
        'spref_horizsys_Units
        '
        Me.spref_horizsys_Units.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.spref_horizsys_Units.FormattingEnabled = True
        Me.spref_horizsys_Units.Location = New System.Drawing.Point(55, 61)
        Me.spref_horizsys_Units.Name = "spref_horizsys_Units"
        Me.spref_horizsys_Units.Size = New System.Drawing.Size(104, 21)
        Me.spref_horizsys_Units.TabIndex = 21
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label65.ForeColor = System.Drawing.Color.Black
        Me.Label65.Location = New System.Drawing.Point(165, 64)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(13, 13)
        Me.Label65.TabIndex = 20
        Me.Label65.Text = "*"
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label64.ForeColor = System.Drawing.Color.Black
        Me.Label64.Location = New System.Drawing.Point(4, 64)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(13, 13)
        Me.Label64.TabIndex = 19
        Me.Label64.Text = "*"
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label63.ForeColor = System.Drawing.Color.Black
        Me.Label63.Location = New System.Drawing.Point(4, 39)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(13, 13)
        Me.Label63.TabIndex = 18
        Me.Label63.Text = "*"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label62.ForeColor = System.Drawing.Color.Black
        Me.Label62.Location = New System.Drawing.Point(3, 14)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(13, 13)
        Me.Label62.TabIndex = 17
        Me.Label62.Text = "*"
        '
        'Panel18
        '
        Me.Panel18.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel18.Controls.Add(Me.distinfo_distliab_____warning)
        Me.Panel18.Controls.Add(Me.distinfo_distliab_____help)
        Me.Panel18.Controls.Add(Me.distinfo_distliab_____default)
        Me.Panel18.Controls.Add(Me.Label76)
        Me.Panel18.Controls.Add(Me.distinfo_distliab)
        Me.Panel18.Location = New System.Drawing.Point(6, 140)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(369, 125)
        Me.Panel18.TabIndex = 22
        '
        'distinfo_distliab_____warning
        '
        Me.distinfo_distliab_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.distinfo_distliab_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.distinfo_distliab_____warning.Location = New System.Drawing.Point(118, 6)
        Me.distinfo_distliab_____warning.Name = "distinfo_distliab_____warning"
        Me.distinfo_distliab_____warning.Size = New System.Drawing.Size(13, 14)
        Me.distinfo_distliab_____warning.TabIndex = 35
        Me.distinfo_distliab_____warning.TabStop = False
        Me.distinfo_distliab_____warning.Visible = False
        '
        'distinfo_distliab_____help
        '
        Me.distinfo_distliab_____help.AutoSize = True
        Me.distinfo_distliab_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.distinfo_distliab_____help.Location = New System.Drawing.Point(18, 6)
        Me.distinfo_distliab_____help.Name = "distinfo_distliab_____help"
        Me.distinfo_distliab_____help.Size = New System.Drawing.Size(99, 13)
        Me.distinfo_distliab_____help.TabIndex = 36
        Me.distinfo_distliab_____help.TabStop = True
        Me.distinfo_distliab_____help.Text = "Distribution Liability"
        '
        'distinfo_distliab_____default
        '
        Me.distinfo_distliab_____default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.distinfo_distliab_____default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.distinfo_distliab_____default.Location = New System.Drawing.Point(333, 1)
        Me.distinfo_distliab_____default.Name = "distinfo_distliab_____default"
        Me.distinfo_distliab_____default.Size = New System.Drawing.Size(33, 23)
        Me.distinfo_distliab_____default.TabIndex = 23
        Me.distinfo_distliab_____default.Text = "D"
        Me.distinfo_distliab_____default.UseVisualStyleBackColor = False
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label76.ForeColor = System.Drawing.Color.Black
        Me.Label76.Location = New System.Drawing.Point(8, 6)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(13, 13)
        Me.Label76.TabIndex = 22
        Me.Label76.Text = "*"
        '
        'distinfo_distliab
        '
        Me.distinfo_distliab.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.distinfo_distliab.Location = New System.Drawing.Point(6, 26)
        Me.distinfo_distliab.Multiline = True
        Me.distinfo_distliab.Name = "distinfo_distliab"
        Me.distinfo_distliab.Size = New System.Drawing.Size(360, 91)
        Me.distinfo_distliab.TabIndex = 2
        '
        'GroupBox14
        '
        Me.GroupBox14.Controls.Add(Me.Panel17)
        Me.GroupBox14.Controls.Add(Me.Panel16)
        Me.GroupBox14.Controls.Add(Me.distinfo_____warning)
        Me.GroupBox14.Controls.Add(Me.Panel18)
        Me.GroupBox14.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox14.ForeColor = System.Drawing.Color.Black
        Me.GroupBox14.Location = New System.Drawing.Point(6, 6)
        Me.GroupBox14.Name = "GroupBox14"
        Me.GroupBox14.Size = New System.Drawing.Size(381, 271)
        Me.GroupBox14.TabIndex = 20
        Me.GroupBox14.TabStop = False
        Me.GroupBox14.Text = "Distribution Information"
        '
        'Panel17
        '
        Me.Panel17.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel17.Controls.Add(Me.distinfo_resdesc_____warning)
        Me.Panel17.Controls.Add(Me.distinfo_resdesc_____default)
        Me.Panel17.Controls.Add(Me.Label75)
        Me.Panel17.Controls.Add(Me.distinfo_resdesc_____help)
        Me.Panel17.Controls.Add(Me.distinfo_resdesc)
        Me.Panel17.Controls.Add(Me.Label19)
        Me.Panel17.Location = New System.Drawing.Point(6, 89)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(369, 45)
        Me.Panel17.TabIndex = 21
        '
        'distinfo_resdesc_____warning
        '
        Me.distinfo_resdesc_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.distinfo_resdesc_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.distinfo_resdesc_____warning.Location = New System.Drawing.Point(135, 0)
        Me.distinfo_resdesc_____warning.Name = "distinfo_resdesc_____warning"
        Me.distinfo_resdesc_____warning.Size = New System.Drawing.Size(13, 14)
        Me.distinfo_resdesc_____warning.TabIndex = 34
        Me.distinfo_resdesc_____warning.TabStop = False
        Me.distinfo_resdesc_____warning.Visible = False
        '
        'distinfo_resdesc_____default
        '
        Me.distinfo_resdesc_____default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.distinfo_resdesc_____default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.distinfo_resdesc_____default.Location = New System.Drawing.Point(333, 15)
        Me.distinfo_resdesc_____default.Name = "distinfo_resdesc_____default"
        Me.distinfo_resdesc_____default.Size = New System.Drawing.Size(33, 23)
        Me.distinfo_resdesc_____default.TabIndex = 23
        Me.distinfo_resdesc_____default.Text = "D"
        Me.distinfo_resdesc_____default.UseVisualStyleBackColor = False
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label75.ForeColor = System.Drawing.Color.Black
        Me.Label75.Location = New System.Drawing.Point(8, 20)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(13, 13)
        Me.Label75.TabIndex = 22
        Me.Label75.Text = "*"
        '
        'distinfo_resdesc_____help
        '
        Me.distinfo_resdesc_____help.AutoSize = True
        Me.distinfo_resdesc_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.distinfo_resdesc_____help.Location = New System.Drawing.Point(18, 20)
        Me.distinfo_resdesc_____help.Name = "distinfo_resdesc_____help"
        Me.distinfo_resdesc_____help.Size = New System.Drawing.Size(92, 13)
        Me.distinfo_resdesc_____help.TabIndex = 18
        Me.distinfo_resdesc_____help.TabStop = True
        Me.distinfo_resdesc_____help.Text = "Type of data set?"
        '
        'distinfo_resdesc
        '
        Me.distinfo_resdesc.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.distinfo_resdesc.FormattingEnabled = True
        Me.distinfo_resdesc.Location = New System.Drawing.Point(110, 17)
        Me.distinfo_resdesc.Name = "distinfo_resdesc"
        Me.distinfo_resdesc.Size = New System.Drawing.Size(220, 21)
        Me.distinfo_resdesc.TabIndex = 17
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.ForeColor = System.Drawing.Color.Black
        Me.Label19.Location = New System.Drawing.Point(17, -3)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(121, 13)
        Me.Label19.TabIndex = 1
        Me.Label19.Text = "Data Resource Type"
        '
        'Panel16
        '
        Me.Panel16.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel16.Controls.Add(Me.distinfo_distrib_____warning)
        Me.Panel16.Controls.Add(Me.distinfo_distrib_____help)
        Me.Panel16.Controls.Add(Me.Label74)
        Me.Panel16.Controls.Add(Me.distinfo_distrib)
        Me.Panel16.Controls.Add(Me.distinfo_distrib_____default)
        Me.Panel16.Controls.Add(Me.distinfo_distrib_cntinfo_cntorgp)
        Me.Panel16.Controls.Add(Me.distinfo_distrib_cntinfo_cntperp)
        Me.Panel16.Location = New System.Drawing.Point(6, 20)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(369, 63)
        Me.Panel16.TabIndex = 18
        '
        'distinfo_distrib_____warning
        '
        Me.distinfo_distrib_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.distinfo_distrib_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.distinfo_distrib_____warning.Location = New System.Drawing.Point(135, 0)
        Me.distinfo_distrib_____warning.Name = "distinfo_distrib_____warning"
        Me.distinfo_distrib_____warning.Size = New System.Drawing.Size(13, 14)
        Me.distinfo_distrib_____warning.TabIndex = 33
        Me.distinfo_distrib_____warning.TabStop = False
        Me.distinfo_distrib_____warning.Visible = False
        '
        'distinfo_distrib_____help
        '
        Me.distinfo_distrib_____help.AutoSize = True
        Me.distinfo_distrib_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.distinfo_distrib_____help.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.distinfo_distrib_____help.Location = New System.Drawing.Point(18, -3)
        Me.distinfo_distrib_____help.Name = "distinfo_distrib_____help"
        Me.distinfo_distrib_____help.Size = New System.Drawing.Size(120, 13)
        Me.distinfo_distrib_____help.TabIndex = 47
        Me.distinfo_distrib_____help.TabStop = True
        Me.distinfo_distrib_____help.Text = "Distribution Contact"
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label74.ForeColor = System.Drawing.Color.Black
        Me.Label74.Location = New System.Drawing.Point(8, -1)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(13, 13)
        Me.Label74.TabIndex = 21
        Me.Label74.Text = "*"
        '
        'distinfo_distrib
        '
        Me.distinfo_distrib.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.distinfo_distrib.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.distinfo_distrib.FormattingEnabled = True
        Me.distinfo_distrib.Location = New System.Drawing.Point(6, 36)
        Me.distinfo_distrib.Name = "distinfo_distrib"
        Me.distinfo_distrib.Size = New System.Drawing.Size(324, 21)
        Me.distinfo_distrib.TabIndex = 17
        '
        'distinfo_distrib_____default
        '
        Me.distinfo_distrib_____default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.distinfo_distrib_____default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.distinfo_distrib_____default.Location = New System.Drawing.Point(333, 34)
        Me.distinfo_distrib_____default.Name = "distinfo_distrib_____default"
        Me.distinfo_distrib_____default.Size = New System.Drawing.Size(33, 23)
        Me.distinfo_distrib_____default.TabIndex = 19
        Me.distinfo_distrib_____default.Text = "D"
        Me.distinfo_distrib_____default.UseVisualStyleBackColor = False
        '
        'distinfo_distrib_cntinfo_cntorgp
        '
        Me.distinfo_distrib_cntinfo_cntorgp.AutoSize = True
        Me.distinfo_distrib_cntinfo_cntorgp.Checked = True
        Me.distinfo_distrib_cntinfo_cntorgp.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.distinfo_distrib_cntinfo_cntorgp.Location = New System.Drawing.Point(118, 13)
        Me.distinfo_distrib_cntinfo_cntorgp.Name = "distinfo_distrib_cntinfo_cntorgp"
        Me.distinfo_distrib_cntinfo_cntorgp.Size = New System.Drawing.Size(125, 17)
        Me.distinfo_distrib_cntinfo_cntorgp.TabIndex = 15
        Me.distinfo_distrib_cntinfo_cntorgp.TabStop = True
        Me.distinfo_distrib_cntinfo_cntorgp.Text = "Primary Organization"
        Me.distinfo_distrib_cntinfo_cntorgp.UseVisualStyleBackColor = True
        '
        'distinfo_distrib_cntinfo_cntperp
        '
        Me.distinfo_distrib_cntinfo_cntperp.AutoSize = True
        Me.distinfo_distrib_cntinfo_cntperp.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.distinfo_distrib_cntinfo_cntperp.Location = New System.Drawing.Point(6, 13)
        Me.distinfo_distrib_cntinfo_cntperp.Name = "distinfo_distrib_cntinfo_cntperp"
        Me.distinfo_distrib_cntinfo_cntperp.Size = New System.Drawing.Size(97, 17)
        Me.distinfo_distrib_cntinfo_cntperp.TabIndex = 14
        Me.distinfo_distrib_cntinfo_cntperp.TabStop = True
        Me.distinfo_distrib_cntinfo_cntperp.Text = "Primary Person"
        Me.distinfo_distrib_cntinfo_cntperp.UseVisualStyleBackColor = True
        '
        'distinfo_____warning
        '
        Me.distinfo_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.distinfo_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.distinfo_____warning.Location = New System.Drawing.Point(147, 0)
        Me.distinfo_____warning.Name = "distinfo_____warning"
        Me.distinfo_____warning.Size = New System.Drawing.Size(13, 14)
        Me.distinfo_____warning.TabIndex = 32
        Me.distinfo_____warning.TabStop = False
        Me.distinfo_____warning.Visible = False
        '
        'metainfo_metfrd
        '
        Me.metainfo_metfrd.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.metainfo_metfrd.Location = New System.Drawing.Point(179, 38)
        Me.metainfo_metfrd.Name = "metainfo_metfrd"
        Me.metainfo_metfrd.Size = New System.Drawing.Size(60, 21)
        Me.metainfo_metfrd.TabIndex = 22
        Me.metainfo_metfrd.Text = "YYYYMMDD"
        '
        'metainfo_metd
        '
        Me.metainfo_metd.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.metainfo_metd.Location = New System.Drawing.Point(112, 9)
        Me.metainfo_metd.Name = "metainfo_metd"
        Me.metainfo_metd.Size = New System.Drawing.Size(60, 21)
        Me.metainfo_metd.TabIndex = 2
        Me.metainfo_metd.Text = "YYYYMMDD"
        '
        'btnMetaFRDate4yrs
        '
        Me.btnMetaFRDate4yrs.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.btnMetaFRDate4yrs.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMetaFRDate4yrs.Location = New System.Drawing.Point(246, 36)
        Me.btnMetaFRDate4yrs.Name = "btnMetaFRDate4yrs"
        Me.btnMetaFRDate4yrs.Size = New System.Drawing.Size(54, 23)
        Me.btnMetaFRDate4yrs.TabIndex = 21
        Me.btnMetaFRDate4yrs.Text = "4 yrs"
        Me.btnMetaFRDate4yrs.UseVisualStyleBackColor = False
        '
        'metainfo_metfrd_____help
        '
        Me.metainfo_metfrd_____help.AutoSize = True
        Me.metainfo_metfrd_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.metainfo_metfrd_____help.Location = New System.Drawing.Point(16, 42)
        Me.metainfo_metfrd_____help.Name = "metainfo_metfrd_____help"
        Me.metainfo_metfrd_____help.Size = New System.Drawing.Size(156, 13)
        Me.metainfo_metfrd_____help.TabIndex = 1
        Me.metainfo_metfrd_____help.TabStop = True
        Me.metainfo_metfrd_____help.Text = "Metadata Future Review Date:"
        '
        'metainfo_metd_____help
        '
        Me.metainfo_metd_____help.AutoSize = True
        Me.metainfo_metd_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.metainfo_metd_____help.Location = New System.Drawing.Point(16, 13)
        Me.metainfo_metd_____help.Name = "metainfo_metd_____help"
        Me.metainfo_metd_____help.Size = New System.Drawing.Size(83, 13)
        Me.metainfo_metd_____help.TabIndex = 0
        Me.metainfo_metd_____help.TabStop = True
        Me.metainfo_metd_____help.Text = "Metadata Date:"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.ForeColor = System.Drawing.Color.Blue
        Me.Label24.Location = New System.Drawing.Point(-345, -105)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(106, 13)
        Me.Label24.TabIndex = 20
        Me.Label24.Text = "Data Resource Type"
        '
        'ComboBox22
        '
        Me.ComboBox22.FormattingEnabled = True
        Me.ComboBox22.Location = New System.Drawing.Point(-190, -85)
        Me.ComboBox22.Name = "ComboBox22"
        Me.ComboBox22.Size = New System.Drawing.Size(183, 21)
        Me.ComboBox22.TabIndex = 30
        '
        'LinkLabel37
        '
        Me.LinkLabel37.AutoSize = True
        Me.LinkLabel37.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel37.Location = New System.Drawing.Point(-345, -82)
        Me.LinkLabel37.Name = "LinkLabel37"
        Me.LinkLabel37.Size = New System.Drawing.Size(149, 13)
        Me.LinkLabel37.TabIndex = 31
        Me.LinkLabel37.TabStop = True
        Me.LinkLabel37.Text = "What type of data set is this?"
        '
        'Panel21
        '
        Me.Panel21.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel21.Controls.Add(Me.metainfo_metstdv_____warning)
        Me.Panel21.Controls.Add(Me.metainfo_metstdn_____warning)
        Me.Panel21.Controls.Add(Me.Button99)
        Me.Panel21.Controls.Add(Me.Label81)
        Me.Panel21.Controls.Add(Me.Label80)
        Me.Panel21.Controls.Add(Me.metainfo_metstdv)
        Me.Panel21.Controls.Add(Me.metainfo_metstdn)
        Me.Panel21.Controls.Add(Me.metainfo_metstdv_____help)
        Me.Panel21.Controls.Add(Me.metainfo_metstdn_____help)
        Me.Panel21.Controls.Add(Me.Label23)
        Me.Panel21.Location = New System.Drawing.Point(7, 177)
        Me.Panel21.Name = "Panel21"
        Me.Panel21.Size = New System.Drawing.Size(383, 75)
        Me.Panel21.TabIndex = 22
        '
        'metainfo_metstdv_____warning
        '
        Me.metainfo_metstdv_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.metainfo_metstdv_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.metainfo_metstdv_____warning.Location = New System.Drawing.Point(97, 47)
        Me.metainfo_metstdv_____warning.Name = "metainfo_metstdv_____warning"
        Me.metainfo_metstdv_____warning.Size = New System.Drawing.Size(13, 14)
        Me.metainfo_metstdv_____warning.TabIndex = 38
        Me.metainfo_metstdv_____warning.TabStop = False
        Me.metainfo_metstdv_____warning.Visible = False
        '
        'metainfo_metstdn_____warning
        '
        Me.metainfo_metstdn_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.metainfo_metstdn_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.metainfo_metstdn_____warning.Location = New System.Drawing.Point(93, 20)
        Me.metainfo_metstdn_____warning.Name = "metainfo_metstdn_____warning"
        Me.metainfo_metstdn_____warning.Size = New System.Drawing.Size(13, 14)
        Me.metainfo_metstdn_____warning.TabIndex = 37
        Me.metainfo_metstdn_____warning.TabStop = False
        Me.metainfo_metstdn_____warning.Visible = False
        '
        'Button99
        '
        Me.Button99.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Button99.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button99.Location = New System.Drawing.Point(342, 44)
        Me.Button99.Name = "Button99"
        Me.Button99.Size = New System.Drawing.Size(33, 23)
        Me.Button99.TabIndex = 24
        Me.Button99.Text = "D"
        Me.Button99.UseVisualStyleBackColor = False
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label81.ForeColor = System.Drawing.Color.Black
        Me.Label81.Location = New System.Drawing.Point(3, 47)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(13, 13)
        Me.Label81.TabIndex = 23
        Me.Label81.Text = "*"
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label80.ForeColor = System.Drawing.Color.Black
        Me.Label80.Location = New System.Drawing.Point(3, 20)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(13, 13)
        Me.Label80.TabIndex = 22
        Me.Label80.Text = "*"
        '
        'metainfo_metstdv
        '
        Me.metainfo_metstdv.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.metainfo_metstdv.Location = New System.Drawing.Point(111, 44)
        Me.metainfo_metstdv.Name = "metainfo_metstdv"
        Me.metainfo_metstdv.Size = New System.Drawing.Size(174, 21)
        Me.metainfo_metstdv.TabIndex = 21
        Me.metainfo_metstdv.Text = "FGDC-STD-001-1998"
        '
        'metainfo_metstdn
        '
        Me.metainfo_metstdn.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.metainfo_metstdn.Location = New System.Drawing.Point(104, 17)
        Me.metainfo_metstdn.Name = "metainfo_metstdn"
        Me.metainfo_metstdn.Size = New System.Drawing.Size(271, 21)
        Me.metainfo_metstdn.TabIndex = 20
        Me.metainfo_metstdn.Text = "FGDC Content Standard for Digitial Geospatial Metadata"
        '
        'metainfo_metstdv_____help
        '
        Me.metainfo_metstdv_____help.AutoSize = True
        Me.metainfo_metstdv_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.metainfo_metstdv_____help.Location = New System.Drawing.Point(13, 47)
        Me.metainfo_metstdv_____help.Name = "metainfo_metstdv_____help"
        Me.metainfo_metstdv_____help.Size = New System.Drawing.Size(93, 13)
        Me.metainfo_metstdv_____help.TabIndex = 19
        Me.metainfo_metstdv_____help.TabStop = True
        Me.metainfo_metstdv_____help.Text = "Standard Version:"
        '
        'metainfo_metstdn_____help
        '
        Me.metainfo_metstdn_____help.AutoSize = True
        Me.metainfo_metstdn_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.metainfo_metstdn_____help.Location = New System.Drawing.Point(13, 20)
        Me.metainfo_metstdn_____help.Name = "metainfo_metstdn_____help"
        Me.metainfo_metstdn_____help.Size = New System.Drawing.Size(85, 13)
        Me.metainfo_metstdn_____help.TabIndex = 18
        Me.metainfo_metstdn_____help.TabStop = True
        Me.metainfo_metstdn_____help.Text = "Standard Name:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.ForeColor = System.Drawing.Color.Black
        Me.Label23.Location = New System.Drawing.Point(12, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(117, 13)
        Me.Label23.TabIndex = 1
        Me.Label23.Text = "Metadata Standard"
        '
        'Panel20
        '
        Me.Panel20.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel20.Controls.Add(Me.metainfo_metc_____warning)
        Me.Panel20.Controls.Add(Me.metainfo_metc_____help)
        Me.Panel20.Controls.Add(Me.Label79)
        Me.Panel20.Controls.Add(Me.metainfo_metc)
        Me.Panel20.Controls.Add(Me.metainfo_metc_____default)
        Me.Panel20.Controls.Add(Me.metainfo_metc_cntinfo_cntorgp)
        Me.Panel20.Controls.Add(Me.metainfo_metc_cntinfo_cntperp)
        Me.Panel20.Location = New System.Drawing.Point(6, 96)
        Me.Panel20.Name = "Panel20"
        Me.Panel20.Size = New System.Drawing.Size(383, 69)
        Me.Panel20.TabIndex = 22
        '
        'metainfo_metc_____warning
        '
        Me.metainfo_metc_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.metainfo_metc_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.metainfo_metc_____warning.Location = New System.Drawing.Point(121, -1)
        Me.metainfo_metc_____warning.Name = "metainfo_metc_____warning"
        Me.metainfo_metc_____warning.Size = New System.Drawing.Size(13, 14)
        Me.metainfo_metc_____warning.TabIndex = 36
        Me.metainfo_metc_____warning.TabStop = False
        Me.metainfo_metc_____warning.Visible = False
        '
        'metainfo_metc_____help
        '
        Me.metainfo_metc_____help.AutoSize = True
        Me.metainfo_metc_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.metainfo_metc_____help.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.metainfo_metc_____help.Location = New System.Drawing.Point(13, -1)
        Me.metainfo_metc_____help.Name = "metainfo_metc_____help"
        Me.metainfo_metc_____help.Size = New System.Drawing.Size(109, 13)
        Me.metainfo_metc_____help.TabIndex = 48
        Me.metainfo_metc_____help.TabStop = True
        Me.metainfo_metc_____help.Text = "Metadata Contact"
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label79.ForeColor = System.Drawing.Color.Black
        Me.Label79.Location = New System.Drawing.Point(3, -1)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(13, 13)
        Me.Label79.TabIndex = 26
        Me.Label79.Text = "*"
        '
        'metainfo_metc
        '
        Me.metainfo_metc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.metainfo_metc.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.metainfo_metc.FormattingEnabled = True
        Me.metainfo_metc.Location = New System.Drawing.Point(6, 40)
        Me.metainfo_metc.Name = "metainfo_metc"
        Me.metainfo_metc.Size = New System.Drawing.Size(331, 21)
        Me.metainfo_metc.TabIndex = 23
        '
        'metainfo_metc_____default
        '
        Me.metainfo_metc_____default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.metainfo_metc_____default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.metainfo_metc_____default.Location = New System.Drawing.Point(343, 38)
        Me.metainfo_metc_____default.Name = "metainfo_metc_____default"
        Me.metainfo_metc_____default.Size = New System.Drawing.Size(33, 23)
        Me.metainfo_metc_____default.TabIndex = 24
        Me.metainfo_metc_____default.Text = "D"
        Me.metainfo_metc_____default.UseVisualStyleBackColor = False
        '
        'metainfo_metc_cntinfo_cntorgp
        '
        Me.metainfo_metc_cntinfo_cntorgp.AutoSize = True
        Me.metainfo_metc_cntinfo_cntorgp.Checked = True
        Me.metainfo_metc_cntinfo_cntorgp.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.metainfo_metc_cntinfo_cntorgp.Location = New System.Drawing.Point(118, 17)
        Me.metainfo_metc_cntinfo_cntorgp.Name = "metainfo_metc_cntinfo_cntorgp"
        Me.metainfo_metc_cntinfo_cntorgp.Size = New System.Drawing.Size(125, 17)
        Me.metainfo_metc_cntinfo_cntorgp.TabIndex = 22
        Me.metainfo_metc_cntinfo_cntorgp.TabStop = True
        Me.metainfo_metc_cntinfo_cntorgp.Text = "Primary Organization"
        Me.metainfo_metc_cntinfo_cntorgp.UseVisualStyleBackColor = True
        '
        'metainfo_metc_cntinfo_cntperp
        '
        Me.metainfo_metc_cntinfo_cntperp.AutoSize = True
        Me.metainfo_metc_cntinfo_cntperp.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.metainfo_metc_cntinfo_cntperp.Location = New System.Drawing.Point(6, 17)
        Me.metainfo_metc_cntinfo_cntperp.Name = "metainfo_metc_cntinfo_cntperp"
        Me.metainfo_metc_cntinfo_cntperp.Size = New System.Drawing.Size(97, 17)
        Me.metainfo_metc_cntinfo_cntperp.TabIndex = 21
        Me.metainfo_metc_cntinfo_cntperp.TabStop = True
        Me.metainfo_metc_cntinfo_cntperp.Text = "Primary Person"
        Me.metainfo_metc_cntinfo_cntperp.UseVisualStyleBackColor = True
        '
        'GroupBox17
        '
        Me.GroupBox17.Controls.Add(Me.metainfo_____warning)
        Me.GroupBox17.Controls.Add(Me.Panel21)
        Me.GroupBox17.Controls.Add(Me.Panel20)
        Me.GroupBox17.Controls.Add(Me.Panel19)
        Me.GroupBox17.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox17.ForeColor = System.Drawing.Color.Black
        Me.GroupBox17.Location = New System.Drawing.Point(393, 6)
        Me.GroupBox17.Name = "GroupBox17"
        Me.GroupBox17.Size = New System.Drawing.Size(396, 271)
        Me.GroupBox17.TabIndex = 21
        Me.GroupBox17.TabStop = False
        Me.GroupBox17.Text = "Metadata Information"
        '
        'metainfo_____warning
        '
        Me.metainfo_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.metainfo_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.metainfo_____warning.Location = New System.Drawing.Point(137, 0)
        Me.metainfo_____warning.Name = "metainfo_____warning"
        Me.metainfo_____warning.Size = New System.Drawing.Size(13, 14)
        Me.metainfo_____warning.TabIndex = 31
        Me.metainfo_____warning.TabStop = False
        Me.metainfo_____warning.Visible = False
        '
        'Panel19
        '
        Me.Panel19.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel19.Controls.Add(Me.metainfo_metfrd_____warning)
        Me.Panel19.Controls.Add(Me.metainfo_metd_____warning)
        Me.Panel19.Controls.Add(Me.metainfo_metd_____today)
        Me.Panel19.Controls.Add(Me.Label78)
        Me.Panel19.Controls.Add(Me.Label77)
        Me.Panel19.Controls.Add(Me.metainfo_metfrd)
        Me.Panel19.Controls.Add(Me.metainfo_metd)
        Me.Panel19.Controls.Add(Me.btnMetaFRDate4yrs)
        Me.Panel19.Controls.Add(Me.metainfo_metfrd_____help)
        Me.Panel19.Controls.Add(Me.metainfo_metd_____help)
        Me.Panel19.Location = New System.Drawing.Point(6, 20)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(384, 63)
        Me.Panel19.TabIndex = 0
        '
        'metainfo_metfrd_____warning
        '
        Me.metainfo_metfrd_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.metainfo_metfrd_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.metainfo_metfrd_____warning.Location = New System.Drawing.Point(167, 42)
        Me.metainfo_metfrd_____warning.Name = "metainfo_metfrd_____warning"
        Me.metainfo_metfrd_____warning.Size = New System.Drawing.Size(13, 14)
        Me.metainfo_metfrd_____warning.TabIndex = 31
        Me.metainfo_metfrd_____warning.TabStop = False
        Me.metainfo_metfrd_____warning.Visible = False
        '
        'metainfo_metd_____warning
        '
        Me.metainfo_metd_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.metainfo_metd_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.metainfo_metd_____warning.Location = New System.Drawing.Point(98, 15)
        Me.metainfo_metd_____warning.Name = "metainfo_metd_____warning"
        Me.metainfo_metd_____warning.Size = New System.Drawing.Size(13, 14)
        Me.metainfo_metd_____warning.TabIndex = 30
        Me.metainfo_metd_____warning.TabStop = False
        Me.metainfo_metd_____warning.Visible = False
        '
        'metainfo_metd_____today
        '
        Me.metainfo_metd_____today.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.metainfo_metd_____today.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.metainfo_metd_____today.Location = New System.Drawing.Point(178, 7)
        Me.metainfo_metd_____today.Name = "metainfo_metd_____today"
        Me.metainfo_metd_____today.Size = New System.Drawing.Size(54, 23)
        Me.metainfo_metd_____today.TabIndex = 29
        Me.metainfo_metd_____today.Text = "today"
        Me.metainfo_metd_____today.UseVisualStyleBackColor = False
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label78.ForeColor = System.Drawing.Color.Black
        Me.Label78.Location = New System.Drawing.Point(4, 42)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(13, 13)
        Me.Label78.TabIndex = 28
        Me.Label78.Text = "*"
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label77.ForeColor = System.Drawing.Color.Black
        Me.Label77.Location = New System.Drawing.Point(4, 13)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(13, 13)
        Me.Label77.TabIndex = 27
        Me.Label77.Text = "*"
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.GroupBox17)
        Me.TabPage3.Controls.Add(Me.GroupBox14)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(806, 518)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Distribution & Metadata Information"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Controls.Add(Me.GroupBox4)
        Me.TabPage1.Controls.Add(Me.GroupBox7)
        Me.TabPage1.Controls.Add(Me.GroupBox6)
        Me.TabPage1.Controls.Add(Me.GroupBox5)
        Me.TabPage1.Controls.Add(Me.GroupBox3)
        Me.TabPage1.Controls.Add(Me.GroupBox2)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(806, 518)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Basic Data Set Information"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.idinfo_citation_____warning)
        Me.GroupBox1.Controls.Add(Me.Panel23)
        Me.GroupBox1.Controls.Add(Me.Panel22)
        Me.GroupBox1.Controls.Add(Me.Panel1)
        Me.GroupBox1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.Black
        Me.GroupBox1.Location = New System.Drawing.Point(6, 5)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(458, 231)
        Me.GroupBox1.TabIndex = 7
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Citation"
        '
        'idinfo_citation_____warning
        '
        Me.idinfo_citation_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_____warning.Location = New System.Drawing.Point(52, 0)
        Me.idinfo_citation_____warning.Name = "idinfo_citation_____warning"
        Me.idinfo_citation_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_citation_____warning.TabIndex = 35
        Me.idinfo_citation_____warning.TabStop = False
        Me.idinfo_citation_____warning.Visible = False
        '
        'Panel23
        '
        Me.Panel23.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel23.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel23.Controls.Add(Me.btnMoreLinkages)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_10_)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_9_)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_10______default)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_9______default)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_10______check)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_9______check)
        Me.Panel23.Controls.Add(Me.Label18)
        Me.Panel23.Controls.Add(Me.Label20)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_9______help)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_10______help)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_8_)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_7_)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_8______default)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_7______default)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_8______check)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_7______check)
        Me.Panel23.Controls.Add(Me.Label21)
        Me.Panel23.Controls.Add(Me.Label43)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_7______help)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_8______help)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_6_)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_5_)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_6______default)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_5______default)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_6______check)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_5______check)
        Me.Panel23.Controls.Add(Me.Label45)
        Me.Panel23.Controls.Add(Me.Label46)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_5______help)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_6______help)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_4_)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_3_)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_4______default)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_3______default)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_4______check)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_3______check)
        Me.Panel23.Controls.Add(Me.Label47)
        Me.Panel23.Controls.Add(Me.Label48)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_3______help)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_4______help)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_2_)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_1_)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_2______default)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_1______default)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_____warning)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_2______check)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_1______check)
        Me.Panel23.Controls.Add(Me.Label44)
        Me.Panel23.Controls.Add(Me.Label33)
        Me.Panel23.Controls.Add(Me.Label26)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_1______help)
        Me.Panel23.Controls.Add(Me.idinfo_citation_citeinfo_onlink_2______help)
        Me.Panel23.Location = New System.Drawing.Point(6, 156)
        Me.Panel23.Name = "Panel23"
        Me.Panel23.Size = New System.Drawing.Size(446, 69)
        Me.Panel23.TabIndex = 23
        '
        'btnMoreLinkages
        '
        Me.btnMoreLinkages.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.btnMoreLinkages.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMoreLinkages.Image = Global.MetadataEditor.My.Resources.Resources.plus
        Me.btnMoreLinkages.Location = New System.Drawing.Point(430, 0)
        Me.btnMoreLinkages.Name = "btnMoreLinkages"
        Me.btnMoreLinkages.Size = New System.Drawing.Size(16, 16)
        Me.btnMoreLinkages.TabIndex = 44
        Me.btnMoreLinkages.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.HoverToolTip.SetToolTip(Me.btnMoreLinkages, "More linkages...")
        Me.btnMoreLinkages.UseVisualStyleBackColor = False
        '
        'idinfo_citation_citeinfo_onlink_10_
        '
        Me.idinfo_citation_citeinfo_onlink_10_.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_onlink_10_.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append
        Me.idinfo_citation_citeinfo_onlink_10_.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.idinfo_citation_citeinfo_onlink_10_.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_10_.FormattingEnabled = True
        Me.idinfo_citation_citeinfo_onlink_10_.Location = New System.Drawing.Point(120, 260)
        Me.idinfo_citation_citeinfo_onlink_10_.Name = "idinfo_citation_citeinfo_onlink_10_"
        Me.idinfo_citation_citeinfo_onlink_10_.Size = New System.Drawing.Size(258, 21)
        Me.idinfo_citation_citeinfo_onlink_10_.TabIndex = 129
        '
        'idinfo_citation_citeinfo_onlink_9_
        '
        Me.idinfo_citation_citeinfo_onlink_9_.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_onlink_9_.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append
        Me.idinfo_citation_citeinfo_onlink_9_.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.idinfo_citation_citeinfo_onlink_9_.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_9_.FormattingEnabled = True
        Me.idinfo_citation_citeinfo_onlink_9_.Location = New System.Drawing.Point(120, 233)
        Me.idinfo_citation_citeinfo_onlink_9_.Name = "idinfo_citation_citeinfo_onlink_9_"
        Me.idinfo_citation_citeinfo_onlink_9_.Size = New System.Drawing.Size(258, 21)
        Me.idinfo_citation_citeinfo_onlink_9_.TabIndex = 128
        '
        'idinfo_citation_citeinfo_onlink_10______default
        '
        Me.idinfo_citation_citeinfo_onlink_10______default.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_onlink_10______default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.idinfo_citation_citeinfo_onlink_10______default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_10______default.Location = New System.Drawing.Point(384, 258)
        Me.idinfo_citation_citeinfo_onlink_10______default.Name = "idinfo_citation_citeinfo_onlink_10______default"
        Me.idinfo_citation_citeinfo_onlink_10______default.Size = New System.Drawing.Size(33, 23)
        Me.idinfo_citation_citeinfo_onlink_10______default.TabIndex = 127
        Me.idinfo_citation_citeinfo_onlink_10______default.Text = "D"
        Me.idinfo_citation_citeinfo_onlink_10______default.UseVisualStyleBackColor = False
        '
        'idinfo_citation_citeinfo_onlink_9______default
        '
        Me.idinfo_citation_citeinfo_onlink_9______default.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_onlink_9______default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.idinfo_citation_citeinfo_onlink_9______default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_9______default.Location = New System.Drawing.Point(384, 231)
        Me.idinfo_citation_citeinfo_onlink_9______default.Name = "idinfo_citation_citeinfo_onlink_9______default"
        Me.idinfo_citation_citeinfo_onlink_9______default.Size = New System.Drawing.Size(33, 23)
        Me.idinfo_citation_citeinfo_onlink_9______default.TabIndex = 126
        Me.idinfo_citation_citeinfo_onlink_9______default.Text = "D"
        Me.idinfo_citation_citeinfo_onlink_9______default.UseVisualStyleBackColor = False
        '
        'idinfo_citation_citeinfo_onlink_10______check
        '
        Me.idinfo_citation_citeinfo_onlink_10______check.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_onlink_10______check.AutoSize = True
        Me.idinfo_citation_citeinfo_onlink_10______check.FlatAppearance.BorderSize = 0
        Me.idinfo_citation_citeinfo_onlink_10______check.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.idinfo_citation_citeinfo_onlink_10______check.Image = CType(resources.GetObject("idinfo_citation_citeinfo_onlink_10______check.Image"), System.Drawing.Image)
        Me.idinfo_citation_citeinfo_onlink_10______check.Location = New System.Drawing.Point(419, 257)
        Me.idinfo_citation_citeinfo_onlink_10______check.Name = "idinfo_citation_citeinfo_onlink_10______check"
        Me.idinfo_citation_citeinfo_onlink_10______check.Size = New System.Drawing.Size(25, 24)
        Me.idinfo_citation_citeinfo_onlink_10______check.TabIndex = 125
        Me.idinfo_citation_citeinfo_onlink_10______check.UseVisualStyleBackColor = True
        '
        'idinfo_citation_citeinfo_onlink_9______check
        '
        Me.idinfo_citation_citeinfo_onlink_9______check.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_onlink_9______check.AutoSize = True
        Me.idinfo_citation_citeinfo_onlink_9______check.FlatAppearance.BorderSize = 0
        Me.idinfo_citation_citeinfo_onlink_9______check.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.idinfo_citation_citeinfo_onlink_9______check.Image = CType(resources.GetObject("idinfo_citation_citeinfo_onlink_9______check.Image"), System.Drawing.Image)
        Me.idinfo_citation_citeinfo_onlink_9______check.Location = New System.Drawing.Point(419, 230)
        Me.idinfo_citation_citeinfo_onlink_9______check.Name = "idinfo_citation_citeinfo_onlink_9______check"
        Me.idinfo_citation_citeinfo_onlink_9______check.Size = New System.Drawing.Size(25, 24)
        Me.idinfo_citation_citeinfo_onlink_9______check.TabIndex = 124
        Me.idinfo_citation_citeinfo_onlink_9______check.UseVisualStyleBackColor = True
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Black
        Me.Label18.Location = New System.Drawing.Point(3, 263)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(19, 13)
        Me.Label18.TabIndex = 123
        Me.Label18.Text = "**"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.Black
        Me.Label20.Location = New System.Drawing.Point(3, 236)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(19, 13)
        Me.Label20.TabIndex = 122
        Me.Label20.Text = "**"
        '
        'idinfo_citation_citeinfo_onlink_9______help
        '
        Me.idinfo_citation_citeinfo_onlink_9______help.AutoSize = True
        Me.idinfo_citation_citeinfo_onlink_9______help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_9______help.Location = New System.Drawing.Point(19, 235)
        Me.idinfo_citation_citeinfo_onlink_9______help.Name = "idinfo_citation_citeinfo_onlink_9______help"
        Me.idinfo_citation_citeinfo_onlink_9______help.Size = New System.Drawing.Size(56, 13)
        Me.idinfo_citation_citeinfo_onlink_9______help.TabIndex = 120
        Me.idinfo_citation_citeinfo_onlink_9______help.TabStop = True
        Me.idinfo_citation_citeinfo_onlink_9______help.Text = "Linkage 9:"
        '
        'idinfo_citation_citeinfo_onlink_10______help
        '
        Me.idinfo_citation_citeinfo_onlink_10______help.AutoSize = True
        Me.idinfo_citation_citeinfo_onlink_10______help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_10______help.Location = New System.Drawing.Point(19, 263)
        Me.idinfo_citation_citeinfo_onlink_10______help.Name = "idinfo_citation_citeinfo_onlink_10______help"
        Me.idinfo_citation_citeinfo_onlink_10______help.Size = New System.Drawing.Size(62, 13)
        Me.idinfo_citation_citeinfo_onlink_10______help.TabIndex = 121
        Me.idinfo_citation_citeinfo_onlink_10______help.TabStop = True
        Me.idinfo_citation_citeinfo_onlink_10______help.Text = "Linkage 10:"
        '
        'idinfo_citation_citeinfo_onlink_8_
        '
        Me.idinfo_citation_citeinfo_onlink_8_.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_onlink_8_.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append
        Me.idinfo_citation_citeinfo_onlink_8_.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.idinfo_citation_citeinfo_onlink_8_.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_8_.FormattingEnabled = True
        Me.idinfo_citation_citeinfo_onlink_8_.Location = New System.Drawing.Point(120, 206)
        Me.idinfo_citation_citeinfo_onlink_8_.Name = "idinfo_citation_citeinfo_onlink_8_"
        Me.idinfo_citation_citeinfo_onlink_8_.Size = New System.Drawing.Size(258, 21)
        Me.idinfo_citation_citeinfo_onlink_8_.TabIndex = 119
        '
        'idinfo_citation_citeinfo_onlink_7_
        '
        Me.idinfo_citation_citeinfo_onlink_7_.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_onlink_7_.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append
        Me.idinfo_citation_citeinfo_onlink_7_.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.idinfo_citation_citeinfo_onlink_7_.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_7_.FormattingEnabled = True
        Me.idinfo_citation_citeinfo_onlink_7_.Location = New System.Drawing.Point(120, 179)
        Me.idinfo_citation_citeinfo_onlink_7_.Name = "idinfo_citation_citeinfo_onlink_7_"
        Me.idinfo_citation_citeinfo_onlink_7_.Size = New System.Drawing.Size(258, 21)
        Me.idinfo_citation_citeinfo_onlink_7_.TabIndex = 118
        '
        'idinfo_citation_citeinfo_onlink_8______default
        '
        Me.idinfo_citation_citeinfo_onlink_8______default.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_onlink_8______default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.idinfo_citation_citeinfo_onlink_8______default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_8______default.Location = New System.Drawing.Point(384, 204)
        Me.idinfo_citation_citeinfo_onlink_8______default.Name = "idinfo_citation_citeinfo_onlink_8______default"
        Me.idinfo_citation_citeinfo_onlink_8______default.Size = New System.Drawing.Size(33, 23)
        Me.idinfo_citation_citeinfo_onlink_8______default.TabIndex = 117
        Me.idinfo_citation_citeinfo_onlink_8______default.Text = "D"
        Me.idinfo_citation_citeinfo_onlink_8______default.UseVisualStyleBackColor = False
        '
        'idinfo_citation_citeinfo_onlink_7______default
        '
        Me.idinfo_citation_citeinfo_onlink_7______default.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_onlink_7______default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.idinfo_citation_citeinfo_onlink_7______default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_7______default.Location = New System.Drawing.Point(384, 177)
        Me.idinfo_citation_citeinfo_onlink_7______default.Name = "idinfo_citation_citeinfo_onlink_7______default"
        Me.idinfo_citation_citeinfo_onlink_7______default.Size = New System.Drawing.Size(33, 23)
        Me.idinfo_citation_citeinfo_onlink_7______default.TabIndex = 116
        Me.idinfo_citation_citeinfo_onlink_7______default.Text = "D"
        Me.idinfo_citation_citeinfo_onlink_7______default.UseVisualStyleBackColor = False
        '
        'idinfo_citation_citeinfo_onlink_8______check
        '
        Me.idinfo_citation_citeinfo_onlink_8______check.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_onlink_8______check.AutoSize = True
        Me.idinfo_citation_citeinfo_onlink_8______check.FlatAppearance.BorderSize = 0
        Me.idinfo_citation_citeinfo_onlink_8______check.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.idinfo_citation_citeinfo_onlink_8______check.Image = CType(resources.GetObject("idinfo_citation_citeinfo_onlink_8______check.Image"), System.Drawing.Image)
        Me.idinfo_citation_citeinfo_onlink_8______check.Location = New System.Drawing.Point(419, 203)
        Me.idinfo_citation_citeinfo_onlink_8______check.Name = "idinfo_citation_citeinfo_onlink_8______check"
        Me.idinfo_citation_citeinfo_onlink_8______check.Size = New System.Drawing.Size(25, 24)
        Me.idinfo_citation_citeinfo_onlink_8______check.TabIndex = 115
        Me.idinfo_citation_citeinfo_onlink_8______check.UseVisualStyleBackColor = True
        '
        'idinfo_citation_citeinfo_onlink_7______check
        '
        Me.idinfo_citation_citeinfo_onlink_7______check.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_onlink_7______check.AutoSize = True
        Me.idinfo_citation_citeinfo_onlink_7______check.FlatAppearance.BorderSize = 0
        Me.idinfo_citation_citeinfo_onlink_7______check.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.idinfo_citation_citeinfo_onlink_7______check.Image = CType(resources.GetObject("idinfo_citation_citeinfo_onlink_7______check.Image"), System.Drawing.Image)
        Me.idinfo_citation_citeinfo_onlink_7______check.Location = New System.Drawing.Point(419, 176)
        Me.idinfo_citation_citeinfo_onlink_7______check.Name = "idinfo_citation_citeinfo_onlink_7______check"
        Me.idinfo_citation_citeinfo_onlink_7______check.Size = New System.Drawing.Size(25, 24)
        Me.idinfo_citation_citeinfo_onlink_7______check.TabIndex = 114
        Me.idinfo_citation_citeinfo_onlink_7______check.UseVisualStyleBackColor = True
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.Black
        Me.Label21.Location = New System.Drawing.Point(3, 209)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(19, 13)
        Me.Label21.TabIndex = 113
        Me.Label21.Text = "**"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.ForeColor = System.Drawing.Color.Black
        Me.Label43.Location = New System.Drawing.Point(3, 182)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(19, 13)
        Me.Label43.TabIndex = 112
        Me.Label43.Text = "**"
        '
        'idinfo_citation_citeinfo_onlink_7______help
        '
        Me.idinfo_citation_citeinfo_onlink_7______help.AutoSize = True
        Me.idinfo_citation_citeinfo_onlink_7______help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_7______help.Location = New System.Drawing.Point(19, 181)
        Me.idinfo_citation_citeinfo_onlink_7______help.Name = "idinfo_citation_citeinfo_onlink_7______help"
        Me.idinfo_citation_citeinfo_onlink_7______help.Size = New System.Drawing.Size(56, 13)
        Me.idinfo_citation_citeinfo_onlink_7______help.TabIndex = 110
        Me.idinfo_citation_citeinfo_onlink_7______help.TabStop = True
        Me.idinfo_citation_citeinfo_onlink_7______help.Text = "Linkage 7:"
        '
        'idinfo_citation_citeinfo_onlink_8______help
        '
        Me.idinfo_citation_citeinfo_onlink_8______help.AutoSize = True
        Me.idinfo_citation_citeinfo_onlink_8______help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_8______help.Location = New System.Drawing.Point(19, 209)
        Me.idinfo_citation_citeinfo_onlink_8______help.Name = "idinfo_citation_citeinfo_onlink_8______help"
        Me.idinfo_citation_citeinfo_onlink_8______help.Size = New System.Drawing.Size(56, 13)
        Me.idinfo_citation_citeinfo_onlink_8______help.TabIndex = 111
        Me.idinfo_citation_citeinfo_onlink_8______help.TabStop = True
        Me.idinfo_citation_citeinfo_onlink_8______help.Text = "Linkage 8:"
        '
        'idinfo_citation_citeinfo_onlink_6_
        '
        Me.idinfo_citation_citeinfo_onlink_6_.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_onlink_6_.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append
        Me.idinfo_citation_citeinfo_onlink_6_.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.idinfo_citation_citeinfo_onlink_6_.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_6_.FormattingEnabled = True
        Me.idinfo_citation_citeinfo_onlink_6_.Location = New System.Drawing.Point(120, 152)
        Me.idinfo_citation_citeinfo_onlink_6_.Name = "idinfo_citation_citeinfo_onlink_6_"
        Me.idinfo_citation_citeinfo_onlink_6_.Size = New System.Drawing.Size(258, 21)
        Me.idinfo_citation_citeinfo_onlink_6_.TabIndex = 109
        '
        'idinfo_citation_citeinfo_onlink_5_
        '
        Me.idinfo_citation_citeinfo_onlink_5_.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_onlink_5_.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append
        Me.idinfo_citation_citeinfo_onlink_5_.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.idinfo_citation_citeinfo_onlink_5_.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_5_.FormattingEnabled = True
        Me.idinfo_citation_citeinfo_onlink_5_.Location = New System.Drawing.Point(120, 125)
        Me.idinfo_citation_citeinfo_onlink_5_.Name = "idinfo_citation_citeinfo_onlink_5_"
        Me.idinfo_citation_citeinfo_onlink_5_.Size = New System.Drawing.Size(258, 21)
        Me.idinfo_citation_citeinfo_onlink_5_.TabIndex = 108
        '
        'idinfo_citation_citeinfo_onlink_6______default
        '
        Me.idinfo_citation_citeinfo_onlink_6______default.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_onlink_6______default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.idinfo_citation_citeinfo_onlink_6______default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_6______default.Location = New System.Drawing.Point(384, 150)
        Me.idinfo_citation_citeinfo_onlink_6______default.Name = "idinfo_citation_citeinfo_onlink_6______default"
        Me.idinfo_citation_citeinfo_onlink_6______default.Size = New System.Drawing.Size(33, 23)
        Me.idinfo_citation_citeinfo_onlink_6______default.TabIndex = 107
        Me.idinfo_citation_citeinfo_onlink_6______default.Text = "D"
        Me.idinfo_citation_citeinfo_onlink_6______default.UseVisualStyleBackColor = False
        '
        'idinfo_citation_citeinfo_onlink_5______default
        '
        Me.idinfo_citation_citeinfo_onlink_5______default.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_onlink_5______default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.idinfo_citation_citeinfo_onlink_5______default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_5______default.Location = New System.Drawing.Point(384, 123)
        Me.idinfo_citation_citeinfo_onlink_5______default.Name = "idinfo_citation_citeinfo_onlink_5______default"
        Me.idinfo_citation_citeinfo_onlink_5______default.Size = New System.Drawing.Size(33, 23)
        Me.idinfo_citation_citeinfo_onlink_5______default.TabIndex = 106
        Me.idinfo_citation_citeinfo_onlink_5______default.Text = "D"
        Me.idinfo_citation_citeinfo_onlink_5______default.UseVisualStyleBackColor = False
        '
        'idinfo_citation_citeinfo_onlink_6______check
        '
        Me.idinfo_citation_citeinfo_onlink_6______check.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_onlink_6______check.AutoSize = True
        Me.idinfo_citation_citeinfo_onlink_6______check.FlatAppearance.BorderSize = 0
        Me.idinfo_citation_citeinfo_onlink_6______check.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.idinfo_citation_citeinfo_onlink_6______check.Image = CType(resources.GetObject("idinfo_citation_citeinfo_onlink_6______check.Image"), System.Drawing.Image)
        Me.idinfo_citation_citeinfo_onlink_6______check.Location = New System.Drawing.Point(419, 149)
        Me.idinfo_citation_citeinfo_onlink_6______check.Name = "idinfo_citation_citeinfo_onlink_6______check"
        Me.idinfo_citation_citeinfo_onlink_6______check.Size = New System.Drawing.Size(25, 24)
        Me.idinfo_citation_citeinfo_onlink_6______check.TabIndex = 105
        Me.idinfo_citation_citeinfo_onlink_6______check.UseVisualStyleBackColor = True
        '
        'idinfo_citation_citeinfo_onlink_5______check
        '
        Me.idinfo_citation_citeinfo_onlink_5______check.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_onlink_5______check.AutoSize = True
        Me.idinfo_citation_citeinfo_onlink_5______check.FlatAppearance.BorderSize = 0
        Me.idinfo_citation_citeinfo_onlink_5______check.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.idinfo_citation_citeinfo_onlink_5______check.Image = CType(resources.GetObject("idinfo_citation_citeinfo_onlink_5______check.Image"), System.Drawing.Image)
        Me.idinfo_citation_citeinfo_onlink_5______check.Location = New System.Drawing.Point(419, 122)
        Me.idinfo_citation_citeinfo_onlink_5______check.Name = "idinfo_citation_citeinfo_onlink_5______check"
        Me.idinfo_citation_citeinfo_onlink_5______check.Size = New System.Drawing.Size(25, 24)
        Me.idinfo_citation_citeinfo_onlink_5______check.TabIndex = 104
        Me.idinfo_citation_citeinfo_onlink_5______check.UseVisualStyleBackColor = True
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.ForeColor = System.Drawing.Color.Black
        Me.Label45.Location = New System.Drawing.Point(3, 155)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(19, 13)
        Me.Label45.TabIndex = 103
        Me.Label45.Text = "**"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.ForeColor = System.Drawing.Color.Black
        Me.Label46.Location = New System.Drawing.Point(3, 128)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(19, 13)
        Me.Label46.TabIndex = 102
        Me.Label46.Text = "**"
        '
        'idinfo_citation_citeinfo_onlink_5______help
        '
        Me.idinfo_citation_citeinfo_onlink_5______help.AutoSize = True
        Me.idinfo_citation_citeinfo_onlink_5______help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_5______help.Location = New System.Drawing.Point(19, 127)
        Me.idinfo_citation_citeinfo_onlink_5______help.Name = "idinfo_citation_citeinfo_onlink_5______help"
        Me.idinfo_citation_citeinfo_onlink_5______help.Size = New System.Drawing.Size(56, 13)
        Me.idinfo_citation_citeinfo_onlink_5______help.TabIndex = 100
        Me.idinfo_citation_citeinfo_onlink_5______help.TabStop = True
        Me.idinfo_citation_citeinfo_onlink_5______help.Text = "Linkage 5:"
        '
        'idinfo_citation_citeinfo_onlink_6______help
        '
        Me.idinfo_citation_citeinfo_onlink_6______help.AutoSize = True
        Me.idinfo_citation_citeinfo_onlink_6______help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_6______help.Location = New System.Drawing.Point(19, 155)
        Me.idinfo_citation_citeinfo_onlink_6______help.Name = "idinfo_citation_citeinfo_onlink_6______help"
        Me.idinfo_citation_citeinfo_onlink_6______help.Size = New System.Drawing.Size(56, 13)
        Me.idinfo_citation_citeinfo_onlink_6______help.TabIndex = 101
        Me.idinfo_citation_citeinfo_onlink_6______help.TabStop = True
        Me.idinfo_citation_citeinfo_onlink_6______help.Text = "Linkage 6:"
        '
        'idinfo_citation_citeinfo_onlink_4_
        '
        Me.idinfo_citation_citeinfo_onlink_4_.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_onlink_4_.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append
        Me.idinfo_citation_citeinfo_onlink_4_.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.idinfo_citation_citeinfo_onlink_4_.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_4_.FormattingEnabled = True
        Me.idinfo_citation_citeinfo_onlink_4_.Location = New System.Drawing.Point(120, 98)
        Me.idinfo_citation_citeinfo_onlink_4_.Name = "idinfo_citation_citeinfo_onlink_4_"
        Me.idinfo_citation_citeinfo_onlink_4_.Size = New System.Drawing.Size(258, 21)
        Me.idinfo_citation_citeinfo_onlink_4_.TabIndex = 99
        '
        'idinfo_citation_citeinfo_onlink_3_
        '
        Me.idinfo_citation_citeinfo_onlink_3_.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_onlink_3_.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append
        Me.idinfo_citation_citeinfo_onlink_3_.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.idinfo_citation_citeinfo_onlink_3_.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_3_.FormattingEnabled = True
        Me.idinfo_citation_citeinfo_onlink_3_.Location = New System.Drawing.Point(120, 71)
        Me.idinfo_citation_citeinfo_onlink_3_.Name = "idinfo_citation_citeinfo_onlink_3_"
        Me.idinfo_citation_citeinfo_onlink_3_.Size = New System.Drawing.Size(258, 21)
        Me.idinfo_citation_citeinfo_onlink_3_.TabIndex = 98
        '
        'idinfo_citation_citeinfo_onlink_4______default
        '
        Me.idinfo_citation_citeinfo_onlink_4______default.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_onlink_4______default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.idinfo_citation_citeinfo_onlink_4______default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_4______default.Location = New System.Drawing.Point(384, 96)
        Me.idinfo_citation_citeinfo_onlink_4______default.Name = "idinfo_citation_citeinfo_onlink_4______default"
        Me.idinfo_citation_citeinfo_onlink_4______default.Size = New System.Drawing.Size(33, 23)
        Me.idinfo_citation_citeinfo_onlink_4______default.TabIndex = 97
        Me.idinfo_citation_citeinfo_onlink_4______default.Text = "D"
        Me.idinfo_citation_citeinfo_onlink_4______default.UseVisualStyleBackColor = False
        '
        'idinfo_citation_citeinfo_onlink_3______default
        '
        Me.idinfo_citation_citeinfo_onlink_3______default.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_onlink_3______default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.idinfo_citation_citeinfo_onlink_3______default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_3______default.Location = New System.Drawing.Point(384, 69)
        Me.idinfo_citation_citeinfo_onlink_3______default.Name = "idinfo_citation_citeinfo_onlink_3______default"
        Me.idinfo_citation_citeinfo_onlink_3______default.Size = New System.Drawing.Size(33, 23)
        Me.idinfo_citation_citeinfo_onlink_3______default.TabIndex = 96
        Me.idinfo_citation_citeinfo_onlink_3______default.Text = "D"
        Me.idinfo_citation_citeinfo_onlink_3______default.UseVisualStyleBackColor = False
        '
        'idinfo_citation_citeinfo_onlink_4______check
        '
        Me.idinfo_citation_citeinfo_onlink_4______check.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_onlink_4______check.AutoSize = True
        Me.idinfo_citation_citeinfo_onlink_4______check.FlatAppearance.BorderSize = 0
        Me.idinfo_citation_citeinfo_onlink_4______check.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.idinfo_citation_citeinfo_onlink_4______check.Image = CType(resources.GetObject("idinfo_citation_citeinfo_onlink_4______check.Image"), System.Drawing.Image)
        Me.idinfo_citation_citeinfo_onlink_4______check.Location = New System.Drawing.Point(419, 95)
        Me.idinfo_citation_citeinfo_onlink_4______check.Name = "idinfo_citation_citeinfo_onlink_4______check"
        Me.idinfo_citation_citeinfo_onlink_4______check.Size = New System.Drawing.Size(25, 24)
        Me.idinfo_citation_citeinfo_onlink_4______check.TabIndex = 95
        Me.idinfo_citation_citeinfo_onlink_4______check.UseVisualStyleBackColor = True
        '
        'idinfo_citation_citeinfo_onlink_3______check
        '
        Me.idinfo_citation_citeinfo_onlink_3______check.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_citation_citeinfo_onlink_3______check.AutoSize = True
        Me.idinfo_citation_citeinfo_onlink_3______check.FlatAppearance.BorderSize = 0
        Me.idinfo_citation_citeinfo_onlink_3______check.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.idinfo_citation_citeinfo_onlink_3______check.Image = CType(resources.GetObject("idinfo_citation_citeinfo_onlink_3______check.Image"), System.Drawing.Image)
        Me.idinfo_citation_citeinfo_onlink_3______check.Location = New System.Drawing.Point(419, 68)
        Me.idinfo_citation_citeinfo_onlink_3______check.Name = "idinfo_citation_citeinfo_onlink_3______check"
        Me.idinfo_citation_citeinfo_onlink_3______check.Size = New System.Drawing.Size(25, 24)
        Me.idinfo_citation_citeinfo_onlink_3______check.TabIndex = 94
        Me.idinfo_citation_citeinfo_onlink_3______check.UseVisualStyleBackColor = True
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.ForeColor = System.Drawing.Color.Black
        Me.Label47.Location = New System.Drawing.Point(3, 101)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(19, 13)
        Me.Label47.TabIndex = 93
        Me.Label47.Text = "**"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.ForeColor = System.Drawing.Color.Black
        Me.Label48.Location = New System.Drawing.Point(3, 74)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(19, 13)
        Me.Label48.TabIndex = 92
        Me.Label48.Text = "**"
        '
        'idinfo_citation_citeinfo_onlink_3______help
        '
        Me.idinfo_citation_citeinfo_onlink_3______help.AutoSize = True
        Me.idinfo_citation_citeinfo_onlink_3______help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_3______help.Location = New System.Drawing.Point(19, 73)
        Me.idinfo_citation_citeinfo_onlink_3______help.Name = "idinfo_citation_citeinfo_onlink_3______help"
        Me.idinfo_citation_citeinfo_onlink_3______help.Size = New System.Drawing.Size(56, 13)
        Me.idinfo_citation_citeinfo_onlink_3______help.TabIndex = 90
        Me.idinfo_citation_citeinfo_onlink_3______help.TabStop = True
        Me.idinfo_citation_citeinfo_onlink_3______help.Text = "Linkage 3:"
        '
        'idinfo_citation_citeinfo_onlink_4______help
        '
        Me.idinfo_citation_citeinfo_onlink_4______help.AutoSize = True
        Me.idinfo_citation_citeinfo_onlink_4______help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_4______help.Location = New System.Drawing.Point(19, 101)
        Me.idinfo_citation_citeinfo_onlink_4______help.Name = "idinfo_citation_citeinfo_onlink_4______help"
        Me.idinfo_citation_citeinfo_onlink_4______help.Size = New System.Drawing.Size(56, 13)
        Me.idinfo_citation_citeinfo_onlink_4______help.TabIndex = 91
        Me.idinfo_citation_citeinfo_onlink_4______help.TabStop = True
        Me.idinfo_citation_citeinfo_onlink_4______help.Text = "Linkage 4:"
        '
        'idinfo_citation_citeinfo_onlink_2_
        '
        Me.idinfo_citation_citeinfo_onlink_2_.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append
        Me.idinfo_citation_citeinfo_onlink_2_.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.idinfo_citation_citeinfo_onlink_2_.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_2_.FormattingEnabled = True
        Me.idinfo_citation_citeinfo_onlink_2_.Location = New System.Drawing.Point(120, 44)
        Me.idinfo_citation_citeinfo_onlink_2_.Name = "idinfo_citation_citeinfo_onlink_2_"
        Me.idinfo_citation_citeinfo_onlink_2_.Size = New System.Drawing.Size(258, 21)
        Me.idinfo_citation_citeinfo_onlink_2_.TabIndex = 39
        '
        'idinfo_citation_citeinfo_onlink_1_
        '
        Me.idinfo_citation_citeinfo_onlink_1_.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append
        Me.idinfo_citation_citeinfo_onlink_1_.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.idinfo_citation_citeinfo_onlink_1_.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_1_.FormattingEnabled = True
        Me.idinfo_citation_citeinfo_onlink_1_.Location = New System.Drawing.Point(120, 17)
        Me.idinfo_citation_citeinfo_onlink_1_.Name = "idinfo_citation_citeinfo_onlink_1_"
        Me.idinfo_citation_citeinfo_onlink_1_.Size = New System.Drawing.Size(258, 21)
        Me.idinfo_citation_citeinfo_onlink_1_.TabIndex = 38
        '
        'idinfo_citation_citeinfo_onlink_2______default
        '
        Me.idinfo_citation_citeinfo_onlink_2______default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.idinfo_citation_citeinfo_onlink_2______default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_2______default.Location = New System.Drawing.Point(384, 44)
        Me.idinfo_citation_citeinfo_onlink_2______default.Name = "idinfo_citation_citeinfo_onlink_2______default"
        Me.idinfo_citation_citeinfo_onlink_2______default.Size = New System.Drawing.Size(33, 23)
        Me.idinfo_citation_citeinfo_onlink_2______default.TabIndex = 37
        Me.idinfo_citation_citeinfo_onlink_2______default.Text = "D"
        Me.idinfo_citation_citeinfo_onlink_2______default.UseVisualStyleBackColor = False
        '
        'idinfo_citation_citeinfo_onlink_1______default
        '
        Me.idinfo_citation_citeinfo_onlink_1______default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.idinfo_citation_citeinfo_onlink_1______default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_1______default.Location = New System.Drawing.Point(384, 17)
        Me.idinfo_citation_citeinfo_onlink_1______default.Name = "idinfo_citation_citeinfo_onlink_1______default"
        Me.idinfo_citation_citeinfo_onlink_1______default.Size = New System.Drawing.Size(33, 23)
        Me.idinfo_citation_citeinfo_onlink_1______default.TabIndex = 36
        Me.idinfo_citation_citeinfo_onlink_1______default.Text = "D"
        Me.idinfo_citation_citeinfo_onlink_1______default.UseVisualStyleBackColor = False
        '
        'idinfo_citation_citeinfo_onlink_____warning
        '
        Me.idinfo_citation_citeinfo_onlink_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_citeinfo_onlink_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_citeinfo_onlink_____warning.Location = New System.Drawing.Point(92, -1)
        Me.idinfo_citation_citeinfo_onlink_____warning.Name = "idinfo_citation_citeinfo_onlink_____warning"
        Me.idinfo_citation_citeinfo_onlink_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_citation_citeinfo_onlink_____warning.TabIndex = 35
        Me.idinfo_citation_citeinfo_onlink_____warning.TabStop = False
        Me.idinfo_citation_citeinfo_onlink_____warning.Visible = False
        '
        'idinfo_citation_citeinfo_onlink_2______check
        '
        Me.idinfo_citation_citeinfo_onlink_2______check.AutoSize = True
        Me.idinfo_citation_citeinfo_onlink_2______check.FlatAppearance.BorderSize = 0
        Me.idinfo_citation_citeinfo_onlink_2______check.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.idinfo_citation_citeinfo_onlink_2______check.Image = CType(resources.GetObject("idinfo_citation_citeinfo_onlink_2______check.Image"), System.Drawing.Image)
        Me.idinfo_citation_citeinfo_onlink_2______check.Location = New System.Drawing.Point(419, 42)
        Me.idinfo_citation_citeinfo_onlink_2______check.Name = "idinfo_citation_citeinfo_onlink_2______check"
        Me.idinfo_citation_citeinfo_onlink_2______check.Size = New System.Drawing.Size(25, 24)
        Me.idinfo_citation_citeinfo_onlink_2______check.TabIndex = 26
        Me.HoverToolTip.SetToolTip(Me.idinfo_citation_citeinfo_onlink_2______check, "Verify secondary online linkage in a browser window")
        Me.idinfo_citation_citeinfo_onlink_2______check.UseVisualStyleBackColor = True
        '
        'idinfo_citation_citeinfo_onlink_1______check
        '
        Me.idinfo_citation_citeinfo_onlink_1______check.AutoSize = True
        Me.idinfo_citation_citeinfo_onlink_1______check.FlatAppearance.BorderSize = 0
        Me.idinfo_citation_citeinfo_onlink_1______check.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.idinfo_citation_citeinfo_onlink_1______check.Image = CType(resources.GetObject("idinfo_citation_citeinfo_onlink_1______check.Image"), System.Drawing.Image)
        Me.idinfo_citation_citeinfo_onlink_1______check.Location = New System.Drawing.Point(419, 16)
        Me.idinfo_citation_citeinfo_onlink_1______check.Name = "idinfo_citation_citeinfo_onlink_1______check"
        Me.idinfo_citation_citeinfo_onlink_1______check.Size = New System.Drawing.Size(25, 24)
        Me.idinfo_citation_citeinfo_onlink_1______check.TabIndex = 25
        Me.HoverToolTip.SetToolTip(Me.idinfo_citation_citeinfo_onlink_1______check, "Verify primary online linkage in a browser window")
        Me.idinfo_citation_citeinfo_onlink_1______check.UseVisualStyleBackColor = True
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.ForeColor = System.Drawing.Color.Black
        Me.Label44.Location = New System.Drawing.Point(3, 47)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(19, 13)
        Me.Label44.TabIndex = 24
        Me.Label44.Text = "**"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.Black
        Me.Label33.Location = New System.Drawing.Point(3, 20)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(19, 13)
        Me.Label33.TabIndex = 22
        Me.Label33.Text = "**"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.ForeColor = System.Drawing.Color.Black
        Me.Label26.Location = New System.Drawing.Point(7, -3)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(89, 13)
        Me.Label26.TabIndex = 1
        Me.Label26.Text = "Online Linkage"
        '
        'idinfo_citation_citeinfo_onlink_1______help
        '
        Me.idinfo_citation_citeinfo_onlink_1______help.AutoSize = True
        Me.idinfo_citation_citeinfo_onlink_1______help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_1______help.Location = New System.Drawing.Point(19, 19)
        Me.idinfo_citation_citeinfo_onlink_1______help.Name = "idinfo_citation_citeinfo_onlink_1______help"
        Me.idinfo_citation_citeinfo_onlink_1______help.Size = New System.Drawing.Size(86, 13)
        Me.idinfo_citation_citeinfo_onlink_1______help.TabIndex = 0
        Me.idinfo_citation_citeinfo_onlink_1______help.TabStop = True
        Me.idinfo_citation_citeinfo_onlink_1______help.Text = "Primary Linkage:"
        '
        'idinfo_citation_citeinfo_onlink_2______help
        '
        Me.idinfo_citation_citeinfo_onlink_2______help.AutoSize = True
        Me.idinfo_citation_citeinfo_onlink_2______help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_onlink_2______help.Location = New System.Drawing.Point(19, 47)
        Me.idinfo_citation_citeinfo_onlink_2______help.Name = "idinfo_citation_citeinfo_onlink_2______help"
        Me.idinfo_citation_citeinfo_onlink_2______help.Size = New System.Drawing.Size(101, 13)
        Me.idinfo_citation_citeinfo_onlink_2______help.TabIndex = 1
        Me.idinfo_citation_citeinfo_onlink_2______help.TabStop = True
        Me.idinfo_citation_citeinfo_onlink_2______help.Text = "Secondary Linkage:"
        '
        'Panel22
        '
        Me.Panel22.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel22.Controls.Add(Me.idinfo_citation_citeinfo_pubdate_____warning)
        Me.Panel22.Controls.Add(Me.idinfo_citation_citeinfo_pubinfo_pubplace_____warning)
        Me.Panel22.Controls.Add(Me.Label9)
        Me.Panel22.Controls.Add(Me.idinfo_citation_citeinfo_pubinfo_publish_____warning)
        Me.Panel22.Controls.Add(Me.idinfo_citation_citeinfo_pubinfo_____warning)
        Me.Panel22.Controls.Add(Me.Button2)
        Me.Panel22.Controls.Add(Me.idinfo_citation_citeinfo_pubdate_____help)
        Me.Panel22.Controls.Add(Me.idinfo_citation_citeinfo_pubdate_____today)
        Me.Panel22.Controls.Add(Me.Label11)
        Me.Panel22.Controls.Add(Me.Label10)
        Me.Panel22.Controls.Add(Me.Label25)
        Me.Panel22.Controls.Add(Me.idinfo_citation_citeinfo_pubdate)
        Me.Panel22.Controls.Add(Me.idinfo_citation_citeinfo_pubinfo_publish_____help)
        Me.Panel22.Controls.Add(Me.idinfo_citation_citeinfo_pubinfo_publish)
        Me.Panel22.Controls.Add(Me.idinfo_citation_citeinfo_pubinfo_pubplace)
        Me.Panel22.Controls.Add(Me.idinfo_citation_citeinfo_pubinfo_pubplace_____help)
        Me.Panel22.Location = New System.Drawing.Point(6, 79)
        Me.Panel22.Name = "Panel22"
        Me.Panel22.Size = New System.Drawing.Size(446, 70)
        Me.Panel22.TabIndex = 22
        '
        'idinfo_citation_citeinfo_pubdate_____warning
        '
        Me.idinfo_citation_citeinfo_pubdate_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_citeinfo_pubdate_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_citeinfo_pubdate_____warning.Location = New System.Drawing.Point(320, 46)
        Me.idinfo_citation_citeinfo_pubdate_____warning.Name = "idinfo_citation_citeinfo_pubdate_____warning"
        Me.idinfo_citation_citeinfo_pubdate_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_citation_citeinfo_pubdate_____warning.TabIndex = 35
        Me.idinfo_citation_citeinfo_pubdate_____warning.TabStop = False
        Me.idinfo_citation_citeinfo_pubdate_____warning.Visible = False
        '
        'idinfo_citation_citeinfo_pubinfo_pubplace_____warning
        '
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____warning.Location = New System.Drawing.Point(79, 44)
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____warning.Name = "idinfo_citation_citeinfo_pubinfo_pubplace_____warning"
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____warning.TabIndex = 34
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____warning.TabStop = False
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____warning.Visible = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(3, 17)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(13, 13)
        Me.Label9.TabIndex = 17
        Me.Label9.Text = "*"
        '
        'idinfo_citation_citeinfo_pubinfo_publish_____warning
        '
        Me.idinfo_citation_citeinfo_pubinfo_publish_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_citeinfo_pubinfo_publish_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_citeinfo_pubinfo_publish_____warning.Location = New System.Drawing.Point(79, 17)
        Me.idinfo_citation_citeinfo_pubinfo_publish_____warning.Name = "idinfo_citation_citeinfo_pubinfo_publish_____warning"
        Me.idinfo_citation_citeinfo_pubinfo_publish_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_citation_citeinfo_pubinfo_publish_____warning.TabIndex = 33
        Me.idinfo_citation_citeinfo_pubinfo_publish_____warning.TabStop = False
        Me.idinfo_citation_citeinfo_pubinfo_publish_____warning.Visible = False
        '
        'idinfo_citation_citeinfo_pubinfo_____warning
        '
        Me.idinfo_citation_citeinfo_pubinfo_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_citeinfo_pubinfo_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_citeinfo_pubinfo_____warning.Location = New System.Drawing.Point(66, -1)
        Me.idinfo_citation_citeinfo_pubinfo_____warning.Name = "idinfo_citation_citeinfo_pubinfo_____warning"
        Me.idinfo_citation_citeinfo_pubinfo_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_citation_citeinfo_pubinfo_____warning.TabIndex = 32
        Me.idinfo_citation_citeinfo_pubinfo_____warning.TabStop = False
        Me.idinfo_citation_citeinfo_pubinfo_____warning.Visible = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Button2.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(409, 3)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(33, 23)
        Me.Button2.TabIndex = 30
        Me.Button2.Text = "D"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'idinfo_citation_citeinfo_pubdate_____help
        '
        Me.idinfo_citation_citeinfo_pubdate_____help.AutoSize = True
        Me.idinfo_citation_citeinfo_pubdate_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_pubdate_____help.Location = New System.Drawing.Point(293, 45)
        Me.idinfo_citation_citeinfo_pubdate_____help.Name = "idinfo_citation_citeinfo_pubdate_____help"
        Me.idinfo_citation_citeinfo_pubdate_____help.Size = New System.Drawing.Size(34, 13)
        Me.idinfo_citation_citeinfo_pubdate_____help.TabIndex = 0
        Me.idinfo_citation_citeinfo_pubdate_____help.TabStop = True
        Me.idinfo_citation_citeinfo_pubdate_____help.Text = "Date:"
        '
        'idinfo_citation_citeinfo_pubdate_____today
        '
        Me.idinfo_citation_citeinfo_pubdate_____today.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.idinfo_citation_citeinfo_pubdate_____today.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_pubdate_____today.Location = New System.Drawing.Point(399, 41)
        Me.idinfo_citation_citeinfo_pubdate_____today.Name = "idinfo_citation_citeinfo_pubdate_____today"
        Me.idinfo_citation_citeinfo_pubdate_____today.Size = New System.Drawing.Size(43, 23)
        Me.idinfo_citation_citeinfo_pubdate_____today.TabIndex = 29
        Me.idinfo_citation_citeinfo_pubdate_____today.Text = "today"
        Me.idinfo_citation_citeinfo_pubdate_____today.UseVisualStyleBackColor = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(285, 46)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(13, 13)
        Me.Label11.TabIndex = 21
        Me.Label11.Text = "*"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(3, 44)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(13, 13)
        Me.Label10.TabIndex = 20
        Me.Label10.Text = "*"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.ForeColor = System.Drawing.Color.Black
        Me.Label25.Location = New System.Drawing.Point(7, -3)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(59, 13)
        Me.Label25.TabIndex = 1
        Me.Label25.Text = "Publisher"
        '
        'idinfo_citation_citeinfo_pubdate
        '
        Me.idinfo_citation_citeinfo_pubdate.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_pubdate.Location = New System.Drawing.Point(333, 41)
        Me.idinfo_citation_citeinfo_pubdate.Name = "idinfo_citation_citeinfo_pubdate"
        Me.idinfo_citation_citeinfo_pubdate.Size = New System.Drawing.Size(62, 21)
        Me.idinfo_citation_citeinfo_pubdate.TabIndex = 1
        Me.idinfo_citation_citeinfo_pubdate.Text = "YYYYMMDD"
        '
        'idinfo_citation_citeinfo_pubinfo_publish_____help
        '
        Me.idinfo_citation_citeinfo_pubinfo_publish_____help.AutoSize = True
        Me.idinfo_citation_citeinfo_pubinfo_publish_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_pubinfo_publish_____help.Location = New System.Drawing.Point(15, 17)
        Me.idinfo_citation_citeinfo_pubinfo_publish_____help.Name = "idinfo_citation_citeinfo_pubinfo_publish_____help"
        Me.idinfo_citation_citeinfo_pubinfo_publish_____help.Size = New System.Drawing.Size(71, 13)
        Me.idinfo_citation_citeinfo_pubinfo_publish_____help.TabIndex = 3
        Me.idinfo_citation_citeinfo_pubinfo_publish_____help.TabStop = True
        Me.idinfo_citation_citeinfo_pubinfo_publish_____help.Text = "Published by:"
        '
        'idinfo_citation_citeinfo_pubinfo_publish
        '
        Me.idinfo_citation_citeinfo_pubinfo_publish.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.idinfo_citation_citeinfo_pubinfo_publish.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.idinfo_citation_citeinfo_pubinfo_publish.DropDownWidth = 600
        Me.idinfo_citation_citeinfo_pubinfo_publish.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_pubinfo_publish.FormattingEnabled = True
        Me.idinfo_citation_citeinfo_pubinfo_publish.Location = New System.Drawing.Point(92, 14)
        Me.idinfo_citation_citeinfo_pubinfo_publish.Name = "idinfo_citation_citeinfo_pubinfo_publish"
        Me.idinfo_citation_citeinfo_pubinfo_publish.Size = New System.Drawing.Size(304, 21)
        Me.idinfo_citation_citeinfo_pubinfo_publish.TabIndex = 4
        '
        'idinfo_citation_citeinfo_pubinfo_pubplace
        '
        Me.idinfo_citation_citeinfo_pubinfo_pubplace.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append
        Me.idinfo_citation_citeinfo_pubinfo_pubplace.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.idinfo_citation_citeinfo_pubinfo_pubplace.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_pubinfo_pubplace.FormattingEnabled = True
        Me.idinfo_citation_citeinfo_pubinfo_pubplace.Location = New System.Drawing.Point(92, 41)
        Me.idinfo_citation_citeinfo_pubinfo_pubplace.Name = "idinfo_citation_citeinfo_pubinfo_pubplace"
        Me.idinfo_citation_citeinfo_pubinfo_pubplace.Size = New System.Drawing.Size(188, 21)
        Me.idinfo_citation_citeinfo_pubinfo_pubplace.TabIndex = 8
        '
        'idinfo_citation_citeinfo_pubinfo_pubplace_____help
        '
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____help.AutoSize = True
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____help.Location = New System.Drawing.Point(15, 44)
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____help.Name = "idinfo_citation_citeinfo_pubinfo_pubplace_____help"
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____help.Size = New System.Drawing.Size(69, 13)
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____help.TabIndex = 7
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____help.TabStop = True
        Me.idinfo_citation_citeinfo_pubinfo_pubplace_____help.Text = "Published at:"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel1.Controls.Add(Me.idinfo_citation_citeinfo_title_____warning)
        Me.Panel1.Controls.Add(Me.idinfo_citation_citeinfo_origin_____warning)
        Me.Panel1.Controls.Add(Me.idinfo_citation_citeinfo_title_____default)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.idinfo_citation_citeinfo_title_____help)
        Me.Panel1.Controls.Add(Me.idinfo_citation_citeinfo_origin_____help)
        Me.Panel1.Controls.Add(Me.idinfo_citation_citeinfo_origin_____default)
        Me.Panel1.Controls.Add(Me.idinfo_citation_citeinfo_title)
        Me.Panel1.Controls.Add(Me.idinfo_citation_citeinfo_origin)
        Me.Panel1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel1.Location = New System.Drawing.Point(6, 18)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(446, 54)
        Me.Panel1.TabIndex = 0
        '
        'idinfo_citation_citeinfo_title_____warning
        '
        Me.idinfo_citation_citeinfo_title_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_citeinfo_title_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_citeinfo_title_____warning.Location = New System.Drawing.Point(46, 34)
        Me.idinfo_citation_citeinfo_title_____warning.Name = "idinfo_citation_citeinfo_title_____warning"
        Me.idinfo_citation_citeinfo_title_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_citation_citeinfo_title_____warning.TabIndex = 35
        Me.idinfo_citation_citeinfo_title_____warning.TabStop = False
        Me.idinfo_citation_citeinfo_title_____warning.Visible = False
        '
        'idinfo_citation_citeinfo_origin_____warning
        '
        Me.idinfo_citation_citeinfo_origin_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_citeinfo_origin_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_citation_citeinfo_origin_____warning.Location = New System.Drawing.Point(46, 9)
        Me.idinfo_citation_citeinfo_origin_____warning.Name = "idinfo_citation_citeinfo_origin_____warning"
        Me.idinfo_citation_citeinfo_origin_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_citation_citeinfo_origin_____warning.TabIndex = 34
        Me.idinfo_citation_citeinfo_origin_____warning.TabStop = False
        Me.idinfo_citation_citeinfo_origin_____warning.Visible = False
        '
        'idinfo_citation_citeinfo_title_____default
        '
        Me.idinfo_citation_citeinfo_title_____default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.idinfo_citation_citeinfo_title_____default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_title_____default.Location = New System.Drawing.Point(409, 29)
        Me.idinfo_citation_citeinfo_title_____default.Name = "idinfo_citation_citeinfo_title_____default"
        Me.idinfo_citation_citeinfo_title_____default.Size = New System.Drawing.Size(33, 23)
        Me.idinfo_citation_citeinfo_title_____default.TabIndex = 17
        Me.idinfo_citation_citeinfo_title_____default.Text = "D"
        Me.idinfo_citation_citeinfo_title_____default.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(3, 34)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(13, 13)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "*"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(3, 9)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(13, 13)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "*"
        '
        'idinfo_citation_citeinfo_title_____help
        '
        Me.idinfo_citation_citeinfo_title_____help.AutoSize = True
        Me.idinfo_citation_citeinfo_title_____help.Location = New System.Drawing.Point(15, 33)
        Me.idinfo_citation_citeinfo_title_____help.Name = "idinfo_citation_citeinfo_title_____help"
        Me.idinfo_citation_citeinfo_title_____help.Size = New System.Drawing.Size(31, 13)
        Me.idinfo_citation_citeinfo_title_____help.TabIndex = 6
        Me.idinfo_citation_citeinfo_title_____help.TabStop = True
        Me.idinfo_citation_citeinfo_title_____help.Text = "Title:"
        '
        'idinfo_citation_citeinfo_origin_____help
        '
        Me.idinfo_citation_citeinfo_origin_____help.AutoSize = True
        Me.idinfo_citation_citeinfo_origin_____help.Location = New System.Drawing.Point(14, 8)
        Me.idinfo_citation_citeinfo_origin_____help.Name = "idinfo_citation_citeinfo_origin_____help"
        Me.idinfo_citation_citeinfo_origin_____help.Size = New System.Drawing.Size(39, 13)
        Me.idinfo_citation_citeinfo_origin_____help.TabIndex = 5
        Me.idinfo_citation_citeinfo_origin_____help.TabStop = True
        Me.idinfo_citation_citeinfo_origin_____help.Text = "Origin:"
        '
        'idinfo_citation_citeinfo_origin_____default
        '
        Me.idinfo_citation_citeinfo_origin_____default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.idinfo_citation_citeinfo_origin_____default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_citation_citeinfo_origin_____default.Location = New System.Drawing.Point(409, 3)
        Me.idinfo_citation_citeinfo_origin_____default.Name = "idinfo_citation_citeinfo_origin_____default"
        Me.idinfo_citation_citeinfo_origin_____default.Size = New System.Drawing.Size(33, 23)
        Me.idinfo_citation_citeinfo_origin_____default.TabIndex = 3
        Me.idinfo_citation_citeinfo_origin_____default.Text = "D"
        Me.idinfo_citation_citeinfo_origin_____default.UseVisualStyleBackColor = False
        '
        'idinfo_citation_citeinfo_title
        '
        Me.idinfo_citation_citeinfo_title.Location = New System.Drawing.Point(59, 30)
        Me.idinfo_citation_citeinfo_title.Name = "idinfo_citation_citeinfo_title"
        Me.idinfo_citation_citeinfo_title.Size = New System.Drawing.Size(345, 21)
        Me.idinfo_citation_citeinfo_title.TabIndex = 1
        '
        'idinfo_citation_citeinfo_origin
        '
        Me.idinfo_citation_citeinfo_origin.Location = New System.Drawing.Point(59, 4)
        Me.idinfo_citation_citeinfo_origin.Name = "idinfo_citation_citeinfo_origin"
        Me.idinfo_citation_citeinfo_origin.Size = New System.Drawing.Size(345, 21)
        Me.idinfo_citation_citeinfo_origin.TabIndex = 0
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.idinfo_spdom_____warning)
        Me.GroupBox4.Controls.Add(Me.Panel24)
        Me.GroupBox4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.ForeColor = System.Drawing.Color.Black
        Me.GroupBox4.Location = New System.Drawing.Point(470, 5)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(330, 102)
        Me.GroupBox4.TabIndex = 28
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Bounding Box"
        '
        'idinfo_spdom_____warning
        '
        Me.idinfo_spdom_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_spdom_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_spdom_____warning.Location = New System.Drawing.Point(86, 1)
        Me.idinfo_spdom_____warning.Name = "idinfo_spdom_____warning"
        Me.idinfo_spdom_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_spdom_____warning.TabIndex = 36
        Me.idinfo_spdom_____warning.TabStop = False
        Me.idinfo_spdom_____warning.Visible = False
        '
        'Panel24
        '
        Me.Panel24.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel24.Controls.Add(Me.idinfo_spdom_bounding_southbc_____warning)
        Me.Panel24.Controls.Add(Me.idinfo_spdom_bounding_westbc_____warning)
        Me.Panel24.Controls.Add(Me.idinfo_spdom_bounding_eastbc_____warning)
        Me.Panel24.Controls.Add(Me.idinfo_spdom_bounding_northbc_____warning)
        Me.Panel24.Controls.Add(Me.idinfo_spdom_bounding_westbc)
        Me.Panel24.Controls.Add(Me.idinfo_spdom_bounding_southbc_____help)
        Me.Panel24.Controls.Add(Me.idinfo_spdom_bounding_westbc_____help)
        Me.Panel24.Controls.Add(Me.idinfo_spdom_bounding_eastbc_____help)
        Me.Panel24.Controls.Add(Me.idinfo_spdom_bounding_northbc_____help)
        Me.Panel24.Controls.Add(Me.Label39)
        Me.Panel24.Controls.Add(Me.Label38)
        Me.Panel24.Controls.Add(Me.Label37)
        Me.Panel24.Controls.Add(Me.Label36)
        Me.Panel24.Controls.Add(Me.idinfo_spdom_bounding)
        Me.Panel24.Controls.Add(Me.idinfo_spdom_bounding_southbc)
        Me.Panel24.Controls.Add(Me.idinfo_spdom_bounding_eastbc)
        Me.Panel24.Controls.Add(Me.idinfo_spdom_bounding_____default)
        Me.Panel24.Controls.Add(Me.idinfo_spdom_bounding_northbc)
        Me.Panel24.Location = New System.Drawing.Point(6, 12)
        Me.Panel24.Name = "Panel24"
        Me.Panel24.Size = New System.Drawing.Size(318, 84)
        Me.Panel24.TabIndex = 24
        '
        'idinfo_spdom_bounding_southbc_____warning
        '
        Me.idinfo_spdom_bounding_southbc_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_spdom_bounding_southbc_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_spdom_bounding_southbc_____warning.Location = New System.Drawing.Point(22, 60)
        Me.idinfo_spdom_bounding_southbc_____warning.Name = "idinfo_spdom_bounding_southbc_____warning"
        Me.idinfo_spdom_bounding_southbc_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_spdom_bounding_southbc_____warning.TabIndex = 40
        Me.idinfo_spdom_bounding_southbc_____warning.TabStop = False
        Me.idinfo_spdom_bounding_southbc_____warning.Visible = False
        '
        'idinfo_spdom_bounding_westbc_____warning
        '
        Me.idinfo_spdom_bounding_westbc_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_spdom_bounding_westbc_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_spdom_bounding_westbc_____warning.Location = New System.Drawing.Point(183, 61)
        Me.idinfo_spdom_bounding_westbc_____warning.Name = "idinfo_spdom_bounding_westbc_____warning"
        Me.idinfo_spdom_bounding_westbc_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_spdom_bounding_westbc_____warning.TabIndex = 39
        Me.idinfo_spdom_bounding_westbc_____warning.TabStop = False
        Me.idinfo_spdom_bounding_westbc_____warning.Visible = False
        '
        'idinfo_spdom_bounding_eastbc_____warning
        '
        Me.idinfo_spdom_bounding_eastbc_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_spdom_bounding_eastbc_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_spdom_bounding_eastbc_____warning.Location = New System.Drawing.Point(183, 35)
        Me.idinfo_spdom_bounding_eastbc_____warning.Name = "idinfo_spdom_bounding_eastbc_____warning"
        Me.idinfo_spdom_bounding_eastbc_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_spdom_bounding_eastbc_____warning.TabIndex = 38
        Me.idinfo_spdom_bounding_eastbc_____warning.TabStop = False
        Me.idinfo_spdom_bounding_eastbc_____warning.Visible = False
        '
        'idinfo_spdom_bounding_northbc_____warning
        '
        Me.idinfo_spdom_bounding_northbc_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_spdom_bounding_northbc_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_spdom_bounding_northbc_____warning.Location = New System.Drawing.Point(21, 35)
        Me.idinfo_spdom_bounding_northbc_____warning.Name = "idinfo_spdom_bounding_northbc_____warning"
        Me.idinfo_spdom_bounding_northbc_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_spdom_bounding_northbc_____warning.TabIndex = 37
        Me.idinfo_spdom_bounding_northbc_____warning.TabStop = False
        Me.idinfo_spdom_bounding_northbc_____warning.Visible = False
        '
        'idinfo_spdom_bounding_westbc
        '
        Me.idinfo_spdom_bounding_westbc.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_spdom_bounding_westbc.Location = New System.Drawing.Point(196, 57)
        Me.idinfo_spdom_bounding_westbc.Name = "idinfo_spdom_bounding_westbc"
        Me.idinfo_spdom_bounding_westbc.Size = New System.Drawing.Size(114, 21)
        Me.idinfo_spdom_bounding_westbc.TabIndex = 11
        '
        'idinfo_spdom_bounding_southbc_____help
        '
        Me.idinfo_spdom_bounding_southbc_____help.AutoSize = True
        Me.idinfo_spdom_bounding_southbc_____help.BackColor = System.Drawing.Color.Transparent
        Me.idinfo_spdom_bounding_southbc_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_spdom_bounding_southbc_____help.Location = New System.Drawing.Point(12, 60)
        Me.idinfo_spdom_bounding_southbc_____help.Name = "idinfo_spdom_bounding_southbc_____help"
        Me.idinfo_spdom_bounding_southbc_____help.Size = New System.Drawing.Size(17, 13)
        Me.idinfo_spdom_bounding_southbc_____help.TabIndex = 31
        Me.idinfo_spdom_bounding_southbc_____help.TabStop = True
        Me.idinfo_spdom_bounding_southbc_____help.Text = "S:"
        '
        'idinfo_spdom_bounding_westbc_____help
        '
        Me.idinfo_spdom_bounding_westbc_____help.AutoSize = True
        Me.idinfo_spdom_bounding_westbc_____help.BackColor = System.Drawing.Color.Transparent
        Me.idinfo_spdom_bounding_westbc_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_spdom_bounding_westbc_____help.Location = New System.Drawing.Point(169, 60)
        Me.idinfo_spdom_bounding_westbc_____help.Name = "idinfo_spdom_bounding_westbc_____help"
        Me.idinfo_spdom_bounding_westbc_____help.Size = New System.Drawing.Size(21, 13)
        Me.idinfo_spdom_bounding_westbc_____help.TabIndex = 31
        Me.idinfo_spdom_bounding_westbc_____help.TabStop = True
        Me.idinfo_spdom_bounding_westbc_____help.Text = "W:"
        '
        'idinfo_spdom_bounding_eastbc_____help
        '
        Me.idinfo_spdom_bounding_eastbc_____help.AutoSize = True
        Me.idinfo_spdom_bounding_eastbc_____help.BackColor = System.Drawing.Color.Transparent
        Me.idinfo_spdom_bounding_eastbc_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_spdom_bounding_eastbc_____help.Location = New System.Drawing.Point(169, 35)
        Me.idinfo_spdom_bounding_eastbc_____help.Name = "idinfo_spdom_bounding_eastbc_____help"
        Me.idinfo_spdom_bounding_eastbc_____help.Size = New System.Drawing.Size(17, 13)
        Me.idinfo_spdom_bounding_eastbc_____help.TabIndex = 31
        Me.idinfo_spdom_bounding_eastbc_____help.TabStop = True
        Me.idinfo_spdom_bounding_eastbc_____help.Text = "E:"
        '
        'idinfo_spdom_bounding_northbc_____help
        '
        Me.idinfo_spdom_bounding_northbc_____help.AutoSize = True
        Me.idinfo_spdom_bounding_northbc_____help.BackColor = System.Drawing.Color.Transparent
        Me.idinfo_spdom_bounding_northbc_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_spdom_bounding_northbc_____help.Location = New System.Drawing.Point(12, 34)
        Me.idinfo_spdom_bounding_northbc_____help.Name = "idinfo_spdom_bounding_northbc_____help"
        Me.idinfo_spdom_bounding_northbc_____help.Size = New System.Drawing.Size(18, 13)
        Me.idinfo_spdom_bounding_northbc_____help.TabIndex = 31
        Me.idinfo_spdom_bounding_northbc_____help.TabStop = True
        Me.idinfo_spdom_bounding_northbc_____help.Text = "N:"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.ForeColor = System.Drawing.Color.Black
        Me.Label39.Location = New System.Drawing.Point(158, 60)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(13, 13)
        Me.Label39.TabIndex = 20
        Me.Label39.Text = "*"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.ForeColor = System.Drawing.Color.Black
        Me.Label38.Location = New System.Drawing.Point(158, 35)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(13, 13)
        Me.Label38.TabIndex = 19
        Me.Label38.Text = "*"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.ForeColor = System.Drawing.Color.Black
        Me.Label37.Location = New System.Drawing.Point(3, 61)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(13, 13)
        Me.Label37.TabIndex = 18
        Me.Label37.Text = "*"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.ForeColor = System.Drawing.Color.Black
        Me.Label36.Location = New System.Drawing.Point(2, 35)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(13, 13)
        Me.Label36.TabIndex = 17
        Me.Label36.Text = "*"
        '
        'idinfo_spdom_bounding
        '
        Me.idinfo_spdom_bounding.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_spdom_bounding.FormattingEnabled = True
        Me.idinfo_spdom_bounding.Location = New System.Drawing.Point(5, 6)
        Me.idinfo_spdom_bounding.Name = "idinfo_spdom_bounding"
        Me.idinfo_spdom_bounding.Size = New System.Drawing.Size(266, 21)
        Me.idinfo_spdom_bounding.TabIndex = 0
        Me.idinfo_spdom_bounding.Text = "Choose an AOI"
        '
        'idinfo_spdom_bounding_southbc
        '
        Me.idinfo_spdom_bounding_southbc.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_spdom_bounding_southbc.Location = New System.Drawing.Point(32, 57)
        Me.idinfo_spdom_bounding_southbc.Name = "idinfo_spdom_bounding_southbc"
        Me.idinfo_spdom_bounding_southbc.Size = New System.Drawing.Size(114, 21)
        Me.idinfo_spdom_bounding_southbc.TabIndex = 10
        '
        'idinfo_spdom_bounding_eastbc
        '
        Me.idinfo_spdom_bounding_eastbc.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_spdom_bounding_eastbc.Location = New System.Drawing.Point(196, 32)
        Me.idinfo_spdom_bounding_eastbc.Name = "idinfo_spdom_bounding_eastbc"
        Me.idinfo_spdom_bounding_eastbc.Size = New System.Drawing.Size(114, 21)
        Me.idinfo_spdom_bounding_eastbc.TabIndex = 9
        '
        'idinfo_spdom_bounding_____default
        '
        Me.idinfo_spdom_bounding_____default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.idinfo_spdom_bounding_____default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_spdom_bounding_____default.Location = New System.Drawing.Point(279, 3)
        Me.idinfo_spdom_bounding_____default.Name = "idinfo_spdom_bounding_____default"
        Me.idinfo_spdom_bounding_____default.Size = New System.Drawing.Size(33, 23)
        Me.idinfo_spdom_bounding_____default.TabIndex = 7
        Me.idinfo_spdom_bounding_____default.Text = "D"
        Me.idinfo_spdom_bounding_____default.UseVisualStyleBackColor = False
        '
        'idinfo_spdom_bounding_northbc
        '
        Me.idinfo_spdom_bounding_northbc.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_spdom_bounding_northbc.Location = New System.Drawing.Point(32, 32)
        Me.idinfo_spdom_bounding_northbc.Name = "idinfo_spdom_bounding_northbc"
        Me.idinfo_spdom_bounding_northbc.Size = New System.Drawing.Size(114, 21)
        Me.idinfo_spdom_bounding_northbc.TabIndex = 8
        '
        'GroupBox7
        '
        Me.GroupBox7.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox7.Controls.Add(Me.idinfo_ptcontac_____warning)
        Me.GroupBox7.Controls.Add(Me.idinfo_ptcontac_____help)
        Me.GroupBox7.Controls.Add(Me.Panel26)
        Me.GroupBox7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox7.Location = New System.Drawing.Point(470, 449)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(330, 67)
        Me.GroupBox7.TabIndex = 13
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "               "
        '
        'idinfo_ptcontac_____warning
        '
        Me.idinfo_ptcontac_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_ptcontac_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_ptcontac_____warning.Location = New System.Drawing.Point(53, 1)
        Me.idinfo_ptcontac_____warning.Name = "idinfo_ptcontac_____warning"
        Me.idinfo_ptcontac_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_ptcontac_____warning.TabIndex = 44
        Me.idinfo_ptcontac_____warning.TabStop = False
        Me.idinfo_ptcontac_____warning.Visible = False
        '
        'idinfo_ptcontac_____help
        '
        Me.idinfo_ptcontac_____help.AutoSize = True
        Me.idinfo_ptcontac_____help.BackColor = System.Drawing.SystemColors.Control
        Me.idinfo_ptcontac_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_ptcontac_____help.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.idinfo_ptcontac_____help.Location = New System.Drawing.Point(7, 0)
        Me.idinfo_ptcontac_____help.Name = "idinfo_ptcontac_____help"
        Me.idinfo_ptcontac_____help.Size = New System.Drawing.Size(51, 13)
        Me.idinfo_ptcontac_____help.TabIndex = 45
        Me.idinfo_ptcontac_____help.TabStop = True
        Me.idinfo_ptcontac_____help.Text = "Contact"
        '
        'Panel26
        '
        Me.Panel26.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Panel26.Controls.Add(Me.idinfo_ptcontac)
        Me.Panel26.Controls.Add(Me.idinfo_ptcontac_cntinfo_cntorgp)
        Me.Panel26.Controls.Add(Me.idinfo_ptcontac_____default)
        Me.Panel26.Controls.Add(Me.idinfo_ptcontac_cntinfo_cntperp)
        Me.Panel26.Location = New System.Drawing.Point(6, 16)
        Me.Panel26.Name = "Panel26"
        Me.Panel26.Size = New System.Drawing.Size(318, 46)
        Me.Panel26.TabIndex = 0
        '
        'idinfo_ptcontac
        '
        Me.idinfo_ptcontac.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_ptcontac.FormattingEnabled = True
        Me.idinfo_ptcontac.Location = New System.Drawing.Point(8, 20)
        Me.idinfo_ptcontac.Name = "idinfo_ptcontac"
        Me.idinfo_ptcontac.Size = New System.Drawing.Size(269, 21)
        Me.idinfo_ptcontac.TabIndex = 8
        '
        'idinfo_ptcontac_cntinfo_cntorgp
        '
        Me.idinfo_ptcontac_cntinfo_cntorgp.AutoSize = True
        Me.idinfo_ptcontac_cntinfo_cntorgp.Checked = True
        Me.idinfo_ptcontac_cntinfo_cntorgp.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_ptcontac_cntinfo_cntorgp.Location = New System.Drawing.Point(152, 2)
        Me.idinfo_ptcontac_cntinfo_cntorgp.Name = "idinfo_ptcontac_cntinfo_cntorgp"
        Me.idinfo_ptcontac_cntinfo_cntorgp.Size = New System.Drawing.Size(125, 17)
        Me.idinfo_ptcontac_cntinfo_cntorgp.TabIndex = 1
        Me.idinfo_ptcontac_cntinfo_cntorgp.TabStop = True
        Me.idinfo_ptcontac_cntinfo_cntorgp.Text = "Primary Organization"
        Me.idinfo_ptcontac_cntinfo_cntorgp.UseVisualStyleBackColor = True
        '
        'idinfo_ptcontac_____default
        '
        Me.idinfo_ptcontac_____default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.idinfo_ptcontac_____default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_ptcontac_____default.Location = New System.Drawing.Point(281, 18)
        Me.idinfo_ptcontac_____default.Name = "idinfo_ptcontac_____default"
        Me.idinfo_ptcontac_____default.Size = New System.Drawing.Size(33, 23)
        Me.idinfo_ptcontac_____default.TabIndex = 12
        Me.idinfo_ptcontac_____default.Text = "D"
        Me.idinfo_ptcontac_____default.UseVisualStyleBackColor = False
        '
        'idinfo_ptcontac_cntinfo_cntperp
        '
        Me.idinfo_ptcontac_cntinfo_cntperp.AutoSize = True
        Me.idinfo_ptcontac_cntinfo_cntperp.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_ptcontac_cntinfo_cntperp.Location = New System.Drawing.Point(8, 2)
        Me.idinfo_ptcontac_cntinfo_cntperp.Name = "idinfo_ptcontac_cntinfo_cntperp"
        Me.idinfo_ptcontac_cntinfo_cntperp.Size = New System.Drawing.Size(97, 17)
        Me.idinfo_ptcontac_cntinfo_cntperp.TabIndex = 0
        Me.idinfo_ptcontac_cntinfo_cntperp.Text = "Primary Person"
        Me.idinfo_ptcontac_cntinfo_cntperp.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox6.Controls.Add(Me.Panel25)
        Me.GroupBox6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox6.ForeColor = System.Drawing.Color.Black
        Me.GroupBox6.Location = New System.Drawing.Point(470, 340)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(330, 109)
        Me.GroupBox6.TabIndex = 12
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Data Set Constraints"
        '
        'Panel25
        '
        Me.Panel25.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel25.Controls.Add(Me.idinfo_secinfo_____warning)
        Me.Panel25.Controls.Add(Me.idinfo_useconst_____warning)
        Me.Panel25.Controls.Add(Me.idinfo_accconst_____warning)
        Me.Panel25.Controls.Add(Me.idinfo_secinfo_____default)
        Me.Panel25.Controls.Add(Me.idinfo_useconst_____default)
        Me.Panel25.Controls.Add(Me.idinfo_accconst_____default)
        Me.Panel25.Controls.Add(Me.Label41)
        Me.Panel25.Controls.Add(Me.Label40)
        Me.Panel25.Controls.Add(Me.Label6)
        Me.Panel25.Controls.Add(Me.idinfo_secinfo)
        Me.Panel25.Controls.Add(Me.idinfo_accconst)
        Me.Panel25.Controls.Add(Me.idinfo_accconst_____help)
        Me.Panel25.Controls.Add(Me.idinfo_secinfo_____help)
        Me.Panel25.Controls.Add(Me.idinfo_useconst_____help)
        Me.Panel25.Controls.Add(Me.idinfo_useconst)
        Me.Panel25.Location = New System.Drawing.Point(6, 14)
        Me.Panel25.Name = "Panel25"
        Me.Panel25.Size = New System.Drawing.Size(318, 90)
        Me.Panel25.TabIndex = 0
        '
        'idinfo_secinfo_____warning
        '
        Me.idinfo_secinfo_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_secinfo_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_secinfo_____warning.Location = New System.Drawing.Point(74, 65)
        Me.idinfo_secinfo_____warning.Name = "idinfo_secinfo_____warning"
        Me.idinfo_secinfo_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_secinfo_____warning.TabIndex = 43
        Me.idinfo_secinfo_____warning.TabStop = False
        Me.idinfo_secinfo_____warning.Visible = False
        '
        'idinfo_useconst_____warning
        '
        Me.idinfo_useconst_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_useconst_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_useconst_____warning.Location = New System.Drawing.Point(47, 38)
        Me.idinfo_useconst_____warning.Name = "idinfo_useconst_____warning"
        Me.idinfo_useconst_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_useconst_____warning.TabIndex = 42
        Me.idinfo_useconst_____warning.TabStop = False
        Me.idinfo_useconst_____warning.Visible = False
        '
        'idinfo_accconst_____warning
        '
        Me.idinfo_accconst_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_accconst_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_accconst_____warning.Location = New System.Drawing.Point(47, 9)
        Me.idinfo_accconst_____warning.Name = "idinfo_accconst_____warning"
        Me.idinfo_accconst_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_accconst_____warning.TabIndex = 41
        Me.idinfo_accconst_____warning.TabStop = False
        Me.idinfo_accconst_____warning.Visible = False
        '
        'idinfo_secinfo_____default
        '
        Me.idinfo_secinfo_____default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.idinfo_secinfo_____default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_secinfo_____default.Location = New System.Drawing.Point(277, 61)
        Me.idinfo_secinfo_____default.Name = "idinfo_secinfo_____default"
        Me.idinfo_secinfo_____default.Size = New System.Drawing.Size(33, 23)
        Me.idinfo_secinfo_____default.TabIndex = 33
        Me.idinfo_secinfo_____default.Text = "D"
        Me.idinfo_secinfo_____default.UseVisualStyleBackColor = False
        '
        'idinfo_useconst_____default
        '
        Me.idinfo_useconst_____default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.idinfo_useconst_____default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_useconst_____default.Location = New System.Drawing.Point(277, 33)
        Me.idinfo_useconst_____default.Name = "idinfo_useconst_____default"
        Me.idinfo_useconst_____default.Size = New System.Drawing.Size(33, 23)
        Me.idinfo_useconst_____default.TabIndex = 32
        Me.idinfo_useconst_____default.Text = "D"
        Me.idinfo_useconst_____default.UseVisualStyleBackColor = False
        '
        'idinfo_accconst_____default
        '
        Me.idinfo_accconst_____default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.idinfo_accconst_____default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_accconst_____default.Location = New System.Drawing.Point(277, 4)
        Me.idinfo_accconst_____default.Name = "idinfo_accconst_____default"
        Me.idinfo_accconst_____default.Size = New System.Drawing.Size(33, 23)
        Me.idinfo_accconst_____default.TabIndex = 31
        Me.idinfo_accconst_____default.Text = "D"
        Me.idinfo_accconst_____default.UseVisualStyleBackColor = False
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.ForeColor = System.Drawing.Color.Black
        Me.Label41.Location = New System.Drawing.Point(2, 61)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(13, 13)
        Me.Label41.TabIndex = 17
        Me.Label41.Text = "*"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.ForeColor = System.Drawing.Color.Black
        Me.Label40.Location = New System.Drawing.Point(2, 38)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(13, 13)
        Me.Label40.TabIndex = 16
        Me.Label40.Text = "*"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(2, 9)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(13, 13)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "*"
        '
        'idinfo_secinfo
        '
        Me.idinfo_secinfo.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_secinfo.FormattingEnabled = True
        Me.idinfo_secinfo.Location = New System.Drawing.Point(87, 62)
        Me.idinfo_secinfo.Name = "idinfo_secinfo"
        Me.idinfo_secinfo.Size = New System.Drawing.Size(184, 21)
        Me.idinfo_secinfo.TabIndex = 5
        '
        'idinfo_accconst
        '
        Me.idinfo_accconst.DropDownWidth = 400
        Me.idinfo_accconst.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_accconst.FormattingEnabled = True
        Me.idinfo_accconst.Location = New System.Drawing.Point(58, 6)
        Me.idinfo_accconst.Name = "idinfo_accconst"
        Me.idinfo_accconst.Size = New System.Drawing.Size(213, 21)
        Me.idinfo_accconst.TabIndex = 7
        '
        'idinfo_accconst_____help
        '
        Me.idinfo_accconst_____help.AutoSize = True
        Me.idinfo_accconst_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_accconst_____help.Location = New System.Drawing.Point(12, 9)
        Me.idinfo_accconst_____help.Name = "idinfo_accconst_____help"
        Me.idinfo_accconst_____help.Size = New System.Drawing.Size(44, 13)
        Me.idinfo_accconst_____help.TabIndex = 0
        Me.idinfo_accconst_____help.TabStop = True
        Me.idinfo_accconst_____help.Text = "Access:"
        '
        'idinfo_secinfo_____help
        '
        Me.idinfo_secinfo_____help.AutoSize = True
        Me.idinfo_secinfo_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_secinfo_____help.Location = New System.Drawing.Point(13, 59)
        Me.idinfo_secinfo_____help.Name = "idinfo_secinfo_____help"
        Me.idinfo_secinfo_____help.Size = New System.Drawing.Size(73, 26)
        Me.idinfo_secinfo_____help.TabIndex = 2
        Me.idinfo_secinfo_____help.TabStop = True
        Me.idinfo_secinfo_____help.Text = "Security" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Classification:"
        '
        'idinfo_useconst_____help
        '
        Me.idinfo_useconst_____help.AutoSize = True
        Me.idinfo_useconst_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_useconst_____help.Location = New System.Drawing.Point(14, 38)
        Me.idinfo_useconst_____help.Name = "idinfo_useconst_____help"
        Me.idinfo_useconst_____help.Size = New System.Drawing.Size(29, 13)
        Me.idinfo_useconst_____help.TabIndex = 1
        Me.idinfo_useconst_____help.TabStop = True
        Me.idinfo_useconst_____help.Text = "Use:"
        '
        'idinfo_useconst
        '
        Me.idinfo_useconst.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.idinfo_useconst.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.idinfo_useconst.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_useconst.FormattingEnabled = True
        Me.idinfo_useconst.Location = New System.Drawing.Point(58, 35)
        Me.idinfo_useconst.Name = "idinfo_useconst"
        Me.idinfo_useconst.Size = New System.Drawing.Size(213, 21)
        Me.idinfo_useconst.TabIndex = 6
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.idinfo_keywords_____warning)
        Me.GroupBox5.Controls.Add(Me.tcKeywords)
        Me.GroupBox5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.ForeColor = System.Drawing.Color.Black
        Me.GroupBox5.Location = New System.Drawing.Point(470, 108)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(330, 227)
        Me.GroupBox5.TabIndex = 11
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Keywords"
        '
        'idinfo_keywords_____warning
        '
        Me.idinfo_keywords_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_keywords_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_keywords_____warning.Location = New System.Drawing.Point(64, 0)
        Me.idinfo_keywords_____warning.Name = "idinfo_keywords_____warning"
        Me.idinfo_keywords_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_keywords_____warning.TabIndex = 41
        Me.idinfo_keywords_____warning.TabStop = False
        Me.idinfo_keywords_____warning.Visible = False
        '
        'tcKeywords
        '
        Me.tcKeywords.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tcKeywords.Controls.Add(Me.tpISO)
        Me.tcKeywords.Controls.Add(Me.tpEPA)
        Me.tcKeywords.Controls.Add(Me.tpUser)
        Me.tcKeywords.Controls.Add(Me.tpPlace)
        Me.tcKeywords.Location = New System.Drawing.Point(6, 17)
        Me.tcKeywords.Name = "tcKeywords"
        Me.tcKeywords.SelectedIndex = 0
        Me.tcKeywords.Size = New System.Drawing.Size(318, 203)
        Me.tcKeywords.TabIndex = 3
        '
        'tpISO
        '
        Me.tpISO.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.tpISO.Controls.Add(Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____default)
        Me.tpISO.Controls.Add(Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____help)
        Me.tpISO.Controls.Add(Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category_______warning)
        Me.tpISO.Controls.Add(Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey)
        Me.tpISO.Location = New System.Drawing.Point(4, 22)
        Me.tpISO.Name = "tpISO"
        Me.tpISO.Padding = New System.Windows.Forms.Padding(3)
        Me.tpISO.Size = New System.Drawing.Size(310, 177)
        Me.tpISO.TabIndex = 0
        Me.tpISO.Text = "ISO"
        '
        'idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____default
        '
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____default.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____default.Location = New System.Drawing.Point(254, 145)
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____default.Name = "idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____default"
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____default.Size = New System.Drawing.Size(33, 23)
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____default.TabIndex = 30
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____default.Text = "D"
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____default.UseVisualStyleBackColor = False
        '
        'idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____help
        '
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____help.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____help.AutoSize = True
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____help.BackColor = System.Drawing.Color.Transparent
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____help.Location = New System.Drawing.Point(254, 129)
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____help.Name = "idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____help"
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____help.Size = New System.Drawing.Size(34, 13)
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____help.TabIndex = 46
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____help.TabStop = True
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____help.Text = " Help "
        '
        'idinfo_keywords_theme_themekt__ISO_19115_Topic_Category_______warning
        '
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category_______warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category_______warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category_______warning.Location = New System.Drawing.Point(247, 5)
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category_______warning.Name = "idinfo_keywords_theme_themekt__ISO_19115_Topic_Category_______warning"
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category_______warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category_______warning.TabIndex = 42
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category_______warning.TabStop = False
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category_______warning.Visible = False
        '
        'idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey
        '
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey.FormattingEnabled = True
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey.Location = New System.Drawing.Point(3, 8)
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey.Name = "idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey"
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey.Size = New System.Drawing.Size(303, 160)
        Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey.TabIndex = 4
        '
        'tpEPA
        '
        Me.tpEPA.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.tpEPA.Controls.Add(Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____default)
        Me.tpEPA.Controls.Add(Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____help)
        Me.tpEPA.Controls.Add(Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus_______warning)
        Me.tpEPA.Controls.Add(Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey)
        Me.tpEPA.Location = New System.Drawing.Point(4, 22)
        Me.tpEPA.Name = "tpEPA"
        Me.tpEPA.Padding = New System.Windows.Forms.Padding(3)
        Me.tpEPA.Size = New System.Drawing.Size(310, 177)
        Me.tpEPA.TabIndex = 1
        Me.tpEPA.Text = "EPA"
        '
        'idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____default
        '
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____default.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____default.Location = New System.Drawing.Point(254, 145)
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____default.Name = "idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____default"
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____default.Size = New System.Drawing.Size(33, 23)
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____default.TabIndex = 31
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____default.Text = "D"
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____default.UseVisualStyleBackColor = False
        '
        'idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____help
        '
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____help.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____help.AutoSize = True
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____help.BackColor = System.Drawing.Color.Transparent
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____help.Location = New System.Drawing.Point(254, 129)
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____help.Name = "idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____help"
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____help.Size = New System.Drawing.Size(34, 13)
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____help.TabIndex = 46
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____help.TabStop = True
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____help.Text = " Help "
        '
        'idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus_______warning
        '
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus_______warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus_______warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus_______warning.Location = New System.Drawing.Point(247, 5)
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus_______warning.Name = "idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus_______warning"
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus_______warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus_______warning.TabIndex = 43
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus_______warning.TabStop = False
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus_______warning.Visible = False
        '
        'idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey
        '
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey.FormattingEnabled = True
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey.Location = New System.Drawing.Point(3, 8)
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey.Name = "idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey"
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey.Size = New System.Drawing.Size(303, 160)
        Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey.TabIndex = 5
        '
        'tpUser
        '
        Me.tpUser.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.tpUser.Controls.Add(Me.idinfo_keywords_theme_themekt__User___themekey_____default)
        Me.tpUser.Controls.Add(Me.idinfo_keywords_theme_themekt__User___themekey_____help)
        Me.tpUser.Controls.Add(Me.idinfo_keywords_theme_themekt__User_______warning)
        Me.tpUser.Controls.Add(Me.idinfo_keywords_theme_themekt__User___themekey)
        Me.tpUser.Location = New System.Drawing.Point(4, 22)
        Me.tpUser.Name = "tpUser"
        Me.tpUser.Size = New System.Drawing.Size(310, 177)
        Me.tpUser.TabIndex = 2
        Me.tpUser.Text = "User"
        '
        'idinfo_keywords_theme_themekt__User___themekey_____default
        '
        Me.idinfo_keywords_theme_themekt__User___themekey_____default.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_keywords_theme_themekt__User___themekey_____default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.idinfo_keywords_theme_themekt__User___themekey_____default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_keywords_theme_themekt__User___themekey_____default.Location = New System.Drawing.Point(254, 145)
        Me.idinfo_keywords_theme_themekt__User___themekey_____default.Name = "idinfo_keywords_theme_themekt__User___themekey_____default"
        Me.idinfo_keywords_theme_themekt__User___themekey_____default.Size = New System.Drawing.Size(33, 23)
        Me.idinfo_keywords_theme_themekt__User___themekey_____default.TabIndex = 34
        Me.idinfo_keywords_theme_themekt__User___themekey_____default.Text = "D"
        Me.idinfo_keywords_theme_themekt__User___themekey_____default.UseVisualStyleBackColor = False
        '
        'idinfo_keywords_theme_themekt__User___themekey_____help
        '
        Me.idinfo_keywords_theme_themekt__User___themekey_____help.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_keywords_theme_themekt__User___themekey_____help.AutoSize = True
        Me.idinfo_keywords_theme_themekt__User___themekey_____help.BackColor = System.Drawing.Color.Transparent
        Me.idinfo_keywords_theme_themekt__User___themekey_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_keywords_theme_themekt__User___themekey_____help.Location = New System.Drawing.Point(254, 129)
        Me.idinfo_keywords_theme_themekt__User___themekey_____help.Name = "idinfo_keywords_theme_themekt__User___themekey_____help"
        Me.idinfo_keywords_theme_themekt__User___themekey_____help.Size = New System.Drawing.Size(34, 13)
        Me.idinfo_keywords_theme_themekt__User___themekey_____help.TabIndex = 46
        Me.idinfo_keywords_theme_themekt__User___themekey_____help.TabStop = True
        Me.idinfo_keywords_theme_themekt__User___themekey_____help.Text = " Help "
        '
        'idinfo_keywords_theme_themekt__User_______warning
        '
        Me.idinfo_keywords_theme_themekt__User_______warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_keywords_theme_themekt__User_______warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_keywords_theme_themekt__User_______warning.Location = New System.Drawing.Point(247, 5)
        Me.idinfo_keywords_theme_themekt__User_______warning.Name = "idinfo_keywords_theme_themekt__User_______warning"
        Me.idinfo_keywords_theme_themekt__User_______warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_keywords_theme_themekt__User_______warning.TabIndex = 44
        Me.idinfo_keywords_theme_themekt__User_______warning.TabStop = False
        Me.idinfo_keywords_theme_themekt__User_______warning.Visible = False
        '
        'idinfo_keywords_theme_themekt__User___themekey
        '
        Me.idinfo_keywords_theme_themekt__User___themekey.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_keywords_theme_themekt__User___themekey.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_keywords_theme_themekt__User___themekey.FormattingEnabled = True
        Me.idinfo_keywords_theme_themekt__User___themekey.Location = New System.Drawing.Point(3, 8)
        Me.idinfo_keywords_theme_themekt__User___themekey.Name = "idinfo_keywords_theme_themekt__User___themekey"
        Me.idinfo_keywords_theme_themekt__User___themekey.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.idinfo_keywords_theme_themekt__User___themekey.Size = New System.Drawing.Size(303, 160)
        Me.idinfo_keywords_theme_themekt__User___themekey.TabIndex = 6
        '
        'tpPlace
        '
        Me.tpPlace.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.tpPlace.Controls.Add(Me.idinfo_keywords_place_placekt__None___placekey_____default)
        Me.tpPlace.Controls.Add(Me.idinfo_keywords_place_placekt__None___placekey_____help)
        Me.tpPlace.Controls.Add(Me.idinfo_keywords_place_placekt__None_______warning)
        Me.tpPlace.Controls.Add(Me.idinfo_keywords_place_placekt__None___placekey)
        Me.tpPlace.Location = New System.Drawing.Point(4, 22)
        Me.tpPlace.Name = "tpPlace"
        Me.tpPlace.Size = New System.Drawing.Size(310, 177)
        Me.tpPlace.TabIndex = 3
        Me.tpPlace.Text = "Place"
        '
        'idinfo_keywords_place_placekt__None___placekey_____default
        '
        Me.idinfo_keywords_place_placekt__None___placekey_____default.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_keywords_place_placekt__None___placekey_____default.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.idinfo_keywords_place_placekt__None___placekey_____default.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_keywords_place_placekt__None___placekey_____default.Location = New System.Drawing.Point(254, 145)
        Me.idinfo_keywords_place_placekt__None___placekey_____default.Name = "idinfo_keywords_place_placekt__None___placekey_____default"
        Me.idinfo_keywords_place_placekt__None___placekey_____default.Size = New System.Drawing.Size(33, 23)
        Me.idinfo_keywords_place_placekt__None___placekey_____default.TabIndex = 32
        Me.idinfo_keywords_place_placekt__None___placekey_____default.Text = "D"
        Me.idinfo_keywords_place_placekt__None___placekey_____default.UseVisualStyleBackColor = False
        '
        'idinfo_keywords_place_placekt__None___placekey_____help
        '
        Me.idinfo_keywords_place_placekt__None___placekey_____help.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_keywords_place_placekt__None___placekey_____help.AutoSize = True
        Me.idinfo_keywords_place_placekt__None___placekey_____help.BackColor = System.Drawing.Color.Transparent
        Me.idinfo_keywords_place_placekt__None___placekey_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_keywords_place_placekt__None___placekey_____help.Location = New System.Drawing.Point(254, 129)
        Me.idinfo_keywords_place_placekt__None___placekey_____help.Name = "idinfo_keywords_place_placekt__None___placekey_____help"
        Me.idinfo_keywords_place_placekt__None___placekey_____help.Size = New System.Drawing.Size(34, 13)
        Me.idinfo_keywords_place_placekt__None___placekey_____help.TabIndex = 45
        Me.idinfo_keywords_place_placekt__None___placekey_____help.TabStop = True
        Me.idinfo_keywords_place_placekt__None___placekey_____help.Text = " Help "
        '
        'idinfo_keywords_place_placekt__None_______warning
        '
        Me.idinfo_keywords_place_placekt__None_______warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_keywords_place_placekt__None_______warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_keywords_place_placekt__None_______warning.Location = New System.Drawing.Point(247, 5)
        Me.idinfo_keywords_place_placekt__None_______warning.Name = "idinfo_keywords_place_placekt__None_______warning"
        Me.idinfo_keywords_place_placekt__None_______warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_keywords_place_placekt__None_______warning.TabIndex = 44
        Me.idinfo_keywords_place_placekt__None_______warning.TabStop = False
        Me.idinfo_keywords_place_placekt__None_______warning.Visible = False
        '
        'idinfo_keywords_place_placekt__None___placekey
        '
        Me.idinfo_keywords_place_placekt__None___placekey.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.idinfo_keywords_place_placekt__None___placekey.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_keywords_place_placekt__None___placekey.FormattingEnabled = True
        Me.idinfo_keywords_place_placekt__None___placekey.Location = New System.Drawing.Point(3, 8)
        Me.idinfo_keywords_place_placekt__None___placekey.Name = "idinfo_keywords_place_placekt__None___placekey"
        Me.idinfo_keywords_place_placekt__None___placekey.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.idinfo_keywords_place_placekt__None___placekey.Size = New System.Drawing.Size(303, 160)
        Me.idinfo_keywords_place_placekt__None___placekey.TabIndex = 6
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox3.Controls.Add(Me.Button1)
        Me.GroupBox3.Controls.Add(Me.idinfo_status_____warning)
        Me.GroupBox3.Controls.Add(Me.idinfo_timeperd_____warning)
        Me.GroupBox3.Controls.Add(Me.Panel27)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.Color.Black
        Me.GroupBox3.Location = New System.Drawing.Point(6, 413)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(458, 103)
        Me.GroupBox3.TabIndex = 9
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Time Period"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Button1.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(415, 0)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(33, 23)
        Me.Button1.TabIndex = 48
        Me.Button1.Text = "D"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'idinfo_status_____warning
        '
        Me.idinfo_status_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_status_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_status_____warning.Location = New System.Drawing.Point(92, 0)
        Me.idinfo_status_____warning.Name = "idinfo_status_____warning"
        Me.idinfo_status_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_status_____warning.TabIndex = 47
        Me.idinfo_status_____warning.TabStop = False
        Me.idinfo_status_____warning.Visible = False
        '
        'idinfo_timeperd_____warning
        '
        Me.idinfo_timeperd_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_timeperd_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_timeperd_____warning.Location = New System.Drawing.Point(79, 0)
        Me.idinfo_timeperd_____warning.Name = "idinfo_timeperd_____warning"
        Me.idinfo_timeperd_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_timeperd_____warning.TabIndex = 44
        Me.idinfo_timeperd_____warning.TabStop = False
        Me.idinfo_timeperd_____warning.Visible = False
        '
        'Panel27
        '
        Me.Panel27.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel27.Controls.Add(Me.idinfo_status_update_____warning)
        Me.Panel27.Controls.Add(Me.idinfo_timeperd_current_____warning)
        Me.Panel27.Controls.Add(Me.idinfo_status_progress_____warning)
        Me.Panel27.Controls.Add(Me.GroupBox18)
        Me.Panel27.Controls.Add(Me.Label35)
        Me.Panel27.Controls.Add(Me.Label34)
        Me.Panel27.Controls.Add(Me.Label32)
        Me.Panel27.Controls.Add(Me.idinfo_status_update)
        Me.Panel27.Controls.Add(Me.idinfo_status_progress_____help)
        Me.Panel27.Controls.Add(Me.idinfo_timeperd_current)
        Me.Panel27.Controls.Add(Me.idinfo_status_progress)
        Me.Panel27.Controls.Add(Me.idinfo_status_update_____help)
        Me.Panel27.Controls.Add(Me.idinfo_timeperd_current_____help)
        Me.Panel27.Location = New System.Drawing.Point(6, 14)
        Me.Panel27.Name = "Panel27"
        Me.Panel27.Size = New System.Drawing.Size(446, 83)
        Me.Panel27.TabIndex = 0
        '
        'idinfo_status_update_____warning
        '
        Me.idinfo_status_update_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_status_update_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_status_update_____warning.Location = New System.Drawing.Point(294, 60)
        Me.idinfo_status_update_____warning.Name = "idinfo_status_update_____warning"
        Me.idinfo_status_update_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_status_update_____warning.TabIndex = 46
        Me.idinfo_status_update_____warning.TabStop = False
        Me.idinfo_status_update_____warning.Visible = False
        '
        'idinfo_timeperd_current_____warning
        '
        Me.idinfo_timeperd_current_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_timeperd_current_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_timeperd_current_____warning.Location = New System.Drawing.Point(294, 40)
        Me.idinfo_timeperd_current_____warning.Name = "idinfo_timeperd_current_____warning"
        Me.idinfo_timeperd_current_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_timeperd_current_____warning.TabIndex = 45
        Me.idinfo_timeperd_current_____warning.TabStop = False
        Me.idinfo_timeperd_current_____warning.Visible = False
        '
        'idinfo_status_progress_____warning
        '
        Me.idinfo_status_progress_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_status_progress_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_status_progress_____warning.Location = New System.Drawing.Point(294, 17)
        Me.idinfo_status_progress_____warning.Name = "idinfo_status_progress_____warning"
        Me.idinfo_status_progress_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_status_progress_____warning.TabIndex = 44
        Me.idinfo_status_progress_____warning.TabStop = False
        Me.idinfo_status_progress_____warning.Visible = False
        '
        'GroupBox18
        '
        Me.GroupBox18.Controls.Add(Me.idinfo_timeperd_timeinfo_____warning)
        Me.GroupBox18.Controls.Add(Me.timeinfo_____help2)
        Me.GroupBox18.Controls.Add(Me.Label17)
        Me.GroupBox18.Controls.Add(Me.Label31)
        Me.GroupBox18.Controls.Add(Me.Label29)
        Me.GroupBox18.Controls.Add(Me.Label2)
        Me.GroupBox18.Controls.Add(Me.timeinfo_____today)
        Me.GroupBox18.Controls.Add(Me.timeinfo)
        Me.GroupBox18.Controls.Add(Me.idinfo_timeperd_timeinfo_mdattim_sngdate____caldate)
        Me.GroupBox18.Controls.Add(Me.Label22)
        Me.GroupBox18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox18.Location = New System.Drawing.Point(3, 0)
        Me.GroupBox18.Name = "GroupBox18"
        Me.GroupBox18.Size = New System.Drawing.Size(197, 80)
        Me.GroupBox18.TabIndex = 34
        Me.GroupBox18.TabStop = False
        '
        'idinfo_timeperd_timeinfo_____warning
        '
        Me.idinfo_timeperd_timeinfo_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_timeperd_timeinfo_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_timeperd_timeinfo_____warning.Location = New System.Drawing.Point(104, 0)
        Me.idinfo_timeperd_timeinfo_____warning.Name = "idinfo_timeperd_timeinfo_____warning"
        Me.idinfo_timeperd_timeinfo_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_timeperd_timeinfo_____warning.TabIndex = 43
        Me.idinfo_timeperd_timeinfo_____warning.TabStop = False
        Me.idinfo_timeperd_timeinfo_____warning.Visible = False
        '
        'timeinfo_____help2
        '
        Me.timeinfo_____help2.AutoSize = True
        Me.timeinfo_____help2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.timeinfo_____help2.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.timeinfo_____help2.Location = New System.Drawing.Point(10, 0)
        Me.timeinfo_____help2.Name = "timeinfo_____help2"
        Me.timeinfo_____help2.Size = New System.Drawing.Size(100, 13)
        Me.timeinfo_____help2.TabIndex = 44
        Me.timeinfo_____help2.TabStop = True
        Me.timeinfo_____help2.Text = "Date of Data Set"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.Black
        Me.Label17.Location = New System.Drawing.Point(0, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(13, 13)
        Me.Label17.TabIndex = 45
        Me.Label17.Text = "*"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(1, 34)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(21, 12)
        Me.Label31.TabIndex = 42
        Me.Label31.Text = "OR"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(21, 34)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(129, 12)
        Me.Label29.TabIndex = 41
        Me.Label29.Text = "Range of dates: Date1 - Date2"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(49, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(21, 12)
        Me.Label2.TabIndex = 40
        Me.Label2.Text = "OR"
        '
        'timeinfo_____today
        '
        Me.timeinfo_____today.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.timeinfo_____today.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.timeinfo_____today.Location = New System.Drawing.Point(151, 55)
        Me.timeinfo_____today.Name = "timeinfo_____today"
        Me.timeinfo_____today.Size = New System.Drawing.Size(43, 23)
        Me.timeinfo_____today.TabIndex = 39
        Me.timeinfo_____today.Text = "today"
        Me.timeinfo_____today.UseVisualStyleBackColor = False
        '
        'timeinfo
        '
        Me.timeinfo.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.timeinfo.Location = New System.Drawing.Point(3, 55)
        Me.timeinfo.Name = "timeinfo"
        Me.timeinfo.Size = New System.Drawing.Size(142, 21)
        Me.timeinfo.TabIndex = 37
        '
        'idinfo_timeperd_timeinfo_mdattim_sngdate____caldate
        '
        Me.idinfo_timeperd_timeinfo_mdattim_sngdate____caldate.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_timeperd_timeinfo_mdattim_sngdate____caldate.FormattingEnabled = True
        Me.idinfo_timeperd_timeinfo_mdattim_sngdate____caldate.Location = New System.Drawing.Point(141, 61)
        Me.idinfo_timeperd_timeinfo_mdattim_sngdate____caldate.Name = "idinfo_timeperd_timeinfo_mdattim_sngdate____caldate"
        Me.idinfo_timeperd_timeinfo_mdattim_sngdate____caldate.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.idinfo_timeperd_timeinfo_mdattim_sngdate____caldate.Size = New System.Drawing.Size(37, 43)
        Me.idinfo_timeperd_timeinfo_mdattim_sngdate____caldate.TabIndex = 35
        Me.idinfo_timeperd_timeinfo_mdattim_sngdate____caldate.Visible = False
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(1, 16)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(185, 12)
        Me.Label22.TabIndex = 35
        Me.Label22.Text = "Single Date           Multi Dates: Date1, Date2,"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.Black
        Me.Label35.Location = New System.Drawing.Point(203, 61)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(13, 13)
        Me.Label35.TabIndex = 27
        Me.Label35.Text = "*"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.ForeColor = System.Drawing.Color.Black
        Me.Label34.Location = New System.Drawing.Point(203, 40)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(13, 13)
        Me.Label34.TabIndex = 26
        Me.Label34.Text = "*"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.ForeColor = System.Drawing.Color.Black
        Me.Label32.Location = New System.Drawing.Point(203, 17)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(13, 13)
        Me.Label32.TabIndex = 25
        Me.Label32.Text = "*"
        '
        'idinfo_status_update
        '
        Me.idinfo_status_update.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_status_update.FormattingEnabled = True
        Me.idinfo_status_update.Location = New System.Drawing.Point(307, 58)
        Me.idinfo_status_update.Name = "idinfo_status_update"
        Me.idinfo_status_update.Size = New System.Drawing.Size(135, 21)
        Me.idinfo_status_update.TabIndex = 18
        '
        'idinfo_status_progress_____help
        '
        Me.idinfo_status_progress_____help.AutoSize = True
        Me.idinfo_status_progress_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_status_progress_____help.Location = New System.Drawing.Point(213, 15)
        Me.idinfo_status_progress_____help.Name = "idinfo_status_progress_____help"
        Me.idinfo_status_progress_____help.Size = New System.Drawing.Size(91, 13)
        Me.idinfo_status_progress_____help.TabIndex = 13
        Me.idinfo_status_progress_____help.TabStop = True
        Me.idinfo_status_progress_____help.Text = "Progress of data:"
        '
        'idinfo_timeperd_current
        '
        Me.idinfo_timeperd_current.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_timeperd_current.FormattingEnabled = True
        Me.idinfo_timeperd_current.Location = New System.Drawing.Point(307, 35)
        Me.idinfo_timeperd_current.Name = "idinfo_timeperd_current"
        Me.idinfo_timeperd_current.Size = New System.Drawing.Size(135, 21)
        Me.idinfo_timeperd_current.TabIndex = 17
        '
        'idinfo_status_progress
        '
        Me.idinfo_status_progress.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_status_progress.FormattingEnabled = True
        Me.idinfo_status_progress.Location = New System.Drawing.Point(307, 12)
        Me.idinfo_status_progress.Name = "idinfo_status_progress"
        Me.idinfo_status_progress.Size = New System.Drawing.Size(135, 21)
        Me.idinfo_status_progress.TabIndex = 14
        '
        'idinfo_status_update_____help
        '
        Me.idinfo_status_update_____help.AutoSize = True
        Me.idinfo_status_update_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_status_update_____help.Location = New System.Drawing.Point(213, 61)
        Me.idinfo_status_update_____help.Name = "idinfo_status_update_____help"
        Me.idinfo_status_update_____help.Size = New System.Drawing.Size(98, 13)
        Me.idinfo_status_update_____help.TabIndex = 16
        Me.idinfo_status_update_____help.TabStop = True
        Me.idinfo_status_update_____help.Text = "Update frequency:"
        '
        'idinfo_timeperd_current_____help
        '
        Me.idinfo_timeperd_current_____help.AutoSize = True
        Me.idinfo_timeperd_current_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_timeperd_current_____help.Location = New System.Drawing.Point(213, 38)
        Me.idinfo_timeperd_current_____help.Name = "idinfo_timeperd_current_____help"
        Me.idinfo_timeperd_current_____help.Size = New System.Drawing.Size(79, 13)
        Me.idinfo_timeperd_current_____help.TabIndex = 15
        Me.idinfo_timeperd_current_____help.TabStop = True
        Me.idinfo_timeperd_current_____help.Text = "Data currency:"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.idinfo_descript_____warning)
        Me.GroupBox2.Controls.Add(Me.Panel6)
        Me.GroupBox2.Controls.Add(Me.Panel3)
        Me.GroupBox2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.Black
        Me.GroupBox2.Location = New System.Drawing.Point(6, 237)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(458, 173)
        Me.GroupBox2.TabIndex = 8
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Description"
        '
        'idinfo_descript_____warning
        '
        Me.idinfo_descript_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_descript_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_descript_____warning.Location = New System.Drawing.Point(72, 2)
        Me.idinfo_descript_____warning.Name = "idinfo_descript_____warning"
        Me.idinfo_descript_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_descript_____warning.TabIndex = 38
        Me.idinfo_descript_____warning.TabStop = False
        Me.idinfo_descript_____warning.Visible = False
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel6.Controls.Add(Me.idinfo_descript_purpose_____warning)
        Me.Panel6.Controls.Add(Me.idinfo_descript_abstract_____warning)
        Me.Panel6.Controls.Add(Me.Label30)
        Me.Panel6.Controls.Add(Me.Label27)
        Me.Panel6.Controls.Add(Me.DateTimePicker1)
        Me.Panel6.Controls.Add(Me.idinfo_descript_purpose_____help)
        Me.Panel6.Controls.Add(Me.idinfo_descript_purpose)
        Me.Panel6.Controls.Add(Me.idinfo_descript_abstract)
        Me.Panel6.Controls.Add(Me.idinfo_descript_abstract_____help)
        Me.Panel6.Location = New System.Drawing.Point(6, 17)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(446, 114)
        Me.Panel6.TabIndex = 23
        '
        'idinfo_descript_purpose_____warning
        '
        Me.idinfo_descript_purpose_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_descript_purpose_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_descript_purpose_____warning.Location = New System.Drawing.Point(54, 77)
        Me.idinfo_descript_purpose_____warning.Name = "idinfo_descript_purpose_____warning"
        Me.idinfo_descript_purpose_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_descript_purpose_____warning.TabIndex = 37
        Me.idinfo_descript_purpose_____warning.TabStop = False
        Me.idinfo_descript_purpose_____warning.Visible = False
        '
        'idinfo_descript_abstract_____warning
        '
        Me.idinfo_descript_abstract_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_descript_abstract_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_descript_abstract_____warning.Location = New System.Drawing.Point(54, 19)
        Me.idinfo_descript_abstract_____warning.Name = "idinfo_descript_abstract_____warning"
        Me.idinfo_descript_abstract_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_descript_abstract_____warning.TabIndex = 36
        Me.idinfo_descript_abstract_____warning.TabStop = False
        Me.idinfo_descript_abstract_____warning.Visible = False
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.ForeColor = System.Drawing.Color.Black
        Me.Label30.Location = New System.Drawing.Point(3, 78)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(13, 13)
        Me.Label30.TabIndex = 23
        Me.Label30.Text = "*"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.ForeColor = System.Drawing.Color.Black
        Me.Label27.Location = New System.Drawing.Point(3, 19)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(13, 13)
        Me.Label27.TabIndex = 22
        Me.Label27.Text = "*"
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(505, 87)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(20, 21)
        Me.DateTimePicker1.TabIndex = 0
        '
        'idinfo_descript_purpose_____help
        '
        Me.idinfo_descript_purpose_____help.AutoSize = True
        Me.idinfo_descript_purpose_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_descript_purpose_____help.Location = New System.Drawing.Point(13, 77)
        Me.idinfo_descript_purpose_____help.Name = "idinfo_descript_purpose_____help"
        Me.idinfo_descript_purpose_____help.Size = New System.Drawing.Size(50, 13)
        Me.idinfo_descript_purpose_____help.TabIndex = 1
        Me.idinfo_descript_purpose_____help.TabStop = True
        Me.idinfo_descript_purpose_____help.Text = "Purpose:"
        '
        'idinfo_descript_purpose
        '
        Me.idinfo_descript_purpose.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_descript_purpose.Location = New System.Drawing.Point(66, 60)
        Me.idinfo_descript_purpose.Multiline = True
        Me.idinfo_descript_purpose.Name = "idinfo_descript_purpose"
        Me.idinfo_descript_purpose.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.idinfo_descript_purpose.Size = New System.Drawing.Size(376, 50)
        Me.idinfo_descript_purpose.TabIndex = 0
        '
        'idinfo_descript_abstract
        '
        Me.idinfo_descript_abstract.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_descript_abstract.Location = New System.Drawing.Point(66, 5)
        Me.idinfo_descript_abstract.Multiline = True
        Me.idinfo_descript_abstract.Name = "idinfo_descript_abstract"
        Me.idinfo_descript_abstract.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.idinfo_descript_abstract.Size = New System.Drawing.Size(376, 50)
        Me.idinfo_descript_abstract.TabIndex = 1
        '
        'idinfo_descript_abstract_____help
        '
        Me.idinfo_descript_abstract_____help.AutoSize = True
        Me.idinfo_descript_abstract_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_descript_abstract_____help.Location = New System.Drawing.Point(13, 19)
        Me.idinfo_descript_abstract_____help.Name = "idinfo_descript_abstract_____help"
        Me.idinfo_descript_abstract_____help.Size = New System.Drawing.Size(52, 13)
        Me.idinfo_descript_abstract_____help.TabIndex = 0
        Me.idinfo_descript_abstract_____help.TabStop = True
        Me.idinfo_descript_abstract_____help.Text = "Abstract:"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Panel3.Controls.Add(Me.idinfo_descript_supplinf_____warning)
        Me.Panel3.Controls.Add(Me.idinfo_descript_supplinf)
        Me.Panel3.Controls.Add(Me.idinfo_descript_supplinf_____help)
        Me.Panel3.Location = New System.Drawing.Point(6, 137)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(446, 30)
        Me.Panel3.TabIndex = 0
        '
        'idinfo_descript_supplinf_____warning
        '
        Me.idinfo_descript_supplinf_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_descript_supplinf_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.idinfo_descript_supplinf_____warning.Location = New System.Drawing.Point(106, 9)
        Me.idinfo_descript_supplinf_____warning.Name = "idinfo_descript_supplinf_____warning"
        Me.idinfo_descript_supplinf_____warning.Size = New System.Drawing.Size(13, 14)
        Me.idinfo_descript_supplinf_____warning.TabIndex = 38
        Me.idinfo_descript_supplinf_____warning.TabStop = False
        Me.idinfo_descript_supplinf_____warning.Visible = False
        '
        'idinfo_descript_supplinf
        '
        Me.idinfo_descript_supplinf.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_descript_supplinf.Location = New System.Drawing.Point(117, 6)
        Me.idinfo_descript_supplinf.Name = "idinfo_descript_supplinf"
        Me.idinfo_descript_supplinf.Size = New System.Drawing.Size(325, 21)
        Me.idinfo_descript_supplinf.TabIndex = 1
        '
        'idinfo_descript_supplinf_____help
        '
        Me.idinfo_descript_supplinf_____help.AutoSize = True
        Me.idinfo_descript_supplinf_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idinfo_descript_supplinf_____help.Location = New System.Drawing.Point(7, 9)
        Me.idinfo_descript_supplinf_____help.Name = "idinfo_descript_supplinf_____help"
        Me.idinfo_descript_supplinf_____help.Size = New System.Drawing.Size(98, 13)
        Me.idinfo_descript_supplinf_____help.TabIndex = 0
        Me.idinfo_descript_supplinf_____help.TabStop = True
        Me.idinfo_descript_supplinf_____help.Text = "Supplemental Info:"
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel4.Location = New System.Drawing.Point(-248, 431)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(20, 20)
        Me.Panel4.TabIndex = 27
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(-318, 435)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(59, 13)
        Me.Label1.TabIndex = 26
        Me.Label1.Text = "mandatory"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel2.Location = New System.Drawing.Point(-342, 431)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(20, 20)
        Me.Panel2.TabIndex = 25
        '
        'btnCloseDiscard
        '
        Me.btnCloseDiscard.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCloseDiscard.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCloseDiscard.Location = New System.Drawing.Point(754, 581)
        Me.btnCloseDiscard.Name = "btnCloseDiscard"
        Me.btnCloseDiscard.Size = New System.Drawing.Size(58, 25)
        Me.btnCloseDiscard.TabIndex = 23
        Me.btnCloseDiscard.Text = "Cancel"
        Me.btnCloseDiscard.UseVisualStyleBackColor = True
        '
        'btnCloseSave
        '
        Me.btnCloseSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCloseSave.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCloseSave.Location = New System.Drawing.Point(659, 581)
        Me.btnCloseSave.Name = "btnCloseSave"
        Me.btnCloseSave.Size = New System.Drawing.Size(85, 25)
        Me.btnCloseSave.TabIndex = 22
        Me.btnCloseSave.Text = "Save && Close"
        Me.btnCloseSave.UseVisualStyleBackColor = True
        '
        'tcEME
        '
        Me.tcEME.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tcEME.Controls.Add(Me.TabPage1)
        Me.tcEME.Controls.Add(Me.TabPage2)
        Me.tcEME.Controls.Add(Me.TabPage3)
        Me.tcEME.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tcEME.Location = New System.Drawing.Point(1, 31)
        Me.tcEME.Name = "tcEME"
        Me.tcEME.SelectedIndex = 0
        Me.tcEME.Size = New System.Drawing.Size(814, 544)
        Me.tcEME.TabIndex = 21
        Me.tcEME.Tag = ""
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.GroupBox13)
        Me.TabPage2.Controls.Add(Me.GroupBox12)
        Me.TabPage2.Controls.Add(Me.GroupBox10)
        Me.TabPage2.Controls.Add(Me.GroupBox11)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(806, 518)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Quality, Coordinate System, and Attribute Information"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'GroupBox13
        '
        Me.GroupBox13.Controls.Add(Me.eainfo_____warning)
        Me.GroupBox13.Controls.Add(Me.tcEntityAttr)
        Me.GroupBox13.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox13.ForeColor = System.Drawing.Color.Black
        Me.GroupBox13.Location = New System.Drawing.Point(455, 129)
        Me.GroupBox13.Name = "GroupBox13"
        Me.GroupBox13.Size = New System.Drawing.Size(344, 387)
        Me.GroupBox13.TabIndex = 21
        Me.GroupBox13.TabStop = False
        Me.GroupBox13.Text = "Entity and Attribute Information"
        '
        'eainfo_____warning
        '
        Me.eainfo_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.eainfo_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.eainfo_____warning.Location = New System.Drawing.Point(133, 0)
        Me.eainfo_____warning.Name = "eainfo_____warning"
        Me.eainfo_____warning.Size = New System.Drawing.Size(13, 14)
        Me.eainfo_____warning.TabIndex = 52
        Me.eainfo_____warning.TabStop = False
        Me.eainfo_____warning.Visible = False
        '
        'tcEntityAttr
        '
        Me.tcEntityAttr.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tcEntityAttr.Controls.Add(Me.TabPage8)
        Me.tcEntityAttr.Controls.Add(Me.TabPage9)
        Me.tcEntityAttr.Location = New System.Drawing.Point(6, 16)
        Me.tcEntityAttr.Name = "tcEntityAttr"
        Me.tcEntityAttr.SelectedIndex = 0
        Me.tcEntityAttr.Size = New System.Drawing.Size(332, 365)
        Me.tcEntityAttr.TabIndex = 40
        '
        'TabPage8
        '
        Me.TabPage8.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TabPage8.Controls.Add(Me.eainfo_overview_eadetcit_____warning)
        Me.TabPage8.Controls.Add(Me.eainfo_overview_eadetcit_____help)
        Me.TabPage8.Controls.Add(Me.eainfo_overview_eaover_____warning)
        Me.TabPage8.Controls.Add(Me.Label66)
        Me.TabPage8.Controls.Add(Me.eainfo_overview_eadetcit_____default)
        Me.TabPage8.Controls.Add(Me.eainfo_overview_eaover_____help)
        Me.TabPage8.Controls.Add(Me.Label61)
        Me.TabPage8.Controls.Add(Me.eainfo_overview_eadetcit)
        Me.TabPage8.Controls.Add(Me.eainfo_overview_eaover)
        Me.TabPage8.Location = New System.Drawing.Point(4, 22)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage8.Size = New System.Drawing.Size(324, 339)
        Me.TabPage8.TabIndex = 0
        Me.TabPage8.Text = "Overview"
        '
        'eainfo_overview_eadetcit_____warning
        '
        Me.eainfo_overview_eadetcit_____warning.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.eainfo_overview_eadetcit_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.eainfo_overview_eadetcit_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.eainfo_overview_eadetcit_____warning.Location = New System.Drawing.Point(61, 315)
        Me.eainfo_overview_eadetcit_____warning.Name = "eainfo_overview_eadetcit_____warning"
        Me.eainfo_overview_eadetcit_____warning.Size = New System.Drawing.Size(13, 14)
        Me.eainfo_overview_eadetcit_____warning.TabIndex = 50
        Me.eainfo_overview_eadetcit_____warning.TabStop = False
        Me.eainfo_overview_eadetcit_____warning.Visible = False
        '
        'eainfo_overview_eadetcit_____help
        '
        Me.eainfo_overview_eadetcit_____help.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.eainfo_overview_eadetcit_____help.AutoSize = True
        Me.eainfo_overview_eadetcit_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.eainfo_overview_eadetcit_____help.Location = New System.Drawing.Point(20, 315)
        Me.eainfo_overview_eadetcit_____help.Name = "eainfo_overview_eadetcit_____help"
        Me.eainfo_overview_eadetcit_____help.Size = New System.Drawing.Size(48, 13)
        Me.eainfo_overview_eadetcit_____help.TabIndex = 35
        Me.eainfo_overview_eadetcit_____help.TabStop = True
        Me.eainfo_overview_eadetcit_____help.Text = "Citation:"
        '
        'eainfo_overview_eaover_____warning
        '
        Me.eainfo_overview_eaover_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.eainfo_overview_eaover_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.eainfo_overview_eaover_____warning.Location = New System.Drawing.Point(126, 3)
        Me.eainfo_overview_eaover_____warning.Name = "eainfo_overview_eaover_____warning"
        Me.eainfo_overview_eaover_____warning.Size = New System.Drawing.Size(13, 14)
        Me.eainfo_overview_eaover_____warning.TabIndex = 51
        Me.eainfo_overview_eaover_____warning.TabStop = False
        Me.eainfo_overview_eaover_____warning.Visible = False
        '
        'Label66
        '
        Me.Label66.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label66.AutoSize = True
        Me.Label66.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label66.ForeColor = System.Drawing.Color.Black
        Me.Label66.Location = New System.Drawing.Point(4, 315)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(19, 13)
        Me.Label66.TabIndex = 36
        Me.Label66.Text = "**"
        '
        'eainfo_overview_eaover_____help
        '
        Me.eainfo_overview_eaover_____help.AutoSize = True
        Me.eainfo_overview_eaover_____help.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.eainfo_overview_eaover_____help.Location = New System.Drawing.Point(20, 2)
        Me.eainfo_overview_eaover_____help.Name = "eainfo_overview_eaover_____help"
        Me.eainfo_overview_eaover_____help.Size = New System.Drawing.Size(109, 13)
        Me.eainfo_overview_eaover_____help.TabIndex = 33
        Me.eainfo_overview_eaover_____help.TabStop = True
        Me.eainfo_overview_eaover_____help.Text = "Overview Description"
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label61.ForeColor = System.Drawing.Color.Black
        Me.Label61.Location = New System.Drawing.Point(6, 3)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(19, 13)
        Me.Label61.TabIndex = 34
        Me.Label61.Text = "**"
        '
        'eainfo_overview_eadetcit
        '
        Me.eainfo_overview_eadetcit.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.eainfo_overview_eadetcit.FormattingEnabled = True
        Me.eainfo_overview_eadetcit.Location = New System.Drawing.Point(74, 312)
        Me.eainfo_overview_eadetcit.Name = "eainfo_overview_eadetcit"
        Me.eainfo_overview_eadetcit.Size = New System.Drawing.Size(244, 21)
        Me.eainfo_overview_eadetcit.TabIndex = 0
        '
        'eainfo_overview_eaover
        '
        Me.eainfo_overview_eaover.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.eainfo_overview_eaover.Location = New System.Drawing.Point(6, 23)
        Me.eainfo_overview_eaover.MaxLength = 0
        Me.eainfo_overview_eaover.Multiline = True
        Me.eainfo_overview_eaover.Name = "eainfo_overview_eaover"
        Me.eainfo_overview_eaover.Size = New System.Drawing.Size(313, 283)
        Me.eainfo_overview_eaover.TabIndex = 1
        '
        'TabPage9
        '
        Me.TabPage9.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TabPage9.Controls.Add(Me.GroupBox8)
        Me.TabPage9.Controls.Add(Me.grpDomain)
        Me.TabPage9.Controls.Add(Me.grpAttr)
        Me.TabPage9.Location = New System.Drawing.Point(4, 22)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage9.Size = New System.Drawing.Size(324, 339)
        Me.TabPage9.TabIndex = 1
        Me.TabPage9.Text = "Detailed"
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.btnDeleteEntity)
        Me.GroupBox8.Controls.Add(Me.btnAddEntity)
        Me.GroupBox8.Controls.Add(Me.enttypd)
        Me.GroupBox8.Controls.Add(Me.enttyp_____help2)
        Me.GroupBox8.Controls.Add(Me.detailed_____help2)
        Me.GroupBox8.Controls.Add(Me.enttypds_____help2)
        Me.GroupBox8.Controls.Add(Me.enttypd_____help2)
        Me.GroupBox8.Controls.Add(Me.enttypds)
        Me.GroupBox8.Controls.Add(Me.enttypl)
        Me.GroupBox8.Controls.Add(Me.enttypl_____help2)
        Me.GroupBox8.Location = New System.Drawing.Point(2, 5)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(319, 81)
        Me.GroupBox8.TabIndex = 10
        Me.GroupBox8.TabStop = False
        '
        'btnDeleteEntity
        '
        Me.btnDeleteEntity.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.btnDeleteEntity.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDeleteEntity.Image = Global.MetadataEditor.My.Resources.Resources.minus
        Me.btnDeleteEntity.Location = New System.Drawing.Point(67, 11)
        Me.btnDeleteEntity.Name = "btnDeleteEntity"
        Me.btnDeleteEntity.Size = New System.Drawing.Size(16, 16)
        Me.btnDeleteEntity.TabIndex = 41
        Me.btnDeleteEntity.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnDeleteEntity.UseVisualStyleBackColor = False
        '
        'btnAddEntity
        '
        Me.btnAddEntity.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.btnAddEntity.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddEntity.Image = Global.MetadataEditor.My.Resources.Resources.plus
        Me.btnAddEntity.Location = New System.Drawing.Point(45, 11)
        Me.btnAddEntity.Name = "btnAddEntity"
        Me.btnAddEntity.Size = New System.Drawing.Size(16, 16)
        Me.btnAddEntity.TabIndex = 40
        Me.btnAddEntity.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnAddEntity.UseVisualStyleBackColor = False
        '
        'enttypd
        '
        Me.enttypd.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.enttypd.Location = New System.Drawing.Point(63, 57)
        Me.enttypd.Name = "enttypd"
        Me.enttypd.Size = New System.Drawing.Size(248, 21)
        Me.enttypd.TabIndex = 39
        '
        'enttyp_____help2
        '
        Me.enttyp_____help2.AutoSize = True
        Me.enttyp_____help2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.enttyp_____help2.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.enttyp_____help2.Location = New System.Drawing.Point(7, -3)
        Me.enttyp_____help2.Name = "enttyp_____help2"
        Me.enttyp_____help2.Size = New System.Drawing.Size(94, 13)
        Me.enttyp_____help2.TabIndex = 38
        Me.enttyp_____help2.TabStop = True
        Me.enttyp_____help2.Text = "Entity Information"
        '
        'detailed_____help2
        '
        Me.detailed_____help2.AutoSize = True
        Me.detailed_____help2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.detailed_____help2.Location = New System.Drawing.Point(294, -3)
        Me.detailed_____help2.Name = "detailed_____help2"
        Me.detailed_____help2.Size = New System.Drawing.Size(28, 13)
        Me.detailed_____help2.TabIndex = 37
        Me.detailed_____help2.TabStop = True
        Me.detailed_____help2.Text = "Help"
        '
        'enttypds_____help2
        '
        Me.enttypds_____help2.AutoSize = True
        Me.enttypds_____help2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.enttypds_____help2.Location = New System.Drawing.Point(150, 13)
        Me.enttypds_____help2.Name = "enttypds_____help2"
        Me.enttypds_____help2.Size = New System.Drawing.Size(88, 13)
        Me.enttypds_____help2.TabIndex = 11
        Me.enttypds_____help2.Text = "Definition Source"
        '
        'enttypd_____help2
        '
        Me.enttypd_____help2.AutoSize = True
        Me.enttypd_____help2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.enttypd_____help2.Location = New System.Drawing.Point(6, 60)
        Me.enttypd_____help2.Name = "enttypd_____help2"
        Me.enttypd_____help2.Size = New System.Drawing.Size(52, 13)
        Me.enttypd_____help2.TabIndex = 10
        Me.enttypd_____help2.Text = "Definition"
        '
        'enttypds
        '
        Me.enttypds.DisplayMember = "displayName"
        Me.enttypds.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.enttypds.FormattingEnabled = True
        Me.enttypds.Location = New System.Drawing.Point(153, 31)
        Me.enttypds.Name = "enttypds"
        Me.enttypds.Size = New System.Drawing.Size(158, 21)
        Me.enttypds.TabIndex = 9
        '
        'enttypl
        '
        Me.enttypl.DisplayMember = "displayName"
        Me.enttypl.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.enttypl.FormattingEnabled = True
        Me.enttypl.Location = New System.Drawing.Point(8, 31)
        Me.enttypl.Name = "enttypl"
        Me.enttypl.Size = New System.Drawing.Size(141, 21)
        Me.enttypl.TabIndex = 7
        '
        'enttypl_____help2
        '
        Me.enttypl_____help2.AutoSize = True
        Me.enttypl_____help2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.enttypl_____help2.Location = New System.Drawing.Point(6, 13)
        Me.enttypl_____help2.Name = "enttypl_____help2"
        Me.enttypl_____help2.Size = New System.Drawing.Size(32, 13)
        Me.enttypl_____help2.TabIndex = 3
        Me.enttypl_____help2.Text = "Label"
        '
        'grpDomain
        '
        Me.grpDomain.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpDomain.Controls.Add(Me.attrdomv_____help2)
        Me.grpDomain.Controls.Add(Me.tcDomain)
        Me.grpDomain.Location = New System.Drawing.Point(3, 173)
        Me.grpDomain.Name = "grpDomain"
        Me.grpDomain.Size = New System.Drawing.Size(318, 163)
        Me.grpDomain.TabIndex = 9
        Me.grpDomain.TabStop = False
        '
        'attrdomv_____help2
        '
        Me.attrdomv_____help2.AutoSize = True
        Me.attrdomv_____help2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.attrdomv_____help2.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.attrdomv_____help2.Location = New System.Drawing.Point(9, -3)
        Me.attrdomv_____help2.Name = "attrdomv_____help2"
        Me.attrdomv_____help2.Size = New System.Drawing.Size(101, 13)
        Me.attrdomv_____help2.TabIndex = 40
        Me.attrdomv_____help2.TabStop = True
        Me.attrdomv_____help2.Text = "Domain Information"
        '
        'tcDomain
        '
        Me.tcDomain.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tcDomain.Controls.Add(Me.tp_rdom)
        Me.tcDomain.Controls.Add(Me.tp_codesetd)
        Me.tcDomain.Controls.Add(Me.tp_edom)
        Me.tcDomain.Controls.Add(Me.tp_udom)
        Me.tcDomain.Location = New System.Drawing.Point(3, 13)
        Me.tcDomain.Name = "tcDomain"
        Me.tcDomain.SelectedIndex = 0
        Me.tcDomain.Size = New System.Drawing.Size(309, 150)
        Me.tcDomain.TabIndex = 8
        '
        'tp_rdom
        '
        Me.tp_rdom.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.tp_rdom.Controls.Add(Me.rdommax)
        Me.tp_rdom.Controls.Add(Me.rdommax_____help2)
        Me.tp_rdom.Controls.Add(Me.rdommin_____help2)
        Me.tp_rdom.Controls.Add(Me.rdommin)
        Me.tp_rdom.Location = New System.Drawing.Point(4, 22)
        Me.tp_rdom.Name = "tp_rdom"
        Me.tp_rdom.Padding = New System.Windows.Forms.Padding(3)
        Me.tp_rdom.Size = New System.Drawing.Size(301, 124)
        Me.tp_rdom.TabIndex = 0
        Me.tp_rdom.Text = "Range"
        '
        'rdommax
        '
        Me.rdommax.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdommax.Location = New System.Drawing.Point(43, 54)
        Me.rdommax.Name = "rdommax"
        Me.rdommax.Size = New System.Drawing.Size(207, 21)
        Me.rdommax.TabIndex = 11
        '
        'rdommax_____help2
        '
        Me.rdommax_____help2.AutoSize = True
        Me.rdommax_____help2.Location = New System.Drawing.Point(10, 57)
        Me.rdommax_____help2.Name = "rdommax_____help2"
        Me.rdommax_____help2.Size = New System.Drawing.Size(31, 13)
        Me.rdommax_____help2.TabIndex = 10
        Me.rdommax_____help2.Text = "Max"
        '
        'rdommin_____help2
        '
        Me.rdommin_____help2.AutoSize = True
        Me.rdommin_____help2.Location = New System.Drawing.Point(10, 22)
        Me.rdommin_____help2.Name = "rdommin_____help2"
        Me.rdommin_____help2.Size = New System.Drawing.Size(27, 13)
        Me.rdommin_____help2.TabIndex = 9
        Me.rdommin_____help2.Text = "Min"
        '
        'rdommin
        '
        Me.rdommin.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdommin.Location = New System.Drawing.Point(43, 19)
        Me.rdommin.Name = "rdommin"
        Me.rdommin.Size = New System.Drawing.Size(207, 21)
        Me.rdommin.TabIndex = 0
        '
        'tp_codesetd
        '
        Me.tp_codesetd.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.tp_codesetd.Controls.Add(Me.codesetn)
        Me.tp_codesetd.Controls.Add(Me.codesets_____help2)
        Me.tp_codesetd.Controls.Add(Me.codesetn_____help2)
        Me.tp_codesetd.Controls.Add(Me.codesets)
        Me.tp_codesetd.Location = New System.Drawing.Point(4, 22)
        Me.tp_codesetd.Name = "tp_codesetd"
        Me.tp_codesetd.Padding = New System.Windows.Forms.Padding(3)
        Me.tp_codesetd.Size = New System.Drawing.Size(301, 124)
        Me.tp_codesetd.TabIndex = 1
        Me.tp_codesetd.Text = "Codeset"
        '
        'codesetn
        '
        Me.codesetn.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.codesetn.Location = New System.Drawing.Point(60, 19)
        Me.codesetn.Name = "codesetn"
        Me.codesetn.Size = New System.Drawing.Size(225, 21)
        Me.codesetn.TabIndex = 41
        '
        'codesets_____help2
        '
        Me.codesets_____help2.AutoSize = True
        Me.codesets_____help2.Location = New System.Drawing.Point(10, 57)
        Me.codesets_____help2.Name = "codesets_____help2"
        Me.codesets_____help2.Size = New System.Drawing.Size(46, 13)
        Me.codesets_____help2.TabIndex = 8
        Me.codesets_____help2.Text = "Source"
        '
        'codesetn_____help2
        '
        Me.codesetn_____help2.AutoSize = True
        Me.codesetn_____help2.Location = New System.Drawing.Point(10, 22)
        Me.codesetn_____help2.Name = "codesetn_____help2"
        Me.codesetn_____help2.Size = New System.Drawing.Size(39, 13)
        Me.codesetn_____help2.TabIndex = 7
        Me.codesetn_____help2.Text = "Name"
        '
        'codesets
        '
        Me.codesets.DisplayMember = "displayName"
        Me.codesets.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.codesets.FormattingEnabled = True
        Me.codesets.Location = New System.Drawing.Point(60, 54)
        Me.codesets.Name = "codesets"
        Me.codesets.Size = New System.Drawing.Size(225, 21)
        Me.codesets.TabIndex = 4
        '
        'tp_edom
        '
        Me.tp_edom.Controls.Add(Me.dgv_edom)
        Me.tp_edom.Location = New System.Drawing.Point(4, 22)
        Me.tp_edom.Name = "tp_edom"
        Me.tp_edom.Padding = New System.Windows.Forms.Padding(3)
        Me.tp_edom.Size = New System.Drawing.Size(301, 124)
        Me.tp_edom.TabIndex = 2
        Me.tp_edom.Text = "Enumerated"
        Me.tp_edom.UseVisualStyleBackColor = True
        '
        'dgv_edom
        '
        Me.dgv_edom.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.dgv_edom.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_edom.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Value, Me.Definition, Me.DefinitionSource})
        Me.dgv_edom.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgv_edom.Location = New System.Drawing.Point(3, 3)
        Me.dgv_edom.Name = "dgv_edom"
        Me.dgv_edom.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_edom.RowHeadersDefaultCellStyle = DataGridViewCellStyle8
        Me.dgv_edom.RowHeadersVisible = False
        Me.dgv_edom.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgv_edom.Size = New System.Drawing.Size(295, 118)
        Me.dgv_edom.TabIndex = 4
        '
        'Value
        '
        Me.Value.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft
        Me.Value.DefaultCellStyle = DataGridViewCellStyle5
        Me.Value.HeaderText = "Value"
        Me.Value.MinimumWidth = 4
        Me.Value.Name = "Value"
        Me.Value.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Value.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'Definition
        '
        Me.Definition.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft
        Me.Definition.DefaultCellStyle = DataGridViewCellStyle6
        Me.Definition.HeaderText = "Definition"
        Me.Definition.MinimumWidth = 4
        Me.Definition.Name = "Definition"
        Me.Definition.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Definition.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'DefinitionSource
        '
        Me.DefinitionSource.AutoComplete = False
        Me.DefinitionSource.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft
        Me.DefinitionSource.DefaultCellStyle = DataGridViewCellStyle7
        Me.DefinitionSource.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox
        Me.DefinitionSource.HeaderText = "Defn Src"
        Me.DefinitionSource.MinimumWidth = 4
        Me.DefinitionSource.Name = "DefinitionSource"
        '
        'tp_udom
        '
        Me.tp_udom.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.tp_udom.Controls.Add(Me.udom)
        Me.tp_udom.Location = New System.Drawing.Point(4, 22)
        Me.tp_udom.Name = "tp_udom"
        Me.tp_udom.Padding = New System.Windows.Forms.Padding(3)
        Me.tp_udom.Size = New System.Drawing.Size(301, 124)
        Me.tp_udom.TabIndex = 3
        Me.tp_udom.Text = "Unrepresentable"
        '
        'udom
        '
        Me.udom.DisplayMember = "displayName"
        Me.udom.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.udom.FormattingEnabled = True
        Me.udom.Location = New System.Drawing.Point(6, 23)
        Me.udom.Name = "udom"
        Me.udom.Size = New System.Drawing.Size(293, 21)
        Me.udom.TabIndex = 1
        '
        'grpAttr
        '
        Me.grpAttr.Controls.Add(Me.btnDeleteAttribute)
        Me.grpAttr.Controls.Add(Me.btnAddAttribute)
        Me.grpAttr.Controls.Add(Me.attrdef)
        Me.grpAttr.Controls.Add(Me.attr_____help2)
        Me.grpAttr.Controls.Add(Me.attrdefs_____help2)
        Me.grpAttr.Controls.Add(Me.attrdef_____help2)
        Me.grpAttr.Controls.Add(Me.attrlabl_____help2)
        Me.grpAttr.Controls.Add(Me.attrdefs)
        Me.grpAttr.Controls.Add(Me.attrlabl)
        Me.grpAttr.Location = New System.Drawing.Point(2, 87)
        Me.grpAttr.Name = "grpAttr"
        Me.grpAttr.Size = New System.Drawing.Size(319, 83)
        Me.grpAttr.TabIndex = 8
        Me.grpAttr.TabStop = False
        '
        'btnDeleteAttribute
        '
        Me.btnDeleteAttribute.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.btnDeleteAttribute.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDeleteAttribute.Image = Global.MetadataEditor.My.Resources.Resources.minus
        Me.btnDeleteAttribute.Location = New System.Drawing.Point(67, 12)
        Me.btnDeleteAttribute.Name = "btnDeleteAttribute"
        Me.btnDeleteAttribute.Size = New System.Drawing.Size(16, 16)
        Me.btnDeleteAttribute.TabIndex = 43
        Me.btnDeleteAttribute.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnDeleteAttribute.UseVisualStyleBackColor = False
        '
        'btnAddAttribute
        '
        Me.btnAddAttribute.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.btnAddAttribute.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddAttribute.Image = Global.MetadataEditor.My.Resources.Resources.plus
        Me.btnAddAttribute.Location = New System.Drawing.Point(45, 12)
        Me.btnAddAttribute.Name = "btnAddAttribute"
        Me.btnAddAttribute.Size = New System.Drawing.Size(16, 16)
        Me.btnAddAttribute.TabIndex = 42
        Me.btnAddAttribute.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnAddAttribute.UseVisualStyleBackColor = False
        '
        'attrdef
        '
        Me.attrdef.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.attrdef.Location = New System.Drawing.Point(63, 59)
        Me.attrdef.Name = "attrdef"
        Me.attrdef.Size = New System.Drawing.Size(248, 21)
        Me.attrdef.TabIndex = 40
        '
        'attr_____help2
        '
        Me.attr_____help2.AutoSize = True
        Me.attr_____help2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.attr_____help2.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.attr_____help2.Location = New System.Drawing.Point(8, 0)
        Me.attr_____help2.Name = "attr_____help2"
        Me.attr_____help2.Size = New System.Drawing.Size(109, 13)
        Me.attr_____help2.TabIndex = 39
        Me.attr_____help2.TabStop = True
        Me.attr_____help2.Text = "Attribute Information"
        '
        'attrdefs_____help2
        '
        Me.attrdefs_____help2.AutoSize = True
        Me.attrdefs_____help2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.attrdefs_____help2.Location = New System.Drawing.Point(155, 15)
        Me.attrdefs_____help2.Name = "attrdefs_____help2"
        Me.attrdefs_____help2.Size = New System.Drawing.Size(88, 13)
        Me.attrdefs_____help2.TabIndex = 6
        Me.attrdefs_____help2.Text = "Definition Source"
        '
        'attrdef_____help2
        '
        Me.attrdef_____help2.AutoSize = True
        Me.attrdef_____help2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.attrdef_____help2.Location = New System.Drawing.Point(6, 62)
        Me.attrdef_____help2.Name = "attrdef_____help2"
        Me.attrdef_____help2.Size = New System.Drawing.Size(52, 13)
        Me.attrdef_____help2.TabIndex = 5
        Me.attrdef_____help2.Text = "Definition"
        '
        'attrlabl_____help2
        '
        Me.attrlabl_____help2.AutoSize = True
        Me.attrlabl_____help2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.attrlabl_____help2.Location = New System.Drawing.Point(7, 14)
        Me.attrlabl_____help2.Name = "attrlabl_____help2"
        Me.attrlabl_____help2.Size = New System.Drawing.Size(32, 13)
        Me.attrlabl_____help2.TabIndex = 4
        Me.attrlabl_____help2.Text = "Label"
        '
        'attrdefs
        '
        Me.attrdefs.DisplayMember = "displayName"
        Me.attrdefs.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.attrdefs.FormattingEnabled = True
        Me.attrdefs.Location = New System.Drawing.Point(155, 33)
        Me.attrdefs.Name = "attrdefs"
        Me.attrdefs.Size = New System.Drawing.Size(156, 21)
        Me.attrdefs.TabIndex = 2
        '
        'attrlabl
        '
        Me.attrlabl.DisplayMember = "displayName"
        Me.attrlabl.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.attrlabl.FormattingEnabled = True
        Me.attrlabl.Location = New System.Drawing.Point(8, 33)
        Me.attrlabl.Name = "attrlabl"
        Me.attrlabl.Size = New System.Drawing.Size(141, 21)
        Me.attrlabl.TabIndex = 0
        '
        'GroupBox12
        '
        Me.GroupBox12.Controls.Add(Me.spref_____warning)
        Me.GroupBox12.Controls.Add(Me.spref_horizsys)
        Me.GroupBox12.Controls.Add(Me.Panel14)
        Me.GroupBox12.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox12.ForeColor = System.Drawing.Color.Black
        Me.GroupBox12.Location = New System.Drawing.Point(455, 7)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Size = New System.Drawing.Size(344, 121)
        Me.GroupBox12.TabIndex = 20
        Me.GroupBox12.TabStop = False
        Me.GroupBox12.Text = "Coordinate System Information"
        '
        'spref_____warning
        '
        Me.spref_____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.spref_____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me.spref_____warning.Location = New System.Drawing.Point(189, 0)
        Me.spref_____warning.Name = "spref_____warning"
        Me.spref_____warning.Size = New System.Drawing.Size(13, 14)
        Me.spref_____warning.TabIndex = 44
        Me.spref_____warning.TabStop = False
        Me.spref_____warning.Visible = False
        '
        'spref_horizsys
        '
        Me.spref_horizsys.FormattingEnabled = True
        Me.spref_horizsys.Location = New System.Drawing.Point(254, 7)
        Me.spref_horizsys.Name = "spref_horizsys"
        Me.spref_horizsys.Size = New System.Drawing.Size(75, 21)
        Me.spref_horizsys.TabIndex = 22
        Me.spref_horizsys.Visible = False
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(465, 581)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(110, 26)
        Me.Label5.TabIndex = 33
        Me.Label5.Text = "Click on text to link to" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "  element description"
        '
        'Label4
        '
        Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(40, 3)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(45, 13)
        Me.Label4.TabIndex = 32
        Me.Label4.Text = "optional"
        '
        'Panel5
        '
        Me.Panel5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Panel5.Controls.Add(Me.Label84)
        Me.Panel5.Controls.Add(Me.Label4)
        Me.Panel5.Location = New System.Drawing.Point(326, 583)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(86, 20)
        Me.Panel5.TabIndex = 28
        '
        'Label84
        '
        Me.Label84.AutoSize = True
        Me.Label84.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label84.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label84.Location = New System.Drawing.Point(3, 4)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(31, 13)
        Me.Label84.TabIndex = 34
        Me.Label84.Text = "BLUE"
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(58, 3)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(118, 13)
        Me.Label3.TabIndex = 29
        Me.Label3.Text = "mandatory if applicable"
        '
        'Panel28
        '
        Me.Panel28.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel28.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel28.Controls.Add(Me.Label42)
        Me.Panel28.Controls.Add(Me.Label82)
        Me.Panel28.Controls.Add(Me.Label28)
        Me.Panel28.Location = New System.Drawing.Point(5, 583)
        Me.Panel28.Name = "Panel28"
        Me.Panel28.Size = New System.Drawing.Size(131, 20)
        Me.Panel28.TabIndex = 29
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label42.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.ForeColor = System.Drawing.Color.Black
        Me.Label42.Location = New System.Drawing.Point(48, 3)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(13, 13)
        Me.Label42.TabIndex = 24
        Me.Label42.Text = "*"
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label82.Location = New System.Drawing.Point(3, 3)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(47, 13)
        Me.Label82.TabIndex = 35
        Me.Label82.Text = "YELLOW"
        '
        'Label28
        '
        Me.Label28.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(63, 3)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(59, 13)
        Me.Label28.TabIndex = 34
        Me.Label28.Text = "mandatory"
        '
        'Panel29
        '
        Me.Panel29.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel29.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel29.Controls.Add(Me.Label85)
        Me.Panel29.Controls.Add(Me.Label83)
        Me.Panel29.Controls.Add(Me.Label3)
        Me.Panel29.Location = New System.Drawing.Point(142, 583)
        Me.Panel29.Name = "Panel29"
        Me.Panel29.Size = New System.Drawing.Size(178, 20)
        Me.Panel29.TabIndex = 30
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label85.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label85.ForeColor = System.Drawing.Color.Black
        Me.Label85.Location = New System.Drawing.Point(42, 4)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(19, 13)
        Me.Label85.TabIndex = 36
        Me.Label85.Text = "**"
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label83.Location = New System.Drawing.Point(3, 4)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(40, 13)
        Me.Label83.TabIndex = 30
        Me.Label83.Text = "GREEN"
        '
        'EMESpelling
        '
        Me.EMESpelling.Dictionary = Me.EMEWordDictionary
        '
        'HoverToolTip
        '
        Me.HoverToolTip.AutomaticDelay = 100
        Me.HoverToolTip.AutoPopDelay = 0
        Me.HoverToolTip.InitialDelay = 100
        Me.HoverToolTip.ReshowDelay = 20
        '
        'btnSave
        '
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSave.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.Location = New System.Drawing.Point(591, 581)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(58, 25)
        Me.btnSave.TabIndex = 34
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        '_____warning
        '
        Me._____warning.Image = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me._____warning.InitialImage = Global.MetadataEditor.My.Resources.Resources.BlinkingRedLed
        Me._____warning.Location = New System.Drawing.Point(417, 587)
        Me._____warning.Name = "_____warning"
        Me._____warning.Size = New System.Drawing.Size(13, 14)
        Me._____warning.TabIndex = 39
        Me._____warning.TabStop = False
        Me._____warning.Visible = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Transparent
        Me.MenuStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.EditToolStripMenuItem, Me.ToolsToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(5, 4)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(164, 24)
        Me.MenuStrip1.TabIndex = 44
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripMenuItem, Me.OpenToolStripMenuItem, Me.toolStripSeparator, Me.SaveToolStripMenuItem, Me.SaveAsToolStripMenuItem, Me.toolStripSeparator1, Me.PrintToolStripMenuItem, Me.PrintPreviewToolStripMenuItem, Me.toolStripSeparator2, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(35, 20)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'NewToolStripMenuItem
        '
        Me.NewToolStripMenuItem.Image = CType(resources.GetObject("NewToolStripMenuItem.Image"), System.Drawing.Image)
        Me.NewToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.NewToolStripMenuItem.Name = "NewToolStripMenuItem"
        Me.NewToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.NewToolStripMenuItem.Size = New System.Drawing.Size(149, 22)
        Me.NewToolStripMenuItem.Text = "&New"
        '
        'OpenToolStripMenuItem
        '
        Me.OpenToolStripMenuItem.Image = CType(resources.GetObject("OpenToolStripMenuItem.Image"), System.Drawing.Image)
        Me.OpenToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.OpenToolStripMenuItem.Name = "OpenToolStripMenuItem"
        Me.OpenToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.OpenToolStripMenuItem.Size = New System.Drawing.Size(149, 22)
        Me.OpenToolStripMenuItem.Text = "&Open"
        '
        'toolStripSeparator
        '
        Me.toolStripSeparator.Name = "toolStripSeparator"
        Me.toolStripSeparator.Size = New System.Drawing.Size(146, 6)
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.Image = CType(resources.GetObject("SaveToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SaveToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(149, 22)
        Me.SaveToolStripMenuItem.Text = "&Save"
        '
        'SaveAsToolStripMenuItem
        '
        Me.SaveAsToolStripMenuItem.Name = "SaveAsToolStripMenuItem"
        Me.SaveAsToolStripMenuItem.Size = New System.Drawing.Size(149, 22)
        Me.SaveAsToolStripMenuItem.Text = "Save &As..."
        '
        'toolStripSeparator1
        '
        Me.toolStripSeparator1.Name = "toolStripSeparator1"
        Me.toolStripSeparator1.Size = New System.Drawing.Size(146, 6)
        '
        'PrintToolStripMenuItem
        '
        Me.PrintToolStripMenuItem.Image = CType(resources.GetObject("PrintToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PrintToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PrintToolStripMenuItem.Name = "PrintToolStripMenuItem"
        Me.PrintToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.P), System.Windows.Forms.Keys)
        Me.PrintToolStripMenuItem.Size = New System.Drawing.Size(149, 22)
        Me.PrintToolStripMenuItem.Text = "&Print"
        Me.PrintToolStripMenuItem.Visible = False
        '
        'PrintPreviewToolStripMenuItem
        '
        Me.PrintPreviewToolStripMenuItem.Image = CType(resources.GetObject("PrintPreviewToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PrintPreviewToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PrintPreviewToolStripMenuItem.Name = "PrintPreviewToolStripMenuItem"
        Me.PrintPreviewToolStripMenuItem.Size = New System.Drawing.Size(149, 22)
        Me.PrintPreviewToolStripMenuItem.Text = "Print Pre&view..."
        Me.PrintPreviewToolStripMenuItem.Visible = False
        '
        'toolStripSeparator2
        '
        Me.toolStripSeparator2.Name = "toolStripSeparator2"
        Me.toolStripSeparator2.Size = New System.Drawing.Size(146, 6)
        Me.toolStripSeparator2.Visible = False
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(149, 22)
        Me.ExitToolStripMenuItem.Text = "E&xit"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UndoToolStripMenuItem, Me.RedoToolStripMenuItem, Me.toolStripSeparator3, Me.CutToolStripMenuItem, Me.CopyToolStripMenuItem, Me.PasteToolStripMenuItem, Me.toolStripSeparator4, Me.SelectAllToolStripMenuItem, Me.FindAndReplaceToolStripMenuItem, Me.SpellCheckToolStripMenuItem, Me.SetDefaultToolStripMenuItem})
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.EditToolStripMenuItem.Text = "&Edit"
        '
        'UndoToolStripMenuItem
        '
        Me.UndoToolStripMenuItem.Name = "UndoToolStripMenuItem"
        Me.UndoToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Z), System.Windows.Forms.Keys)
        Me.UndoToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.UndoToolStripMenuItem.Text = "&Undo"
        Me.UndoToolStripMenuItem.Visible = False
        '
        'RedoToolStripMenuItem
        '
        Me.RedoToolStripMenuItem.Name = "RedoToolStripMenuItem"
        Me.RedoToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Y), System.Windows.Forms.Keys)
        Me.RedoToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.RedoToolStripMenuItem.Text = "&Redo"
        Me.RedoToolStripMenuItem.Visible = False
        '
        'toolStripSeparator3
        '
        Me.toolStripSeparator3.Name = "toolStripSeparator3"
        Me.toolStripSeparator3.Size = New System.Drawing.Size(153, 6)
        Me.toolStripSeparator3.Visible = False
        '
        'CutToolStripMenuItem
        '
        Me.CutToolStripMenuItem.Image = CType(resources.GetObject("CutToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CutToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CutToolStripMenuItem.Name = "CutToolStripMenuItem"
        Me.CutToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
        Me.CutToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.CutToolStripMenuItem.Text = "Cu&t"
        Me.CutToolStripMenuItem.Visible = False
        '
        'CopyToolStripMenuItem
        '
        Me.CopyToolStripMenuItem.Image = CType(resources.GetObject("CopyToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CopyToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CopyToolStripMenuItem.Name = "CopyToolStripMenuItem"
        Me.CopyToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.CopyToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.CopyToolStripMenuItem.Text = "&Copy"
        Me.CopyToolStripMenuItem.Visible = False
        '
        'PasteToolStripMenuItem
        '
        Me.PasteToolStripMenuItem.Image = CType(resources.GetObject("PasteToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PasteToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PasteToolStripMenuItem.Name = "PasteToolStripMenuItem"
        Me.PasteToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.V), System.Windows.Forms.Keys)
        Me.PasteToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.PasteToolStripMenuItem.Text = "&Paste"
        Me.PasteToolStripMenuItem.Visible = False
        '
        'toolStripSeparator4
        '
        Me.toolStripSeparator4.Name = "toolStripSeparator4"
        Me.toolStripSeparator4.Size = New System.Drawing.Size(153, 6)
        Me.toolStripSeparator4.Visible = False
        '
        'SelectAllToolStripMenuItem
        '
        Me.SelectAllToolStripMenuItem.Name = "SelectAllToolStripMenuItem"
        Me.SelectAllToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.SelectAllToolStripMenuItem.Text = "Select &All"
        Me.SelectAllToolStripMenuItem.Visible = False
        '
        'FindAndReplaceToolStripMenuItem
        '
        Me.FindAndReplaceToolStripMenuItem.Name = "FindAndReplaceToolStripMenuItem"
        Me.FindAndReplaceToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.FindAndReplaceToolStripMenuItem.Text = "Find and Replace"
        '
        'SpellCheckToolStripMenuItem
        '
        Me.SpellCheckToolStripMenuItem.Name = "SpellCheckToolStripMenuItem"
        Me.SpellCheckToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.SpellCheckToolStripMenuItem.Text = "Spell Check"
        '
        'SetDefaultToolStripMenuItem
        '
        Me.SetDefaultToolStripMenuItem.Name = "SetDefaultToolStripMenuItem"
        Me.SetDefaultToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.SetDefaultToolStripMenuItem.Text = "Set Default"
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.SetValidationResultsToolStripMenuItem, Me.ValidateToolStripMenuItem, Me.ViewMetadataXMLToolStripMenuItem, Me.OpenDatabaseToolStripMenuItem, Me.RefreshFromDatabaseToolStripMenuItem, Me.RemoveESRITagsToolStripMenuItem})
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.ToolsToolStripMenuItem.Text = "&Tools"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LocalToolStripMenuItem, Me.ViaWebserviceToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(208, 22)
        Me.ToolStripMenuItem1.Text = "Configure Validation"
        '
        'LocalToolStripMenuItem
        '
        Me.LocalToolStripMenuItem.Checked = True
        Me.LocalToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.LocalToolStripMenuItem.Name = "LocalToolStripMenuItem"
        Me.LocalToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.LocalToolStripMenuItem.Text = "Local"
        '
        'ViaWebserviceToolStripMenuItem
        '
        Me.ViaWebserviceToolStripMenuItem.Checked = True
        Me.ViaWebserviceToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ViaWebserviceToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tbValidationTimeout})
        Me.ViaWebserviceToolStripMenuItem.Name = "ViaWebserviceToolStripMenuItem"
        Me.ViaWebserviceToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ViaWebserviceToolStripMenuItem.Text = "Via Webservice"
        '
        'tbValidationTimeout
        '
        Me.tbValidationTimeout.Name = "tbValidationTimeout"
        Me.tbValidationTimeout.Size = New System.Drawing.Size(100, 21)
        Me.tbValidationTimeout.ToolTipText = "Webservice timeout in seconds"
        '
        'SetValidationResultsToolStripMenuItem
        '
        Me.SetValidationResultsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ViewInUserInterfaceToolStripMenuItem, Me.ViewInBrowserWindowToolStripMenuItem})
        Me.SetValidationResultsToolStripMenuItem.Name = "SetValidationResultsToolStripMenuItem"
        Me.SetValidationResultsToolStripMenuItem.Size = New System.Drawing.Size(208, 22)
        Me.SetValidationResultsToolStripMenuItem.Text = "Configure Validation Results"
        '
        'ViewInUserInterfaceToolStripMenuItem
        '
        Me.ViewInUserInterfaceToolStripMenuItem.Checked = True
        Me.ViewInUserInterfaceToolStripMenuItem.CheckOnClick = True
        Me.ViewInUserInterfaceToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ViewInUserInterfaceToolStripMenuItem.Name = "ViewInUserInterfaceToolStripMenuItem"
        Me.ViewInUserInterfaceToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
        Me.ViewInUserInterfaceToolStripMenuItem.Text = "View In User Interface"
        '
        'ViewInBrowserWindowToolStripMenuItem
        '
        Me.ViewInBrowserWindowToolStripMenuItem.Checked = True
        Me.ViewInBrowserWindowToolStripMenuItem.CheckOnClick = True
        Me.ViewInBrowserWindowToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ViewInBrowserWindowToolStripMenuItem.Name = "ViewInBrowserWindowToolStripMenuItem"
        Me.ViewInBrowserWindowToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
        Me.ViewInBrowserWindowToolStripMenuItem.Text = "View in Browser Window"
        '
        'ValidateToolStripMenuItem
        '
        Me.ValidateToolStripMenuItem.Name = "ValidateToolStripMenuItem"
        Me.ValidateToolStripMenuItem.Size = New System.Drawing.Size(208, 22)
        Me.ValidateToolStripMenuItem.Text = "Validate Metadata"
        '
        'ViewMetadataXMLToolStripMenuItem
        '
        Me.ViewMetadataXMLToolStripMenuItem.Name = "ViewMetadataXMLToolStripMenuItem"
        Me.ViewMetadataXMLToolStripMenuItem.Size = New System.Drawing.Size(208, 22)
        Me.ViewMetadataXMLToolStripMenuItem.Text = "View Metadata XML"
        '
        'OpenDatabaseToolStripMenuItem
        '
        Me.OpenDatabaseToolStripMenuItem.Name = "OpenDatabaseToolStripMenuItem"
        Me.OpenDatabaseToolStripMenuItem.Size = New System.Drawing.Size(208, 22)
        Me.OpenDatabaseToolStripMenuItem.Text = "Open Database"
        '
        'RefreshFromDatabaseToolStripMenuItem
        '
        Me.RefreshFromDatabaseToolStripMenuItem.Name = "RefreshFromDatabaseToolStripMenuItem"
        Me.RefreshFromDatabaseToolStripMenuItem.Size = New System.Drawing.Size(208, 22)
        Me.RefreshFromDatabaseToolStripMenuItem.Text = "Refresh From Database"
        '
        'RemoveESRITagsToolStripMenuItem
        '
        Me.RemoveESRITagsToolStripMenuItem.Name = "RemoveESRITagsToolStripMenuItem"
        Me.RemoveESRITagsToolStripMenuItem.Size = New System.Drawing.Size(208, 22)
        Me.RemoveESRITagsToolStripMenuItem.Text = "Remove ESRI Tags"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContentsToolStripMenuItem, Me.IndexToolStripMenuItem, Me.SearchToolStripMenuItem, Me.toolStripSeparator5, Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(40, 20)
        Me.HelpToolStripMenuItem.Text = "&Help"
        '
        'ContentsToolStripMenuItem
        '
        Me.ContentsToolStripMenuItem.Name = "ContentsToolStripMenuItem"
        Me.ContentsToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ContentsToolStripMenuItem.Text = "&Contents"
        '
        'IndexToolStripMenuItem
        '
        Me.IndexToolStripMenuItem.Name = "IndexToolStripMenuItem"
        Me.IndexToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.IndexToolStripMenuItem.Text = "&Index"
        Me.IndexToolStripMenuItem.Visible = False
        '
        'SearchToolStripMenuItem
        '
        Me.SearchToolStripMenuItem.Name = "SearchToolStripMenuItem"
        Me.SearchToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.SearchToolStripMenuItem.Text = "&Search"
        Me.SearchToolStripMenuItem.Visible = False
        '
        'toolStripSeparator5
        '
        Me.toolStripSeparator5.Name = "toolStripSeparator5"
        Me.toolStripSeparator5.Size = New System.Drawing.Size(149, 6)
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.AboutToolStripMenuItem.Text = "&About..."
        '
        'EditorForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(814, 608)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me._____warning)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.Panel28)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.ComboBox22)
        Me.Controls.Add(Me.LinkLabel37)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.btnCloseDiscard)
        Me.Controls.Add(Me.btnCloseSave)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Panel29)
        Me.Controls.Add(Me.tcEME)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "EditorForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "EPA Metadata Editor"
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        CType(Me.dataqual_complete_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dataqual_logic_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel10.ResumeLayout(False)
        Me.Panel10.PerformLayout()
        CType(Me.dataqual_posacc_horizpa_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dataqual_posacc_horizpa_horizpar_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox11.PerformLayout()
        CType(Me.dataqual_lineage_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dataqual_lineage_procstep_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel30.ResumeLayout(False)
        Me.Panel30.PerformLayout()
        CType(Me.dataqual_lineage_procstep, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel12.ResumeLayout(False)
        Me.Panel12.PerformLayout()
        CType(Me.dataqual_posacc_vertacc_qvertpa_vertaccv_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dataqual_posacc_vertacc_qvertpa_vertacce_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox10.ResumeLayout(False)
        CType(Me.dataqual_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel11.ResumeLayout(False)
        Me.Panel11.PerformLayout()
        CType(Me.dataqual_posacc_horizpa_qhorizpa_horizpae_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dataqual_posacc_horizpa_qhorizpa_horizpav_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel13.ResumeLayout(False)
        Me.Panel13.PerformLayout()
        CType(Me.dataqual_posacc_vertacc_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dataqual_posacc_vertacc_vertaccr_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel14.ResumeLayout(False)
        Me.Panel14.PerformLayout()
        CType(Me.spref_horizsys_Datum_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spref_horizsys_Units_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spref_horizsys_Zone_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spref_horizsys_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spref_horizsys_CoordinateSystem_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel18.ResumeLayout(False)
        Me.Panel18.PerformLayout()
        CType(Me.distinfo_distliab_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox14.ResumeLayout(False)
        Me.Panel17.ResumeLayout(False)
        Me.Panel17.PerformLayout()
        CType(Me.distinfo_resdesc_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel16.ResumeLayout(False)
        Me.Panel16.PerformLayout()
        CType(Me.distinfo_distrib_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.distinfo_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel21.ResumeLayout(False)
        Me.Panel21.PerformLayout()
        CType(Me.metainfo_metstdv_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.metainfo_metstdn_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel20.ResumeLayout(False)
        Me.Panel20.PerformLayout()
        CType(Me.metainfo_metc_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox17.ResumeLayout(False)
        CType(Me.metainfo_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel19.ResumeLayout(False)
        Me.Panel19.PerformLayout()
        CType(Me.metainfo_metfrd_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.metainfo_metd_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.idinfo_citation_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel23.ResumeLayout(False)
        Me.Panel23.PerformLayout()
        CType(Me.idinfo_citation_citeinfo_onlink_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel22.ResumeLayout(False)
        Me.Panel22.PerformLayout()
        CType(Me.idinfo_citation_citeinfo_pubdate_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.idinfo_citation_citeinfo_pubinfo_pubplace_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.idinfo_citation_citeinfo_pubinfo_publish_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.idinfo_citation_citeinfo_pubinfo_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.idinfo_citation_citeinfo_title_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.idinfo_citation_citeinfo_origin_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        CType(Me.idinfo_spdom_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel24.ResumeLayout(False)
        Me.Panel24.PerformLayout()
        CType(Me.idinfo_spdom_bounding_southbc_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.idinfo_spdom_bounding_westbc_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.idinfo_spdom_bounding_eastbc_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.idinfo_spdom_bounding_northbc_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        CType(Me.idinfo_ptcontac_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel26.ResumeLayout(False)
        Me.Panel26.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.Panel25.ResumeLayout(False)
        Me.Panel25.PerformLayout()
        CType(Me.idinfo_secinfo_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.idinfo_useconst_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.idinfo_accconst_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        CType(Me.idinfo_keywords_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tcKeywords.ResumeLayout(False)
        Me.tpISO.ResumeLayout(False)
        Me.tpISO.PerformLayout()
        CType(Me.idinfo_keywords_theme_themekt__ISO_19115_Topic_Category_______warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpEPA.ResumeLayout(False)
        Me.tpEPA.PerformLayout()
        CType(Me.idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus_______warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpUser.ResumeLayout(False)
        Me.tpUser.PerformLayout()
        CType(Me.idinfo_keywords_theme_themekt__User_______warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpPlace.ResumeLayout(False)
        Me.tpPlace.PerformLayout()
        CType(Me.idinfo_keywords_place_placekt__None_______warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        CType(Me.idinfo_status_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.idinfo_timeperd_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel27.ResumeLayout(False)
        Me.Panel27.PerformLayout()
        CType(Me.idinfo_status_update_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.idinfo_timeperd_current_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.idinfo_status_progress_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox18.ResumeLayout(False)
        Me.GroupBox18.PerformLayout()
        CType(Me.idinfo_timeperd_timeinfo_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.idinfo_descript_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        CType(Me.idinfo_descript_purpose_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.idinfo_descript_abstract_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.idinfo_descript_supplinf_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tcEME.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.GroupBox13.ResumeLayout(False)
        CType(Me.eainfo_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tcEntityAttr.ResumeLayout(False)
        Me.TabPage8.ResumeLayout(False)
        Me.TabPage8.PerformLayout()
        CType(Me.eainfo_overview_eadetcit_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.eainfo_overview_eaover_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage9.ResumeLayout(False)
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.grpDomain.ResumeLayout(False)
        Me.grpDomain.PerformLayout()
        Me.tcDomain.ResumeLayout(False)
        Me.tp_rdom.ResumeLayout(False)
        Me.tp_rdom.PerformLayout()
        Me.tp_codesetd.ResumeLayout(False)
        Me.tp_codesetd.PerformLayout()
        Me.tp_edom.ResumeLayout(False)
        CType(Me.dgv_edom, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tp_udom.ResumeLayout(False)
        Me.grpAttr.ResumeLayout(False)
        Me.grpAttr.PerformLayout()
        Me.GroupBox12.ResumeLayout(False)
        CType(Me.spref_____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel28.ResumeLayout(False)
        Me.Panel28.PerformLayout()
        Me.Panel29.ResumeLayout(False)
        Me.Panel29.PerformLayout()
        CType(Me._____warning, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dataqual_complete_____default As System.Windows.Forms.Button
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents dataqual_complete As System.Windows.Forms.ComboBox
    Friend WithEvents dataqual_logic As System.Windows.Forms.TextBox
    Friend WithEvents dataqual_complete_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents dataqual_logic_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents Panel10 As System.Windows.Forms.Panel
    Friend WithEvents dataqual_posacc_horizpa_horizpar_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents spref_horizsys_Zone As System.Windows.Forms.ComboBox
    Friend WithEvents spref_horizsys_Zone_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents spref_horizsys_CoordinateSystem As System.Windows.Forms.ComboBox
    Friend WithEvents spref_horizsys_CoordinateSystem_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents Panel12 As System.Windows.Forms.Panel
    Friend WithEvents dataqual_posacc_vertacc_qvertpa_vertacce As System.Windows.Forms.TextBox
    Friend WithEvents dataqual_posacc_vertacc_qvertpa_vertacce_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents dataqual_posacc_vertacc_qvertpa_vertaccv As System.Windows.Forms.TextBox
    Friend WithEvents dataqual_posacc_vertacc_qvertpa_vertaccv_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents Panel11 As System.Windows.Forms.Panel
    Friend WithEvents dataqual_posacc_horizpa_qhorizpa_horizpae As System.Windows.Forms.TextBox
    Friend WithEvents dataqual_posacc_horizpa_qhorizpa_horizpae_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents dataqual_posacc_horizpa_qhorizpa_horizpav As System.Windows.Forms.TextBox
    Friend WithEvents dataqual_posacc_horizpa_qhorizpa_horizpav_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents Panel13 As System.Windows.Forms.Panel
    Friend WithEvents dataqual_posacc_vertacc_vertaccr As System.Windows.Forms.TextBox
    Friend WithEvents dataqual_posacc_vertacc_vertaccr_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents spref_horizsys_Datum As System.Windows.Forms.ComboBox
    Friend WithEvents spref_horizsys_Datum_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents spref_horizsys_Units_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents Panel14 As System.Windows.Forms.Panel
    Friend WithEvents Panel18 As System.Windows.Forms.Panel
    Friend WithEvents distinfo_distliab As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox14 As System.Windows.Forms.GroupBox
    Friend WithEvents Panel17 As System.Windows.Forms.Panel
    Friend WithEvents distinfo_resdesc_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents distinfo_resdesc As System.Windows.Forms.ComboBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Panel16 As System.Windows.Forms.Panel
    Friend WithEvents distinfo_distrib As System.Windows.Forms.ComboBox
    Friend WithEvents distinfo_distrib_____default As System.Windows.Forms.Button
    Friend WithEvents distinfo_distrib_cntinfo_cntorgp As System.Windows.Forms.RadioButton
    Friend WithEvents distinfo_distrib_cntinfo_cntperp As System.Windows.Forms.RadioButton
    Friend WithEvents metainfo_metfrd As System.Windows.Forms.TextBox
    Friend WithEvents metainfo_metd As System.Windows.Forms.TextBox
    Friend WithEvents btnMetaFRDate4yrs As System.Windows.Forms.Button
    Friend WithEvents metainfo_metfrd_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents metainfo_metd_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents ComboBox22 As System.Windows.Forms.ComboBox
    Friend WithEvents LinkLabel37 As System.Windows.Forms.LinkLabel
    Friend WithEvents Panel21 As System.Windows.Forms.Panel
    Friend WithEvents metainfo_metstdv As System.Windows.Forms.TextBox
    Friend WithEvents metainfo_metstdn As System.Windows.Forms.TextBox
    Friend WithEvents metainfo_metstdv_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents metainfo_metstdn_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Panel20 As System.Windows.Forms.Panel
    Friend WithEvents metainfo_metc As System.Windows.Forms.ComboBox
    Friend WithEvents metainfo_metc_____default As System.Windows.Forms.Button
    Friend WithEvents metainfo_metc_cntinfo_cntorgp As System.Windows.Forms.RadioButton
    Friend WithEvents metainfo_metc_cntinfo_cntperp As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox17 As System.Windows.Forms.GroupBox
    Friend WithEvents Panel19 As System.Windows.Forms.Panel
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Panel24 As System.Windows.Forms.Panel
    Friend WithEvents idinfo_spdom_bounding As System.Windows.Forms.ComboBox
    Friend WithEvents idinfo_spdom_bounding_southbc As System.Windows.Forms.TextBox
    Friend WithEvents idinfo_spdom_bounding_eastbc As System.Windows.Forms.TextBox
    Friend WithEvents idinfo_spdom_bounding_westbc As System.Windows.Forms.TextBox
    Friend WithEvents idinfo_spdom_bounding_____default As System.Windows.Forms.Button
    Friend WithEvents idinfo_spdom_bounding_northbc As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents Panel26 As System.Windows.Forms.Panel
    Friend WithEvents idinfo_ptcontac As System.Windows.Forms.ComboBox
    Friend WithEvents idinfo_ptcontac_cntinfo_cntorgp As System.Windows.Forms.RadioButton
    Friend WithEvents idinfo_ptcontac_____default As System.Windows.Forms.Button
    Friend WithEvents idinfo_ptcontac_cntinfo_cntperp As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents Panel25 As System.Windows.Forms.Panel
    Friend WithEvents idinfo_secinfo As System.Windows.Forms.ComboBox
    Friend WithEvents idinfo_accconst As System.Windows.Forms.ComboBox
    Friend WithEvents idinfo_accconst_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_secinfo_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_useconst_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_useconst As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Panel27 As System.Windows.Forms.Panel
    Friend WithEvents idinfo_status_update As System.Windows.Forms.ComboBox
    Friend WithEvents idinfo_status_progress_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_timeperd_current As System.Windows.Forms.ComboBox
    Friend WithEvents idinfo_status_progress As System.Windows.Forms.ComboBox
    Friend WithEvents idinfo_status_update_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_timeperd_current_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents idinfo_descript_purpose_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_descript_purpose As System.Windows.Forms.TextBox
    Friend WithEvents idinfo_descript_abstract As System.Windows.Forms.TextBox
    Friend WithEvents idinfo_descript_abstract_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents idinfo_descript_supplinf As System.Windows.Forms.TextBox
    Friend WithEvents idinfo_descript_supplinf_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Panel23 As System.Windows.Forms.Panel
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents idinfo_citation_citeinfo_onlink_1______help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_citation_citeinfo_onlink_2______help As System.Windows.Forms.LinkLabel
    Friend WithEvents Panel22 As System.Windows.Forms.Panel
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents idinfo_citation_citeinfo_pubdate As System.Windows.Forms.TextBox
    Friend WithEvents idinfo_citation_citeinfo_pubinfo_publish_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_citation_citeinfo_pubdate_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_citation_citeinfo_pubinfo_pubplace As System.Windows.Forms.ComboBox
    Friend WithEvents idinfo_citation_citeinfo_pubinfo_pubplace_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents idinfo_citation_citeinfo_title_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_citation_citeinfo_origin_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_citation_citeinfo_origin_____default As System.Windows.Forms.Button
    Friend WithEvents idinfo_citation_citeinfo_title As System.Windows.Forms.TextBox
    Friend WithEvents idinfo_citation_citeinfo_origin As System.Windows.Forms.TextBox
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents btnCloseDiscard As System.Windows.Forms.Button
    Friend WithEvents btnCloseSave As System.Windows.Forms.Button
    Friend WithEvents tcEME As System.Windows.Forms.TabControl
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox13 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox12 As System.Windows.Forms.GroupBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Panel28 As System.Windows.Forms.Panel
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Panel29 As System.Windows.Forms.Panel
    Friend WithEvents idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey As System.Windows.Forms.ListBox
    Friend WithEvents idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey As System.Windows.Forms.ListBox
    Friend WithEvents idinfo_keywords_place_placekt__None___placekey As System.Windows.Forms.ListBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents Label74 As System.Windows.Forms.Label
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents Label81 As System.Windows.Forms.Label
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents Label82 As System.Windows.Forms.Label
    Friend WithEvents Label84 As System.Windows.Forms.Label
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents Label83 As System.Windows.Forms.Label
    Public WithEvents idinfo_citation_citeinfo_pubinfo_publish As System.Windows.Forms.ComboBox
    Friend WithEvents spref_horizsys_Units As System.Windows.Forms.ComboBox
    Friend WithEvents EMEWordDictionary As NetSpell.SpellChecker.Dictionary.WordDictionary
    Friend WithEvents EMESpelling As NetSpell.SpellChecker.Spelling
    Friend WithEvents HoverToolTip As System.Windows.Forms.ToolTip
    Friend WithEvents idinfo_citation_citeinfo_onlink_1______check As System.Windows.Forms.Button
    Friend WithEvents idinfo_citation_citeinfo_onlink_2______check As System.Windows.Forms.Button
    Friend WithEvents idinfo_citation_citeinfo_pubdate_____today As System.Windows.Forms.Button
    Friend WithEvents metainfo_metd_____today As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents idinfo_keywords_place_placekt__None___placekey_____default As System.Windows.Forms.Button
    Friend WithEvents idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____default As System.Windows.Forms.Button
    Friend WithEvents distinfo_distliab_____default As System.Windows.Forms.Button
    Friend WithEvents spref_horizsys As System.Windows.Forms.ComboBox
    Friend WithEvents idinfo_spdom_bounding_southbc_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_spdom_bounding_westbc_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_spdom_bounding_eastbc_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_spdom_bounding_northbc_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents Button99 As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents idinfo_citation_citeinfo_title_____default As System.Windows.Forms.Button
    Friend WithEvents idinfo_secinfo_____default As System.Windows.Forms.Button
    Friend WithEvents idinfo_useconst_____default As System.Windows.Forms.Button
    Friend WithEvents idinfo_accconst_____default As System.Windows.Forms.Button
    Friend WithEvents GroupBox18 As System.Windows.Forms.GroupBox
    Friend WithEvents timeinfo_____today As System.Windows.Forms.Button
    Friend WithEvents timeinfo As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents dataqual_logic_____default As System.Windows.Forms.Button
    Friend WithEvents dataqual_posacc_horizpa_horizpar_____default As System.Windows.Forms.Button
    Friend WithEvents distinfo_resdesc_____default As System.Windows.Forms.Button
    Friend WithEvents tcKeywords As System.Windows.Forms.TabControl
    Friend WithEvents tpISO As System.Windows.Forms.TabPage
    Friend WithEvents tpEPA As System.Windows.Forms.TabPage
    Friend WithEvents tpUser As System.Windows.Forms.TabPage
    Friend WithEvents tpPlace As System.Windows.Forms.TabPage
    Friend WithEvents idinfo_keywords_theme_themekt__User___themekey As System.Windows.Forms.ListBox
    Friend WithEvents idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____default As System.Windows.Forms.Button
    Friend WithEvents idinfo_keywords_theme_themekt__User___themekey_____default As System.Windows.Forms.Button
    Friend WithEvents dataqual_posacc_horizpa_horizpar As System.Windows.Forms.ComboBox
    Friend WithEvents eainfo_overview_eadetcit_____default As System.Windows.Forms.Button
    Friend WithEvents spref_horizsys_____default As System.Windows.Forms.Button
    Friend WithEvents idinfo_timeperd_timeinfo_mdattim_sngdate____caldate As System.Windows.Forms.ListBox
    Friend WithEvents Panel30 As System.Windows.Forms.Panel
    Friend WithEvents lblProc As System.Windows.Forms.Label
    Friend WithEvents dataqual_lineage_procstep As System.Windows.Forms.DataGridView
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents tcEntityAttr As System.Windows.Forms.TabControl
    Friend WithEvents TabPage8 As System.Windows.Forms.TabPage
    Friend WithEvents eainfo_overview_eadetcit As System.Windows.Forms.ComboBox
    Friend WithEvents eainfo_overview_eaover As System.Windows.Forms.TextBox
    Friend WithEvents TabPage9 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents enttypds_____help2 As System.Windows.Forms.Label
    Friend WithEvents enttypd_____help2 As System.Windows.Forms.Label
    Friend WithEvents enttypds As System.Windows.Forms.ComboBox
    Friend WithEvents enttypl As System.Windows.Forms.ComboBox
    Friend WithEvents enttypl_____help2 As System.Windows.Forms.Label
    Friend WithEvents grpDomain As System.Windows.Forms.GroupBox
    Friend WithEvents tcDomain As System.Windows.Forms.TabControl
    Friend WithEvents tp_rdom As System.Windows.Forms.TabPage
    Friend WithEvents rdommax As System.Windows.Forms.TextBox
    Friend WithEvents rdommax_____help2 As System.Windows.Forms.Label
    Friend WithEvents rdommin_____help2 As System.Windows.Forms.Label
    Friend WithEvents rdommin As System.Windows.Forms.TextBox
    Friend WithEvents tp_codesetd As System.Windows.Forms.TabPage
    Friend WithEvents codesets_____help2 As System.Windows.Forms.Label
    Friend WithEvents codesetn_____help2 As System.Windows.Forms.Label
    Friend WithEvents codesets As System.Windows.Forms.ComboBox
    Friend WithEvents tp_edom As System.Windows.Forms.TabPage
    Friend WithEvents dgv_edom As System.Windows.Forms.DataGridView
    Friend WithEvents tp_udom As System.Windows.Forms.TabPage
    Friend WithEvents udom As System.Windows.Forms.ComboBox
    Friend WithEvents grpAttr As System.Windows.Forms.GroupBox
    Friend WithEvents attrdefs_____help2 As System.Windows.Forms.Label
    Friend WithEvents attrdef_____help2 As System.Windows.Forms.Label
    Friend WithEvents attrlabl_____help2 As System.Windows.Forms.Label
    Friend WithEvents attrdefs As System.Windows.Forms.ComboBox
    Friend WithEvents attrlabl As System.Windows.Forms.ComboBox
    Friend WithEvents eainfo_overview_eaover_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents eainfo_overview_eadetcit_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents metainfo_metd_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents metainfo_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents metainfo_metfrd_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_citation_citeinfo_pubinfo_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_citation_citeinfo_pubinfo_publish_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_citation_citeinfo_pubinfo_pubplace_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_citation_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_citation_citeinfo_pubdate_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_citation_citeinfo_title_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_citation_citeinfo_origin_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_timeperd_timeinfo_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_descript_purpose_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_descript_abstract_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_descript_supplinf_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_citation_citeinfo_onlink_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_timeperd_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_timeperd_current_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_status_progress_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_status_update_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_spdom_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_spdom_bounding_southbc_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_spdom_bounding_westbc_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_spdom_bounding_eastbc_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_spdom_bounding_northbc_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_keywords_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_keywords_theme_themekt__ISO_19115_Topic_Category_______warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus_______warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_keywords_theme_themekt__User_______warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_keywords_place_placekt__None_______warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_useconst_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_accconst_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_ptcontac_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_secinfo_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents dataqual_complete_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents dataqual_logic_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents dataqual_posacc_horizpa_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents dataqual_posacc_horizpa_horizpar_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents dataqual_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents dataqual_posacc_horizpa_qhorizpa_horizpae_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents dataqual_posacc_horizpa_qhorizpa_horizpav_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents dataqual_posacc_vertacc_qvertpa_vertaccv_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents dataqual_posacc_vertacc_qvertpa_vertacce_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents dataqual_posacc_vertacc_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents dataqual_posacc_vertacc_vertaccr_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents dataqual_lineage_procstep_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents spref_horizsys_Datum_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents spref_horizsys_Units_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents spref_horizsys_Zone_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents spref_horizsys_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents spref_horizsys_CoordinateSystem_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents spref_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents distinfo_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents distinfo_distrib_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents eainfo_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents eainfo_overview_eaover_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents eainfo_overview_eadetcit_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents distinfo_distliab_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents distinfo_resdesc_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents metainfo_metstdv_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents metainfo_metstdn_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents metainfo_metc_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents timeinfo_____help2 As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_ptcontac_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents distinfo_distrib_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents metainfo_metc_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents detailed_____help2 As System.Windows.Forms.LinkLabel
    Friend WithEvents enttyp_____help2 As System.Windows.Forms.LinkLabel
    Friend WithEvents attr_____help2 As System.Windows.Forms.LinkLabel
    Friend WithEvents dataqual_lineage_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_status_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents idinfo_descript_____warning As System.Windows.Forms.PictureBox
    Friend WithEvents _____warning As System.Windows.Forms.PictureBox
    Friend WithEvents enttypd As System.Windows.Forms.TextBox
    Friend WithEvents attrdef As System.Windows.Forms.TextBox
    Friend WithEvents codesetn As System.Windows.Forms.TextBox
    Friend WithEvents btnAddEntity As System.Windows.Forms.Button
    Friend WithEvents btnDeleteEntity As System.Windows.Forms.Button
    Friend WithEvents btnDeleteAttribute As System.Windows.Forms.Button
    Friend WithEvents btnAddAttribute As System.Windows.Forms.Button
    Friend WithEvents procDate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents procdesc As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents attrdomv_____help2 As System.Windows.Forms.LinkLabel
    Friend WithEvents Value As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Definition As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DefinitionSource As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents idinfo_citation_citeinfo_onlink_2______default As System.Windows.Forms.Button
    Friend WithEvents idinfo_citation_citeinfo_onlink_1______default As System.Windows.Forms.Button
    Friend WithEvents idinfo_keywords_place_placekt__None___placekey_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_keywords_theme_themekt__ISO_19115_Topic_Category___themekey_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_keywords_theme_themekt__EPA_GIS_Keyword_Thesaurus___themekey_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_keywords_theme_themekt__User___themekey_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents dataqual_lineage_procstep_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_citation_citeinfo_onlink_1_ As System.Windows.Forms.ComboBox
    Friend WithEvents idinfo_citation_citeinfo_onlink_2_ As System.Windows.Forms.ComboBox
    Friend WithEvents btnAddProcstep As System.Windows.Forms.Button
    Friend WithEvents btnDelProcstep As System.Windows.Forms.Button
    Friend WithEvents distinfo_distliab_____help As System.Windows.Forms.LinkLabel
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents btnMoreLinkages As System.Windows.Forms.Button
    Friend WithEvents idinfo_citation_citeinfo_onlink_10_ As System.Windows.Forms.ComboBox
    Friend WithEvents idinfo_citation_citeinfo_onlink_9_ As System.Windows.Forms.ComboBox
    Friend WithEvents idinfo_citation_citeinfo_onlink_10______default As System.Windows.Forms.Button
    Friend WithEvents idinfo_citation_citeinfo_onlink_9______default As System.Windows.Forms.Button
    Friend WithEvents idinfo_citation_citeinfo_onlink_10______check As System.Windows.Forms.Button
    Friend WithEvents idinfo_citation_citeinfo_onlink_9______check As System.Windows.Forms.Button
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents idinfo_citation_citeinfo_onlink_9______help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_citation_citeinfo_onlink_10______help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_citation_citeinfo_onlink_8_ As System.Windows.Forms.ComboBox
    Friend WithEvents idinfo_citation_citeinfo_onlink_7_ As System.Windows.Forms.ComboBox
    Friend WithEvents idinfo_citation_citeinfo_onlink_8______default As System.Windows.Forms.Button
    Friend WithEvents idinfo_citation_citeinfo_onlink_7______default As System.Windows.Forms.Button
    Friend WithEvents idinfo_citation_citeinfo_onlink_8______check As System.Windows.Forms.Button
    Friend WithEvents idinfo_citation_citeinfo_onlink_7______check As System.Windows.Forms.Button
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents idinfo_citation_citeinfo_onlink_7______help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_citation_citeinfo_onlink_8______help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_citation_citeinfo_onlink_6_ As System.Windows.Forms.ComboBox
    Friend WithEvents idinfo_citation_citeinfo_onlink_5_ As System.Windows.Forms.ComboBox
    Friend WithEvents idinfo_citation_citeinfo_onlink_6______default As System.Windows.Forms.Button
    Friend WithEvents idinfo_citation_citeinfo_onlink_5______default As System.Windows.Forms.Button
    Friend WithEvents idinfo_citation_citeinfo_onlink_6______check As System.Windows.Forms.Button
    Friend WithEvents idinfo_citation_citeinfo_onlink_5______check As System.Windows.Forms.Button
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents idinfo_citation_citeinfo_onlink_5______help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_citation_citeinfo_onlink_6______help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_citation_citeinfo_onlink_4_ As System.Windows.Forms.ComboBox
    Friend WithEvents idinfo_citation_citeinfo_onlink_3_ As System.Windows.Forms.ComboBox
    Friend WithEvents idinfo_citation_citeinfo_onlink_4______default As System.Windows.Forms.Button
    Friend WithEvents idinfo_citation_citeinfo_onlink_3______default As System.Windows.Forms.Button
    Friend WithEvents idinfo_citation_citeinfo_onlink_4______check As System.Windows.Forms.Button
    Friend WithEvents idinfo_citation_citeinfo_onlink_3______check As System.Windows.Forms.Button
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents idinfo_citation_citeinfo_onlink_3______help As System.Windows.Forms.LinkLabel
    Friend WithEvents idinfo_citation_citeinfo_onlink_4______help As System.Windows.Forms.LinkLabel
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents toolStripSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SaveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveAsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents toolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents PrintToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrintPreviewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents toolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UndoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RedoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents toolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PasteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents toolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SelectAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FindAndReplaceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SpellCheckToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetValidationResultsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewInUserInterfaceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewInBrowserWindowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ValidateToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewMetadataXMLToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContentsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IndexToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SearchToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents toolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenDatabaseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetDefaultToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RefreshFromDatabaseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoveESRITagsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LocalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViaWebserviceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tbValidationTimeout As System.Windows.Forms.ToolStripTextBox

End Class
